USE AdventureWorks

--Skapa ny tabell
SELECT
	BusinessEntityID
	,FirstName
	,MiddleName
	,LastName
INTO
	personer
FROM
	person.Person

--Fyll p� med fler rader
INSERT INTO personer
SELECT
	BusinessEntityID
	,FirstName
	,MiddleName
	,LastName
FROM
	person.Person
GO 50--G�r om 50 g�nger

SELECT COUNT(*) FROM personer--1.018.572 rader

SET STATISTICS IO ON--Sl� p� IO

SELECT
	FirstName
	,LastName
FROM
	personer
WHERE
	LastName='Merz'--7396 sidor, 6.60 Kostnad

--Skapa klustrat index 
CREATE CLUSTERED INDEX CL_BID ON personer(Businessentityid)

SELECT
	FirstName
	,LastName
FROM
	personer
WHERE
	LastName='Merz'--6395 sidor, 5.85 Kostnad

--Skapa index p� efternamn
CREATE INDEX IX_Lastname ON personer(Lastname)

SELECT
	FirstName
	,LastName
FROM
	personer
WHERE
	LastName='Merz'--4 sidor sidor, 0.31 Kostnad


--Skapa ett t�ckande (covering) index
CREATE INDEX IX_Last_First ON personer(Lastname) 
INCLUDE(Firstname)

SELECT
	FirstName
	,LastName
FROM
	personer
WHERE
	LastName='Merz'--5 sidor sidor, 0.003 Kostnad

--F�rdel med index
--S�kningar g�r snabbare

--Nackdelar med index
	--1. Tar plats
	--2. Uppdateringar tar tid

SET STATISTICS IO OFF
SET STATISTICS TIME ON

INSERT INTO personer
SELECT
	BusinessEntityID
	,FirstName
	,MiddleName
	,LastName
FROM
	person.Person--Tid med index:11821 ms, Utan index:1546 ms

SET STATISTICS TIME OFF

--Skapa fragmentering
INSERT INTO personer
SELECT
	BusinessEntityID
	,FirstName
	,MiddleName
	,LastName
FROM
	person.Person
GO 20

--Reorganisera indexet, l�tt uppgift
ALTER INDEX IX_Lastname ON personer REORGANIZE

--Reorganisera indexet, mer kr�vande
ALTER INDEX IX_Lastname ON personer REBUILD