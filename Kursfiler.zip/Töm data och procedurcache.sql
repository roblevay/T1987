--T�m datacachen, f�rsiktigt i produktion!
CHECKPOINT
DBCC DROPCLEANBUFFERS

--T�m procedurcachen
DBCC FREEPROCCACHE

--G�r i en s�rskild databas
DBCC FLUSHPROCINDB(8)

--T�m i nuvarande databas
DECLARE @dbid INT =DB_ID()
DBCC FLUSHPROCINDB(@dbid)


EXEC sp_Helpdb

--F�r att kolla IO
SET STATISTICS IO ON

SELECT * FROM FactResellerSales