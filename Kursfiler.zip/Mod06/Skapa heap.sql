USE AdventureWorks



CREATE TABLE firstname (fnamn VARCHAR(50))

INSERT INTO firstname VALUES ('bertil')
INSERT INTO firstname VALUES ('Cesar')
INSERT INTO firstname VALUES ('Adam')

SELECT * FROM firstname--Osorterad

EXEC sp_indexinfo firstname--Info

SELECT * FROM Person.Person

EXEC sp_indexinfo person--Info