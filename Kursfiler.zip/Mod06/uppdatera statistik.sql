--Uppdatera statistik f�r en tabelle
UPDATE STATISTICS [dbo].[personer]

--Uppdatera statistik f�r hela databasen
EXEC sp_updatestats