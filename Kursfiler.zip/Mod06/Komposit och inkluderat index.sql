SELECT
	firstname
	,lastname
FROM
	Personer
WHERE
	LastName='Smith'--0.003

--Tv� s�tt att skapa t�ckande index, identisk fr�geprestanda
--Skillnaden �r att included index tar
--mindre kraft att uppdatera

--1. Skapa komposit index
CREATE INDEX IX_Comp ON personer(lastname,Firstname)
DROP INDEX IX_Comp ON personer

--2. Skapa index med included column
CREATE INDEX IX_Included ON personer(lastname) INCLUDE (Firstname)