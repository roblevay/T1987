--Default l�ge
SET TRANSACTION ISOLATION LEVEL READ COMMITTED

USE AdventureWorks
BEGIN TRAN
	UPDATE person.Person
	SET FirstName='Robban' WHERE BusinessEntityID=1

ROLLBACK TRAN--Omintetg�r �ndringen