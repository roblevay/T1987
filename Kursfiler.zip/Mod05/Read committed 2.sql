--Default
SET TRANSACTION ISOLATION LEVEL READ COMMITTED

--Nu �r jag blockerad
SELECT * FROM Person.Person WHERE BusinessEntityID=1

--�ndra s� att jag kan l�sa i transaktioner
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

--Nu �r jag inte blockerad. Jag kan l�sa i en �ppen transaktion
SELECT * FROM Person.Person WHERE BusinessEntityID=1

--Om trasaktionen har rullats tillbaks s� har jag f�tt fel info
