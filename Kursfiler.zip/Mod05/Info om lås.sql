EXEC sp_who--Alla processer

EXEC sp_who2--Nyare version 

SELECT * FROM sys.dm_tran_locks--Alla l�s

EXEC sp_whoisactive--Endast processer inblandade i blockeringar

EXEC sp_blitzlock--Som whoisactive men med mer info

EXEC sp_blitzwho--Som whoisactive