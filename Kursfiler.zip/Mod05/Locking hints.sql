CREATE DATABASE LockingDemo;
GO
USE LockingDemo;
GO
CREATE TABLE Customers (
    ID INT PRIMARY KEY,
    Name NVARCHAR(50)
);
INSERT INTO Customers VALUES (1, 'Alice'), (2, 'Bob'), (3, 'Charlie');

--ROWLOCK
UPDATE Customers WITH (ROWLOCK) SET Name = 'David' WHERE ID = 1;


--PAGLOCK
UPDATE Customers WITH (PAGLOCK) SET Name = 'Eve' WHERE ID = 2;

--TABLOCK
SELECT * FROM Customers WITH (TABLOCK);


--READCOMMITTED � Standardl�ge, l�ser endast committad data
SELECT * FROM Customers WITH (READCOMMITTED);

--READUNCOMMITTED / NOLOCK � Till�ter dirty reads
SELECT * FROM Customers WITH (READUNCOMMITTED);
-- Eller ekvivalent:
SELECT * FROM Customers WITH (NOLOCK);
