--Lista sidor i en tabell
DBCC IND('Adventureworks', 'person.person', -1) 

--Eller
SELECT *
FROM sys.dm_db_database_page_allocations(DB_ID('Adventureworks'
), OBJECT_ID('person.address'), NULL, NULL, 'DETAILED');
