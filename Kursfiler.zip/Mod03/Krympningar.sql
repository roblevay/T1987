--Krymp hela databasen
DBCC SHRINKDATABASE
(
    N'SalesDB',      -- Databasnamn
    10              -- L�mna 10 % ledigt utrymme, optional
);
GO

--Krymp en fil
USE [Salesdb]
GO
DBCC SHRINKFILE (N'Salesdb' --Filnamn
, 10)--�nskad storlek
GO

--Kolla
SELECT
    name,
    type_desc,
    size / 128.0 AS SizeMB,
    physical_name
FROM sys.database_files;
GO

--Anv�nd denna n�r krympning inte funkar
SELECT
    name,
    recovery_model_desc,
    log_reuse_wait_desc
FROM sys.databases
WHERE name = 'SalesDB';
GO
