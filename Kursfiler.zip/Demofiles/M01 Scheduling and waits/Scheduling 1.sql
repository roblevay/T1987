--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Scheduling, skapa �ppen transaktion
USE TSQL

--Returnera v�s SPID f�rst
SELECT @@SPID as update_session_id

BEGIN TRAN

UPDATE Sales.Customers
SET companyname = N'Customer Demo Update'
WHERE custid = 10

--ROLLBACK
