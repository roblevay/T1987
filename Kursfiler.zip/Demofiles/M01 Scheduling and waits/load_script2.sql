-- load generation script 2
USE TSQL;
GO

DECLARE @start datetime2 = GETDATE();

WHILE DATEDIFF(ss,@start,GETDATE()) < 300
BEGIN
	INSERT insertTarget (date1)
	VALUES (GETDATE())
END