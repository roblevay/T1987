﻿."$PSScriptRoot\Run-Workload.ps1" "$PSScriptRoot\load_script1.sql"
