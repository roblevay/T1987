-- load generation script 1
-- loops for three minutes
DECLARE @start datetime2 = GETDATE();

WHILE DATEDIFF(ss,@start,GETDATE()) < 300
BEGIN
	SELECT TOP 5 a.name
	FROM master.dbo.spt_values AS a
	CROSS JOIN master.dbo.spt_values AS b
	ORDER BY NEWID()
	OPTION  (MAXDOP 1);
END