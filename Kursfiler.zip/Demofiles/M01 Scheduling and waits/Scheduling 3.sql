--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Scheduling, visa info

DROP TABLE IF EXISTS #session;
CREATE TABLE #session (session_id int NOT NULL)

--Justera dessa till v�rden fr�n andra sessionerna
INSERT #session
VALUES
 (65)
,(66)
,(68)

--En rad per connection. N�t-relaterad info.
SELECT session_id, connect_time, net_transport, encrypt_option, auth_scheme, most_recent_sql_handle-- ,*
FROM sys.dm_exec_connections
WHERE session_id IN (SELECT session_id FROM #session)

--En rad per session
SELECT status, * 
FROM sys.dm_exec_sessions 
WHERE session_id IN (SELECT session_id FROM #session)

--Request: Logisk representation av batch/proc som klient skickat in
SELECT status, * 
FROM sys.dm_exec_requests  
WHERE session_id IN (SELECT session_id FROM #session)

--Task, " single unit of work that needs to be carried out for the request to be completed."
--Update har ingen task, g�r inget f�r tillf�llet
SELECT t.session_id, t.task_state, t.scheduler_id
FROM sys.dm_os_tasks AS t
WHERE session_id IN (SELECT session_id FROM #session)
ORDER BY scheduler_id

--Notera query som l�ggs �ver 4 schedulers. D�r har vi vad MAXDOP betyder. 
--En scheduler kan ju bara g�ra en sak �t g�ngen, oavsett hur m�nga tasks som l�ggs d�r.

--Worker, "Tasks that need to be executed are assigned to a worker, which in turn is scheduled to run on the CPU"
--Update har ingen task, g�r inget f�r tillf�llet
--SELECT �r suspended
SELECT dot.session_id, dow.state, dow.last_wait_type, dow.*
FROM sys.dm_os_workers AS dow
  JOIN sys.dm_os_tasks AS dot ON dot.task_address = dow.task_address
WHERE dot.session_id IN (SELECT session_id FROM #session)

--Hur l�nge har vi v�ntat?
SELECT	dot.session_id, 
		dow.state,
		CASE WHEN dow.state = 'SUSPENDED' 
			 THEN (SELECT ms_ticks FROM sys.dm_os_sys_info) - dow.wait_started_ms_ticks
			 ELSE NULL
		END AS time_spent_waiting_ms,
		CASE WHEN dow.state = 'RUNNABLE' 
			 THEN (SELECT ms_ticks FROM sys.dm_os_sys_info) - dow.wait_resumed_ms_ticks
			 ELSE NULL
		END AS time_spent_runnable_ms
FROM sys.dm_os_workers AS dow
  JOIN sys.dm_os_tasks AS dot ON dot.task_address = dow.task_address
WHERE dot.session_id IN (SELECT session_id FROM #session)

--Tr�dinfo
SELECT dot.session_id,  dth.*
FROM sys.dm_os_threads dth
  INNER JOIN sys.dm_os_workers AS dow ON dow.worker_address = dth.worker_address
  INNER JOIN sys.dm_os_tasks AS dot ON dot.task_address = dow.task_address
WHERE dot.session_id IN (SELECT session_id FROM #session)

--G�r ROLLBACK
