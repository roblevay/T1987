--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Scheduling, g�r l�sning s� vi blir blockerad
USE TSQL

SELECT @@SPID as select_session_id
GO

SELECT companyname FROM Sales.Customers

