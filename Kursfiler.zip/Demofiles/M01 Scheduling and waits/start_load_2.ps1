﻿."$PSScriptRoot\Workload\Run-Workload.ps1" "$PSScriptRoot\Workload\load_script2.sql" 50

