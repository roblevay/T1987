--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Vyer f�r att titta p� v�ntestatistik


------------------------------------------------------------------------------------------------------------
--sys.dm_os_wait_stats
------------------------------------------------------------------------------------------------------------

--Den nog mest vanligt anv�nda:
SELECT * 
FROM sys.dm_os_wait_stats
ORDER BY wait_time_ms DESC

--Azure SQL Database har sys.dm_db_wait_stats


--Problemet �r att viss typ av v�ntan �r helt naturligt.
--Exempelvis processer som l�gger sig och sover ("v�ntar") och sen vaknar till snabbt (exempelvis checkpoint)

--Nedan �r fr�n Glenn Berrys DMV diag script. Notera "ignore-listan":
-- https://glennsqlperformance.com/resources/


-- Isolate top waits for server instance since last restart or wait statistics clear  (Query 39) (Top Waits)
WITH [Waits] 
AS (SELECT wait_type, wait_time_ms/ 1000.0 AS [WaitS],
          (wait_time_ms - signal_wait_time_ms) / 1000.0 AS [ResourceS],
           signal_wait_time_ms / 1000.0 AS [SignalS],
           waiting_tasks_count AS [WaitCount],
           100.0 *  wait_time_ms / SUM (wait_time_ms) OVER() AS [Percentage],
           ROW_NUMBER() OVER(ORDER BY wait_time_ms DESC) AS [RowNum]
    FROM sys.dm_os_wait_stats WITH (NOLOCK)
    WHERE [wait_type] NOT IN (
        N'BROKER_EVENTHANDLER', N'BROKER_RECEIVE_WAITFOR', N'BROKER_TASK_STOP',
		N'BROKER_TO_FLUSH', N'BROKER_TRANSMITTER', N'CHECKPOINT_QUEUE',
        N'CHKPT', N'CLR_AUTO_EVENT', N'CLR_MANUAL_EVENT', N'CLR_SEMAPHORE', N'CXCONSUMER',
        N'DBMIRROR_DBM_EVENT', N'DBMIRROR_EVENTS_QUEUE', N'DBMIRROR_WORKER_QUEUE',
		N'DBMIRRORING_CMD', N'DIRTY_PAGE_POLL', N'DISPATCHER_QUEUE_SEMAPHORE',
        N'EXECSYNC', N'FSAGENT', N'FT_IFTS_SCHEDULER_IDLE_WAIT', N'FT_IFTSHC_MUTEX',
        N'HADR_CLUSAPI_CALL', N'HADR_FILESTREAM_IOMGR_IOCOMPLETION', N'HADR_LOGCAPTURE_WAIT', 
		N'HADR_NOTIFICATION_DEQUEUE', N'HADR_TIMER_TASK', N'HADR_WORK_QUEUE',
        N'KSOURCE_WAKEUP', N'LAZYWRITER_SLEEP', N'LOGMGR_QUEUE', 
		N'MEMORY_ALLOCATION_EXT', N'ONDEMAND_TASK_QUEUE',
		N'PARALLEL_REDO_DRAIN_WORKER', N'PARALLEL_REDO_LOG_CACHE', N'PARALLEL_REDO_TRAN_LIST',
		N'PARALLEL_REDO_WORKER_SYNC', N'PARALLEL_REDO_WORKER_WAIT_WORK',
		N'PREEMPTIVE_HADR_LEASE_MECHANISM', N'PREEMPTIVE_SP_SERVER_DIAGNOSTICS',
		N'PREEMPTIVE_OS_LIBRARYOPS', N'PREEMPTIVE_OS_COMOPS', N'PREEMPTIVE_OS_CRYPTOPS',
		N'PREEMPTIVE_OS_PIPEOPS', N'PREEMPTIVE_OS_AUTHENTICATIONOPS',
		N'PREEMPTIVE_OS_GENERICOPS', N'PREEMPTIVE_OS_VERIFYTRUST',
		N'PREEMPTIVE_OS_FILEOPS', N'PREEMPTIVE_OS_DEVICEOPS', N'PREEMPTIVE_OS_QUERYREGISTRY',
		N'PREEMPTIVE_OS_WRITEFILE', N'PREEMPTIVE_OS_WRITEFILEGATHER',
		N'PREEMPTIVE_XE_CALLBACKEXECUTE', N'PREEMPTIVE_XE_DISPATCHER',
		N'PREEMPTIVE_XE_GETTARGETSTATE', N'PREEMPTIVE_XE_SESSIONCOMMIT',
		N'PREEMPTIVE_XE_TARGETINIT', N'PREEMPTIVE_XE_TARGETFINALIZE',
        N'PWAIT_ALL_COMPONENTS_INITIALIZED', N'PWAIT_DIRECTLOGCONSUMER_GETNEXT',
		N'PWAIT_EXTENSIBILITY_CLEANUP_TASK',
		N'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP', N'QDS_ASYNC_QUEUE',
        N'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP', N'REQUEST_FOR_DEADLOCK_SEARCH',
		N'RESOURCE_QUEUE', N'SERVER_IDLE_CHECK', N'SLEEP_BPOOL_FLUSH', N'SLEEP_DBSTARTUP',
		N'SLEEP_DCOMSTARTUP', N'SLEEP_MASTERDBREADY', N'SLEEP_MASTERMDREADY',
        N'SLEEP_MASTERUPGRADED', N'SLEEP_MSDBSTARTUP', N'SLEEP_SYSTEMTASK', N'SLEEP_TASK',
        N'SLEEP_TEMPDBSTARTUP', N'SNI_HTTP_ACCEPT', N'SOS_WORK_DISPATCHER',
		N'SP_SERVER_DIAGNOSTICS_SLEEP', N'SOS_WORKER_MIGRATION', N'VDI_CLIENT_OTHER',
		N'SQLTRACE_BUFFER_FLUSH', N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP', N'SQLTRACE_WAIT_ENTRIES',
		N'STARTUP_DEPENDENCY_MANAGER',
		N'WAIT_FOR_RESULTS', N'WAITFOR', N'WAITFOR_TASKSHUTDOWN', N'WAIT_XTP_HOST_WAIT',
		N'WAIT_XTP_OFFLINE_CKPT_NEW_LOG', N'WAIT_XTP_CKPT_CLOSE', N'WAIT_XTP_RECOVERY',
		N'XE_BUFFERMGR_ALLPROCESSED_EVENT', N'XE_DISPATCHER_JOIN',
        N'XE_DISPATCHER_WAIT', N'XE_LIVE_TARGET_TVF', N'XE_TIMER_EVENT')
    AND waiting_tasks_count > 0)
SELECT
    MAX (W1.wait_type) AS [WaitType],
	CAST (MAX (W1.Percentage) AS DECIMAL (5,2)) AS [Wait Percentage],
	CAST ((MAX (W1.WaitS) / MAX (W1.WaitCount)) AS DECIMAL (16,4)) AS [AvgWait_Sec],
    CAST ((MAX (W1.ResourceS) / MAX (W1.WaitCount)) AS DECIMAL (16,4)) AS [AvgRes_Sec],
    CAST ((MAX (W1.SignalS) / MAX (W1.WaitCount)) AS DECIMAL (16,4)) AS [AvgSig_Sec], 
    CAST (MAX (W1.WaitS) AS DECIMAL (16,2)) AS [Wait_Sec],
    CAST (MAX (W1.ResourceS) AS DECIMAL (16,2)) AS [Resource_Sec],
    CAST (MAX (W1.SignalS) AS DECIMAL (16,2)) AS [Signal_Sec],
    MAX (W1.WaitCount) AS [Wait Count],
	CAST (N'https://www.sqlskills.com/help/waits/' + W1.wait_type AS XML) AS [Help/Info URL]
FROM Waits AS W1
INNER JOIN Waits AS W2
ON W2.RowNum <= W1.RowNum
GROUP BY W1.RowNum, W1.wait_type
--HAVING SUM (W2.Percentage) - MAX (W1.Percentage) < 99 -- percentage threshold
OPTION (RECOMPILE);
------

--Hur stor del �r signal wait (dvs v�nta p� CPU) om stor del kanske vi kan dra nytta ev fler CPU
SELECT SUM(signal_wait_time_ms)/ CAST(SUM(wait_time_ms) AS decimal(38,2))  
FROM sys.dm_os_wait_stats
--H�r b�r vi ignorera ointressanta, enligt ovan
GO




--Bra resurs f�r wait stats:
-- https://www.sqlskills.com/help/waits

--CXPACKET bryts upp i tv� olika i 2016 sp2, 2017 cu1
--CXPACKET �r n�r producenten �r seg med att producera data till konsumenten.
--CXCONSUMER �r n�r konsumenten v�ntar p� att data produceras. Inget konstigt med det, kan vanligtvis ignorera dessa.
-- https://www.sqlskills.com/blogs/paul/cxconsumer-wait-type-history-and-what-you-need-to-know/
-- https://blogs.msdn.microsoft.com/sql_server_team/making-parallelism-waits-actionable/


--Vi kan nolla waitstats med:
--DBCC SQLPERF('sys.dm_os_wait_stats', CLEAR);

--Sen n�r? Om wait-stats inte har nollats, sen uppstart:
SELECT create_date FROM sys.databases WHERE name = 'tempdb'
--Eller
SELECT x.sqlserver_start_time FROM sys.dm_os_sys_info AS x

------------------------------------------------------------------------------------------------------------
--sys.dm_os_waiting_tasks
------------------------------------------------------------------------------------------------------------
--Var v�ntar vi just nu?
SELECT * 
FROM sys.dm_os_waiting_tasks  AS r
INNER JOIN sys.dm_exec_sessions AS s ON s.session_id = r.session_id
WHERE s.is_user_process = 1
ORDER BY r.session_id DESC

--Framkalla v�ntan
BEGIN TRANSACTION;
UPDATE AdventureWorks.Person.Person
SET Firstname = 'Kalle'
WHERE BusinessEntityID = 1;
-- H�ll transaktionen �ppen utan att committa.

--i ett annat f�nster
SELECT * FROM AdventureWorks.Person.Person

--rulla tillbaks
ROLLBACK TRAN


------------------------------------------------------------------------------------------------------------
--I exekveringsplanen, se actual execution plan, "yttersta" SELECT:en
------------------------------------------------------------------------------------------------------------
SELECT * FROM Adventureworks.Sales.SalesOrderDetail ORDER BY OrderQty
GO

------------------------------------------------------------------------------------------------------------
--sys.dm_exec_session_wait_stats
------------------------------------------------------------------------------------------------------------
SELECT *
FROM sys.dm_exec_session_wait_stats
--WHERE session_id = @@SPID				--OBS: Justera!!!
ORDER BY session_id, wait_time_ms DESC
