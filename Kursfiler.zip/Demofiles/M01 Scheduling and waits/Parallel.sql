--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

-------------------------------------------------------------------------------------------------------------
--Vilka processork�rnor f�r vi anv�nda (f�rsta tre)
-------------------------------------------------------------------------------------------------------------
ALTER SERVER CONFIGURATION SET PROCESS AFFINITY CPU = 0 TO 1


-------------------------------------------------------------------------------------------------------------
--Parallelism (f�r en operator)
-------------------------------------------------------------------------------------------------------------

USE Adventureworks

--Exempel p� fr�ga som parallelliseras
SELECT * FROM Sales.SalesOrderDetail ORDER BY OrderQty
GO 10

--Max antal k�rnor per operator, f�r hela servern (instansen)
EXEC sp_configure 'max degree of parallelism', 0--Parallelism till�ten
RECONFIGURE

EXEC sp_configure 'max degree of parallelism', 1--Bara en k�rna
RECONFIGURE

--P� databas niv� (kom i 2016), g�r override p� server-inst�llningen
ALTER DATABASE SCOPED CONFIGURATION SET MAXDOP = 4;

--Som en query hint, dvs p� query niv�. G�r override p� b�da ovanst�ende
SELECT * FROM Sales.SalesOrderDetail ORDER BY OrderQty OPTION(MAXDOP 1)

--I SQL Server 2022 kan vi f� DOP feedback
-- https://cloudblogs.microsoft.com/sqlserver/2022/10/20/intelligent-query-processing-degree-of-parallelism-feedback/


-------------------------------------------------------------------------------------------------------------
--Gr�ns f�r kostnad f�r att parallellisera (parallellisera inte billiga fr�gor, typ. 50, kanske?)
-------------------------------------------------------------------------------------------------------------
SELECT * FROM Sales.SalesOrderDetail ORDER BY OrderQty

EXEC sp_configure N'cost threshold for parallelism', N'5'
RECONFIGURE 

--H�r �r fr�ga som ger en estimated cost p� 5 (n�r jag testade den)
SELECT * 
FROM 
(
SELECT TOP(60900) * FROM Sales.SalesOrderDetail
) AS i
ORDER BY OrderQty
OPTION(MAXDOP 1)
-------------------------------------------------------------------------------------------------------------


-------------------------------------------------------------------------------------------------------------
--Approp� "best practices" och bla sp_configure
-------------------------------------------------------------------------------------------------------------

--Se http://karaszi.com/checklist-for-sql-server-implementations f�r "checklista"/"best practices"

EXEC sp_blitz

-- https://glennsqlperformance.com/resources/


-------------------------------------------------------------------------------------------------------------
--Approp� sp_configure (instansniv�)
-------------------------------------------------------------------------------------------------------------
SELECT * FROM sys.configurations ORDER BY name
EXEC sp_configure

--Sl� p� show advanved f�r att se alla
EXEC sp_configure 'show advanced', 1
RECONFIGURE
GO

--Vissa server-inst�llningar s�tts med ALTER SERVER CONFIGURATION ist�llet
