--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Visa lite allm�nt om DMV och systemarkitektur

-- K�r: start_load_1.ps1
-- C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 01
-- Den g�r i ca 5 minuter, g�r att starta om...

--NUMA noder
SELECT * FROM sys.dm_os_nodes

--Schedulers, en per processork�rna
SELECT * FROM sys.dm_os_schedulers

--Quanta
SELECT * FROM sys.dm_os_sys_info


--En rad per session
SELECT * FROM sys.dm_exec_sessions 
WHERE is_user_process = 1
ORDER BY session_id


--En rad per exekverande session/kommando
--Notera statuskolumnen
SELECT * FROM sys.dm_exec_requests AS r
INNER JOIN sys.dm_exec_sessions AS s ON s.session_id = r.session_id
WHERE s.is_user_process = 1


--CPU historik fr�n sys.dm_os_ring_buffer
SELECT Notification_Time, ProcessUtilization AS SQLProcessUtilization,
SystemIdle, 100 - SystemIdle - ProcessUtilization AS OtherProcessUtilization
FROM (	SELECT	r.value('(./Record/@id)[1]', 'int') AS record_id,
				r.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int') AS SystemIdle,
				r.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int') AS ProcessUtilization,
				Notification_Time
		FROM (	SELECT	CONVERT(xml, record) as r,
						DATEADD(ms, (rbf.timestamp - tme.ms_ticks), 
						GETDATE()) as Notification_Time
				FROM sys.dm_os_ring_buffers AS rbf
				CROSS join sys.dm_os_sys_info tme
				WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR'
			) AS x
	) AS y
ORDER BY record_id DESC

--sys.dm_os_ring_buffers, kolumnen "record" inneh�ller XML
SELECT * FROM sys.dm_os_ring_buffers
WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR'

SELECT * FROM sys.dm_os_sys_info
