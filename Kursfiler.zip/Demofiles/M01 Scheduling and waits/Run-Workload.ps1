﻿# generate database load by starting a number of workers running the same SQL script

param 
(
    $scriptPath = $(throw "a file name is required"),
    $workerCount = 10,
    $sqlServerName = "TK\A",
    $sqlDatabaseName = "master"
)

$execScript = {
    param( $sqlServerName, $sqlDatabaseName, $scriptPath  )
    & SQLCMD -E -S $sqlServerName -d $sqlDatabaseName -i $scriptPath
}

(1..$workerCount) | % {
    Start-Job $execScript -ArgumentList $sqlServerName, $sqlDatabaseName, $scriptPath
}

Write-Host -NoNewline "Load running."

while ( @(gjb | Select-Object -ExpandProperty State -Unique) -contains "Running" ){
    Start-Sleep -seconds 2
    Write-Host -NoNewline "."
}

Write-Host "`nLoad ended"
Pause