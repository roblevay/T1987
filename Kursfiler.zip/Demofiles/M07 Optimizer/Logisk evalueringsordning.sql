--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Den ordning vi skriver
--SELECT
--FROM
--WHERE
--GROUP BY
--HAVING
--ORDER BY

--Den logiska evalueringsordningen, enkel
--FROM
--WHERE
--GROUP BY
--HAVING
--SELECT
--ORDER BY
--TOP

