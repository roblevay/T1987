--Sl� av vissa optimeringsm�jligheter i optimizer

--Exempel, sl� av m�jlighet att �ndra join-ording f�r inner joins:
-- OPTION ( QUERYRULEOFF JoinCommute)

-- https://www.mssqltips.com/sqlservertip/4175/disabling-sql-server-optimizer-rules-with-queryruleoff/
