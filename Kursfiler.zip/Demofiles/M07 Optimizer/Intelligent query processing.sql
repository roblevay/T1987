--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

https://docs.microsoft.com/en-us/sql/relational-databases/performance/intelligent-query-processing?view=sql-server-ver15

USE AdventureworksDW

SELECT COUNT(DISTINCT UnitPrice)
FROM FactResellerSalesXL
GO

SELECT APPROX_COUNT_DISTINCT(UnitPrice)
FROM FactResellerSalesXL
GO

SELECT * FROM sys.database_scoped_configurations

--Vilka saker kr�ver Enterprise Edition?
-- https://docs.microsoft.com/en-us/sql/sql-server/editions-and-components-of-sql-server-version-15


CREATE TABLE #myTable(c1 int)

DECLARE @myTable table(c1 int)
