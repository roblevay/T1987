--Approximate query processing

USE StackOverflow
GO


SELECT TOP(1000) * FROM Votes

--Sl� p� Actual execution plan

--J�mf�r memory grant p� nedanst�ende
SELECT COUNT(DISTINCT PostId) FROM Votes
SELECT APPROX_COUNT_DISTINCT(PostId) FROM Votes
