--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.


/*
View various tree representations
8605: Logical query Tree
8606: Additional logical trees (input tree, simplified tree, join-collapsed tree, tree before project normalization, and tree after project normalization)
8607: Optimization output tree
8675: Info about the various phases
2372: Memory utilization
2373: More memory utilization
8757: Skip trivial optimization (goto full directly)
http://www.benjaminnevarez.com/2012/04/more-undocumented-query-optimizer-trace-flags/
*/

USE Adventureworks
DBCC TRACEON (3604)
GO
/*Medan vissa sp�rningsflaggor skickar information till en loggfil eller till en 
filstr�m, g�r TRACEON (3604) att information visas direkt i klientens f�nster 
(t.ex. Resultatf�nstret i SQL Server Management Studio).*/



SELECT d.CarrierTrackingNumber
FROM Sales.SalesOrderDetail AS d
WHERE OrderQty = 34
OPTION (RECOMPILE, QUERYTRACEON 8605)--8605: Logical query Tree

SELECT d.CarrierTrackingNumber
FROM Sales.SalesOrderDetail AS d
WHERE OrderQty = 34
OPTION (RECOMPILE, QUERYTRACEON 8606);--8606: Additional logical trees (input tree, simplified tree, join-collapsed tree, tree before project normalization, and tree after project normalization)


SELECT d.CarrierTrackingNumber
FROM Sales.SalesOrderDetail AS d
WHERE OrderQty = 34
OPTION (RECOMPILE, QUERYTRACEON 8607)--8607: Optimization output tree

SELECT d.CarrierTrackingNumber
FROM Sales.SalesOrderDetail AS d
WHERE OrderQty = 34
OPTION (RECOMPILE, QUERYTRACEON 2372);--2372: Memory utilization i antalet sidor

SELECT d.CarrierTrackingNumber
FROM Sales.SalesOrderDetail AS d
WHERE OrderQty = 34
OPTION (RECOMPILE, QUERYTRACEON 2373);--2373: More memory utilization

SELECT d.CarrierTrackingNumber
FROM Sales.SalesOrderDetail AS d
WHERE OrderQty = 34
OPTION (RECOMPILE, QUERYTRACEON 8675);--8675: Info about the various phases


