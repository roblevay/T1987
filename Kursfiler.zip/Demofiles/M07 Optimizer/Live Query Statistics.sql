--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.

--K�r denna fr�n SSMS 2016 eller senare
USE AdventureworksDW
GO

--Verifiera att inga columnstore index p� FactResellerSalesXL
EXEC sp_indexinfo 'FactResellerSalesXL'
DROP INDEX IF EXISTS x3 ON FactResellerSalesXL
DROP INDEX IF EXISTS x ON FactResellerSalesXL


--Sl� p� live query statistics


--Se till att "det g�r l�ngsamt", sl� av batch mode on rowstore
ALTER DATABASE CURRENT SET COMPATIBILITY_LEVEL = 150
ALTER DATABASE CURRENT SET COMPATIBILITY_LEVEL = 140

ALTER DATABASE SCOPED CONFIGURATION SET BATCH_MODE_ON_ROWSTORE = OFF

--Aktivera "Live Query statistics"

--En fr�ga som g�r p� nolltid
SELECT * 
FROM FactResellerSales AS s 
WHERE s.CurrencyKey = 19
ORDER BY SalesAmount

SET STATISTICS TIME ON


--En fr�ga som tar n�n minut, 1.06
SELECT
    SUM(s.OrderQuantity * s.UnitPrice) AS TotalSales,
    COUNT(DISTINCT s.CurrencyKey) AS DistinctCurrencies,
    COUNT(s.Freight) AS FreightCount,
    COUNT(p.EnglishProductName) AS ProductNameCount,
    COUNT(t.SalesTerritoryCountry) AS TerritoryCountryCount,
    psc.EnglishProductSubcategoryName,
    t.SalesTerritoryCountry,
    d.CalendarYear
FROM FactResellerSalesXL AS s
    INNER JOIN DimDate AS d ON s.OrderDateKey = d.DateKey
    INNER JOIN DimProduct AS p ON s.ProductKey = p.ProductKey
    INNER JOIN DimSalesTerritory AS t ON s.SalesTerritoryKey = t.SalesTerritoryKey
    INNER JOIN DimProductSubcategory AS psc ON p.ProductSubcategoryKey = psc.ProductSubcategoryKey
GROUP BY psc.EnglishProductSubcategoryName, d.CalendarYear, t.SalesTerritoryCountry
ORDER BY d.CalendarYear DESC
OPTION (MAXDOP 4, RECOMPILE);



--Titta p� fliken medan fr�gan exekverar
--Notera att den g�r p� estimat



--Visa under tiden Activity Monitor

--Vi kan ocks� h�mta plan f�r exekverande fr�ga via nedan
--K�r resultatet fr�n annat f�nster
SELECT CONCAT('SELECT * FROM sys.dm_exec_query_statistics_xml(' , @@SPID, ')')


/*Inget mer i denna demo

--F�r att se live:
-- Den som k�r fr�gan har n�gon av
--   SET STATISTICS XML ON
--   SET STATISTICS PROFILE ON
-- XE trace som f�ngar query_post_execution_showplan, det kostar!
-- Lightweight Profiling p�slagen, med
--   TF 7412 (det troligen b�sta alternativet)
--   XE trace som f�ngar query_thread_profile

--Notera att lightweight profiling �r p�slaget per default i 2019
--Kan sl� av p� databasniv� med LIGHTWEIGHT_QUERY_PROFILING

SELECT * FROM sys.database_scoped_configurations
WHERE name = 'LIGHTWEIGHT_QUERY_PROFILING'

ALTER DATABASE SCOPED CONFIGURATION SET LIGHTWEIGHT_QUERY_PROFILING = OFF

--�terst�ll
ALTER DATABASE SCOPED CONFIGURATION SET LIGHTWEIGHT_QUERY_PROFILING = ON

--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

--Vi vill kunna se faktisk plan f�r senaste exekveringen av denna plan
SELECT * FROM sys.database_scoped_configurations
WHERE name = 'LAST_QUERY_PLAN_STATS'

ALTER DATABASE SCOPED CONFIGURATION SET LAST_QUERY_PLAN_STATS = ON

DBCC FREEPROCCACHE

--K�r query igen

SELECT * 
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle)

--Senaste actual plan f�r "dom flesta" fr�gor

SELECT qps.* 
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS st
CROSS APPLY sys.dm_exec_query_plan_stats(plan_handle) AS qps; 
