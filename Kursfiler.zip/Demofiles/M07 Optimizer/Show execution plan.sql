--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.


USE Adventureworks

--Gammalmodig, bara operatorerna ("plan shape")
SET SHOWPLAN_TEXT ON
SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = 34 
SET SHOWPLAN_TEXT OFF

--Gammalmodig, operatorer och kostnad
SET SHOWPLAN_ALL ON
SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = 34 
SET SHOWPLAN_ALL OFF

--Gammamodig, exekvering och faktisk plan
SET STATISTICS PROFILE ON
SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = 34 
SET STATISTICS PROFILE OFF

--Estimerad plan som XML
SET SHOWPLAN_XML ON
SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = 34 
SET SHOWPLAN_XML OFF
--SSMS k�nner igen XML, att det �r exekveringsplan. Klicka p� XMLen.

--Faktisk plan som XML
SET STATISTICS XML ON
SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = 34 
SET STATISTICS XML OFF

--Display estimated execution plan
SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = 34 

--Include actual execution plan
SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = 34 

--Pilarna mellan operatorer finns inte i XML, genereras av SSMS
--Estimated plan:	Rader ut fr�n operator
--Actual plan:		Rader l�sta av operator

--Titta g�rna p� tiden:
--Row mode ackumulerar
--Batch mode ackumulerar inte, f�rr�n man �verg�r till row-mode
--Trace flagga som i 2022 g�r att row mode inte ackumulerar: DBCC TRACEON (7418, -1);

--Properties p� operator, Actual Time statistics

--Tool-tip
--Properties
--Save as , open
--Paste the plan https://www.brentozar.com/pastetheplan/
--SQL SentryOne plan explorer (gratis)

--Arbete som g�rs av egna scalar functions syns ej i planen
--Tips om scalar functions, som kan vara riktiga prestandad�dare
--Se ScalarFnPerf.sql
