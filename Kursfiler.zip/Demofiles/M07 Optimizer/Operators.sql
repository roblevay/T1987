--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

-----------------------------------------------------------------------------------------------------------------------------------------------------------
--Vanliga operatorer i exekveringsplaner

--Dokumentationen:
-- https://docs.microsoft.com/en-us/sql/relational-databases/showplan-logical-and-physical-operators-reference?view=sql-server-ver15

--Gratis bok om exekveringsplaner:
-- https://www.red-gate.com/products/dba/sql-monitor/entrypage/execution-plans

--The SQL Server Execution Plan Reference
-- https://sqlserverfast.com/epr/


USE Adventureworks

SET STATISTICS IO ON

-----------------------------------------------------------------------------------------------------------------
--Hitta datat
-----------------------------------------------------------------------------------------------------------------

--Table Scan, bara f�r heap
EXEC sp_indexinfo 'DatabaseLog'
SELECT * FROM dbo.DatabaseLog
SELECT * FROM dbo.DatabaseLog WHERE Event = 'CREATE_XML_SCHEMA_COLLECTION'


--CL IX scan
EXEC sp_indexinfo 'Person'
SELECT * FROM Person.Person

--CL IX Seek
SELECT * FROM Person.Person 
WHERE BusinessEntityId = 12;

--Sortera p� CL key, ingen SORT i planen
SELECT * FROM Person.Person 
WHERE BusinessEntityId BETWEEN 12 AND 27
ORDER BY BusinessEntityID DESC

--Sortera p� annan kolumn, nu har vi SORT i planen
SELECT * FROM Person.Person 
WHERE BusinessEntityId BETWEEN 12 AND 27
ORDER BY FirstName


--Non clustered index seek
EXEC sp_indexinfo 'Person'

CREATE INDEX Person_FirstName ON Person.Person(FirstName) 

--Enable index om disable
ALTER INDEX Person_FirstName ON Person.Person REBUILD

--Key lookup (klustrad tabell)
SELECT * FROM Person.Person 
WHERE FirstName = 'James'

--Indexet t�cker fr�gan, inga lookups
SELECT FirstName FROM Person.Person 
WHERE FirstName = 'James'

--Rid lookup (heap tabell)
SELECT * FROM dbo.DatabaseLog WHERE DatabaseLogID = 21


--F�r column-index finns bara scan
SELECT * FROM AdventureworksDW.dbo.FactResellerSalesXL_CCI AS f
WHERE f.DiscountAmount = 45

--Rowgroup/segment eliminering, strunta i denna
/*
SET STATISTICS IO ON
SELECT * FROM AdventureworksDW.dbo.FactResellerSalesXL_CCI AS f
WHERE f.OrderDate = '2005-12-05'
*/


-----------------------------------------------------------------------------------------------------------------
-- Join typer
-----------------------------------------------------------------------------------------------------------------

--Loop join
SELECT od.LineTotal, oh.BillToAddressId, od.ModifiedDate
FROM Sales.SalesOrderDetail AS od
 INNER JOIN Sales.SalesOrderHeader AS oh
  ON od.SalesOrderID = oh.SalesOrderID
WHERE od.LineTotal = 2039.994000

-- Merge join
SELECT od.LineTotal, oh.BillToAddressId, od.ModifiedDate
FROM Sales.SalesOrderDetail AS od
 INNER JOIN Sales.SalesOrderHeader AS oh
  ON od.SalesOrderID = oh.SalesOrderID
WHERE oh.SubTotal > 3000


-- Hash join, samt join med mer �n 2 tabeller (join inputs)
SELECT c.CustomerID
FROM Sales.SalesOrderDetail AS od
 INNER JOIN Sales.SalesOrderHeader AS oh  ON od.SalesOrderID = oh.SalesOrderID
 INNER JOIN Sales.Customer AS c ON oh.CustomerID = c.CustomerID

 
-----------------------------------------------------------------------------------------------------------------
-- Row mode kontra batch mode
-----------------------------------------------------------------------------------------------------------------

USE AdventureworksDW

ALTER DATABASE CURRENT SET COMPATIBILITY_LEVEL = 150

--Kolla att Batch Mode anv�nds
ALTER DATABASE SCOPED CONFIGURATION SET BATCH_MODE_ON_ROWSTORE = ON;

--Notera batch mode f�r operatorerna
SELECT
SUM(s.OrderQuantity * s.UnitPrice)
,psc.EnglishProductSubcategoryName
,t.SalesTerritoryCountry
,d.CalendarYear
FROM FactResellerSalesXL AS s
 INNER JOIN DimDate AS d ON s.OrderDateKey = d.DateKey
 INNER JOIN DimProduct AS p ON s.ProductKey = p.ProductKey
 INNER JOIN DimSalesTerritory AS t ON s.SalesTerritoryKey = t.SalesTerritoryKey
 INNER JOIN DimProductSubcategory AS psc ON p.ProductSubcategoryKey = psc.ProductSubcategoryKey
 INNER JOIN DimProductCategory AS pc ON psc.ProductCategoryKey = pc.ProductCategoryKey
 INNER JOIN DimReseller AS r ON r.ResellerKey = s.ResellerKey
GROUP BY psc.EnglishProductSubcategoryName, d.CalendarYear, t.SalesTerritoryCountry
OPTION (RECOMPILE)

--Notera v�ntestatistik f�r denna session
SELECT * 
FROM sys.dm_exec_session_wait_stats
WHERE session_id = @@SPID
ORDER BY wait_time_ms DESC

--HT-operatorerna f�r vi vid batch mode hash-operatorer
--Jmf CXPACKET f�r "vanlig parallellism".
--Se https://forrestmcdaniel.com/2020/08/12/ht-waits-explained-and-animated/


-----------------------------------------------------------------------------------------------------------------
--Optimizer hints (s�k i BOL p� nedan)
-- Table hints https://docs.microsoft.com/en-us/sql/t-sql/queries/hints-transact-sql-table
-- Join hints
-- Query hints
-----------------------------------------------------------------------------------------------------------------

USE Adventureworks


SELECT c.CustomerID
FROM Sales.SalesOrderDetail AS od --WITH(INDEX(x))									--Table hint
 INNER JOIN Sales.SalesOrderHeader AS oh  ON od.SalesOrderID = oh.SalesOrderID
 INNER LOOP JOIN Sales.Customer AS c ON oh.CustomerID = c.CustomerID				--Join hint, tvingar join ordninggen som en f�ljdeffekt HASH, LOOP, MERGE
OPTION (MAXDOP 1)																--Query hint
GO

--Ex fast hint
DROP TABLE IF EXISTS #x
SELECT *
INTO #x
FROM Sales.SalesOrderDetail AS od

SELECT * FROM #x

CREATE INDEX x ON #x(OrderQty)

SELECT * FROM #x ORDER BY OrderQty 
SELECT * FROM #x ORDER BY OrderQty OPTION (FAST 100)
--SQL Server prioriterar att snabbt returnera de f�rsta 100 raderna snarare �n 
--att optimera f�r att bearbeta hela fr�gan p� b�sta s�tt. 
--Detta kan leda till snabbare initiala resultat men s�mre totalprestanda.

-----------------------------------------------------------------------------------------------------------------
--GROUP BY
-----------------------------------------------------------------------------------------------------------------
DROP INDEX IF EXISTS x ON Sales.SalesOrderDetail

SELECT * FROM Sales.SalesOrderDetail

--Stream aggregate (sortering f�rst)
SELECT OrderQty, SUM(UnitPrice)
FROM Sales.SalesOrderDetail
WHERE UnitPriceDiscount = 0.05
GROUP BY OrderQty

--Hash aggregate. Notera raderna i "slumpvis" ordning utan ORDER BY
SELECT OrderQty, SUM(UnitPrice)
FROM Sales.SalesOrderDetail
GROUP BY OrderQty

--Hash aggregate, f�ljt av sort.
SELECT OrderQty, SUM(UnitPrice)
FROM Sales.SalesOrderDetail
GROUP BY OrderQty
ORDER BY OrderQty



-----------------------------------------------------------------------------------------------------------------
--�ven modifierande kommandon har exekveringsplaner
-----------------------------------------------------------------------------------------------------------------
--Estimated plan (actual funkar ej)
DELETE FROM Person.Address
WHERE AddressID = 52;
--Varf�r s� komplex?
--Referensintegritet, triggers, index

-----------------------------------------------------------------------------------------------------------------
--Parallellisering
-----------------------------------------------------------------------------------------------------------------
SELECT * FROM Sales.SalesOrderDetail ORDER BY OrderQty
SELECT * FROM Sales.SalesOrderDetail ORDER BY OrderQty OPTION(MAXDOP 1)
--sp_configure 'max degree of parallelism'
--sp_configure 'cost threshold for parallelism', 11 RECONFIGURE
DROP INDEX x ON Sales.SalesOrderDetail

SELECT * FROM sys.dm_os_wait_stats
WHERE wait_type LIKE 'CXP%'

