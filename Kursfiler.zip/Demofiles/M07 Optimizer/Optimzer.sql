--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

USE Adventureworks
DBCC TRACEON (3604)

/*Medan vissa sp�rningsflaggor skickar information till en loggfil eller till en 
filstr�m, g�r TRACEON (3604) att information visas direkt i klientens f�nster 
(t.ex. Resultatf�nstret i SQL Server Management Studio).*/
--------------------------------------------------------------------------------------------------------------------------
--Simplification

--FK tabell eliminerad. Vi accessar ingen kolumn d�rifr�n, och DISTINCT.
SELECT DISTINCT c.CustomerID, c.AccountNumber--, h.Freight
FROM Sales.Customer AS c
LEFT OUTER JOIN Sales.SalesOrderHeader AS h ON c.CustomerID = h.CustomerID
OPTION (RECOMPILE, QUERYTRACEON 8606);--8606: Additional logical trees (input tree, simplified tree, join-collapsed tree, tree before project normalization, and tree after project normalization)

SET STATISTICS TIME ON

--PK tabell eliminerad. Vi acessar ingen kolumn d�rifr�n.
SELECT h.Freight, h.CustomerID, h.CustomerID
FROM Sales.Customer AS c
RIGHT OUTER JOIN Sales.SalesOrderHeader AS h ON c.CustomerID = h.CustomerID

SET STATISTICS TIME OFF

--------------------------------------------------------------------------------------------------------------------------
--Simplification
--Accessar ingen tabell alls. CHECK constraint som �r trusted finns
SELECT * FROM HumanResources.Employee WHERE SickLeaveHours = 500

--H�r �r v�r CHECK constraint
SELECT is_not_trusted, definition 
FROM sys.check_constraints 
WHERE name = 'CK_Employee_SickLeaveHours'

--------------------------------------------------------------------------------------------------------------------------
--Trivial plan
SELECT * FROM HumanResources.Employee AS e WHERE e.BusinessEntityId = 4
--Actual plan, SELECT, Properties, MemoryGrantInfo, OptimizationLevel

SELECT * FROM HumanResources.Employee AS e WHERE e.OrganizationLevel = 4
--Actual plan, SELECT, Properties, MemoryGrantInfo, OptimizationLevel
































--------------------------------------------------------------------------------------------------------------------------
--Transformation Rules
--Vi ska se tranformeringar som den g�r f�r en query
--Vi tar en f�re och en efterbild fr�n sys.dm_exec_query_transformation_stats
--D�remellan k�r vi en query


DROP TABLE IF EXISTS #transformation_stats_before_query_execution;
DROP TABLE IF EXISTS #transformation_stats_after_query_execution;
DROP TABLE IF EXISTS #result;

--F�re-bild p� transformeringsstatistik
SELECT *
INTO #transformation_stats_before_query_execution
FROM sys.dm_exec_query_transformation_stats;

--V�r fr�ga
SELECT pp.ProductID, Count(*) ProductCount 
INTO #result
FROM Production.Product pp 
 INNER JOIN Sales.SalesOrderDetail ss ON pp.ProductID=ss.ProductID
WHERE ss.OrderQty > 10
GROUP BY pp.ProductID
OPTION (RECOMPILE);

--Efter-bild p� transformeringsstatistik
SELECT *
INTO #transformation_stats_after_query_execution
FROM sys.dm_exec_query_transformation_stats;

SELECT * FROM #transformation_stats_after_query_execution WHERE succeeded > 0
EXCEPT
SELECT * FROM #transformation_stats_before_query_execution

