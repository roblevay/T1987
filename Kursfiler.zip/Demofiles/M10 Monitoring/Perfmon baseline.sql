--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Vi ska f�nga perfmonr�knare f�r att ha en baseline

SELECT * FROM sys.dm_os_performance_counters


--Tips vad g�ller hur tolka r�knare:
SELECT object_name,counter_name,instance_name,cntr_value,cntr_type,
CASE 
         WHEN cntr_type IN (65792, 65536) THEN 'Absolute Meaning' 
         WHEN cntr_type = 272696576 THEN 'Per Second counter and is Cumulative in Nature'
         when cntr_type IN (1073874176, 537003264) THEN 'Bulk Counter. To get correct value, this value needs to be divided by Base Counter value'
         ELSE CAST(cntr_type AS varchar(1000))
END AS counter_comments
FROM sys.dm_os_performance_counters 
WHERE cntr_type NOT IN (1073939712)

-- Ett part artiklar f�r att tolka cntr_type:
-- https://blogs.msdn.microsoft.com/psssql/2013/09/23/interpreting-the-counter-values-from-sys-dm_os_performance_counters/
-- https://www.sqlshack.com/troubleshooting-sql-server-issues-sys-dm_os_performance_counters/

------------------------------------------------------------------------------------------------------------------------------------
--Skapa databasen
------------------------------------------------------------------------------------------------------------------------------------

USE master
GO

IF (DB_ID('Baseline') IS NOT NULL)
BEGIN
	ALTER DATABASE baseline SET SINGLE_USER WITH ROLLBACK IMMEDIATE
	DROP DATABASE baseline
END
GO

CREATE DATABASE Baseline
 ON  PRIMARY 
( NAME = 'Baseline_data', FILENAME = 'R:\SqlData\a\Baseline_data.mdf' , SIZE = 20MB , FILEGROWTH = 20MB )
 LOG ON 
( NAME = 'Baseline_log', FILENAME = 'R:\SqlData\Baseline_log.ldf' , SIZE = 20MB , FILEGROWTH = 20MB )
GO

------------------------------------------------------------------------------------------------------------------------------------
--Skapa tabellerna vi ska logga till
------------------------------------------------------------------------------------------------------------------------------------

USE Baseline

DROP TABLE IF EXISTS PerfCountersData
DROP TABLE IF EXISTS PerfCounters

CREATE TABLE PerfCounters (
 CounterID smallint IDENTITY NOT NULL CONSTRAINT PK_PerfCounters PRIMARY KEY
,ObjectName varchar(100)
,CounterName varchar(100)
,InstanceName varchar(100)
,CounterType int NOT NULL
)
GO

CREATE TABLE PerfCountersData (
 CounterID smallint CONSTRAINT FK_PerfCountersData_PerfCounters FOREIGN KEY REFERENCES PerfCounters(CounterID)
,LogDt datetime2(0) NOT NULL
,Value real NOT NULL
,CONSTRAINT PK_PerfCountersData PRIMARY KEY (CounterID, LogDt)
)

USE master

------------------------------------------------------------------------------------------------------------------------------------
--Starta Agent!
------------------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------------------
--Schemal�gg nedan i ett Agent job
--Jobstegstyp:	TSQL
--Databas:		BaseLine
--Till exempel var 5:e minut
--F�r demo skull, k�r var 10:e sekund
------------------------------------------------------------------------------------------------------------------------------------

--F�nga perfmonv�rden till temp tabell
SELECT object_name, counter_name, instance_name, cntr_type, cntr_value, SYSDATETIME() AS capture_dt
INTO #theCapture
FROM sys.dm_os_performance_counters
WHERE counter_name IN (
	'Page life expectancy', 'Lazy writes/sec', 'Page reads/sec', 'Page writes/sec','Free Pages',
	'Free list stalls/sec','User Connections', 'Lock Waits/sec', 'Number of Deadlocks/sec',
	'Transactions/sec', 'Forwarded Records/sec', 'Index Searches/sec', 'Full Scans/sec',
	'Batch Requests/sec','SQL Compilations/sec', 'SQL Re-Compilations/sec', 'Total Server Memory (KB)',
	'Target Server Memory (KB)', 'Latch Waits/sec', 'CPU usage %', 'CPU usage % base', 'Memory Grants Pending'
	)


--L�gg till till tabellen med r�knare de som inte fanns d�r sen f�rut
MERGE INTO PerfCounters AS p
USING #theCapture AS c 
 ON  p.ObjectName = c.object_name
 AND p.CounterName = c.counter_name
 AND p.InstanceName = c.instance_name
WHEN NOT MATCHED BY TARGET THEN
    INSERT (ObjectName, CounterName, InstanceName, CounterType)
        VALUES (object_name, counter_name, instance_name, cntr_type);

--L�gg till sj�lva loggade datat
INSERT INTO PerfCountersData (CounterID, LogDt, Value)
SELECT CounterID, capture_dt, cntr_value FROM #theCapture AS c 
 INNER JOIN PerfCounters AS p
  ON c.object_name = p.ObjectName
  AND c.counter_name = p.CounterName
  AND c.instance_name = p.InstanceName
GO
------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------------------
--Generera aktivitet
------------------------------------------------------------------------------------------------------------------------------------
--Exekvera usp_RandomQ i StackOverflow genom SqlQueryStress
EXEC usp_RandomQ
--30 itereringar
--5 tr�dar
--Ger ca 1:30 i tid



------------------------------------------------------------------------------------------------------------------------------------
--Titta p� lasten
------------------------------------------------------------------------------------------------------------------------------------
USE Baseline
GO

CREATE OR ALTER VIEW vPerfCountersData
AS
SELECT c.ObjectName, c.CounterName, c.InstanceName, c.CounterType, d.LogDt, d.Value
FROM PerfCounters AS c INNER JOIN PerfCountersData AS d ON c.CounterID = d.CounterID
GO

--Obs: justera instansnamnet (SQLServer f�r defaultinstans)

--G�r inte s� h�r!
SELECT * FROM vPerfCountersData AS d
WHERE d.CounterName like '%Page reads/sec%'
ORDER BY LogDt

--CPU
SELECT CPUCount.ObjectName, CPUCount.CounterName, CPUCount.InstanceName, CPUCount.LogDt,
CASE 
 WHEN CPUBase.Value = 0 THEN 0
 ELSE (CAST(CPUCount.Value AS FLOAT) / CPUBase.Value) * 100
END AS cntr_Value
FROM (SELECT * FROM vPerfCountersData WHERE ObjectName LIKE '%Resource Pool Stats' AND CounterName = 'CPU usage %' AND InstanceName = 'default') AS CPUCount
 INNER JOIN (SELECT * FROM vPerfCountersData WHERE ObjectName LIKE '%Resource Pool Stats' AND CounterName = 'CPU usage % base' AND InstanceName = 'default' ) AS CPUBase
  ON CPUCount.LogDt = CPUBase.LogDt
ORDER BY CPUCount.LogDt


--Minne
SELECT ObjectName, CounterName, InstanceName, LogDt, Value/1024 as MemoryUsageMB
FROM vPerfCountersData 
WHERE CounterName = 'Total Server Memory (KB)'
ORDER BY LogDt


--Transaktionsgenomstr�mmning, justera �ven databasnamnet
--Notera hur vi kalkylerar per sekund (kursens exempel g�r inte det)
SELECT 
ObjectName, CounterName, InstanceName, LogDt, Value
,(Value - LAG(Value, 1, NULL) OVER(ORDER BY LogDt)) / (DATEDIFF(SECOND, LAG(LogDt, 1, NULL) OVER(ORDER BY LogDt), LogDt)) AS TranPerSec	--Justerat f�r per sekund
--*****Nedanst�ende �r bara f�r att visa hur vi r�knar ut /sec v�rdet...
--,LAG(Value, 1, NULL) OVER(ORDER BY LogDt)									AS preRowTran	--F�reg�ende rads v�rde
--,Value - LAG(Value, 1, NULL) OVER(ORDER BY LogDt)							AS DiffTran		--Differans
--,DATEDIFF(SECOND, LAG(LogDt, 1, NULL) OVER(ORDER BY LogDt), LogDt)	AS SecDiff			--Hur m�nga sekunder sen sist
--*****Hit
FROM vPerfCountersData
WHERE CounterName = 'Transactions/sec' AND InstanceName = '_Total'
ORDER BY LogDt


--Pages l�sta per sekund
SELECT 
ObjectName, CounterName, InstanceName, LogDt, Value
,(Value - LAG(Value, 1, NULL) OVER(ORDER BY LogDt)) / (DATEDIFF(SECOND, LAG(LogDt, 1, NULL) OVER(ORDER BY LogDt), LogDt)) AS PagesPerSec	--Justerat f�r per sekund
FROM vPerfCountersData
WHERE CounterName like '%Page reads/sec%'
ORDER BY LogDt

------------------------------------------------------------------------------------------------------------------------------------
--Hur stor �r tabellen?
------------------------------------------------------------------------------------------------------------------------------------

--Tidsspann
SELECT MIN(p.LogDt), MAX(p.LogDt)
FROM PerfCountersData AS p

SELECT * FROM PerfCountersData

--Skala nu upp storleken f�r s� l�ng tid ni vill ha...
EXEC sp_tableinfo 

--Vilka r�knare lade vi till?
SELECT * FROM PerfCounters
--64 stycken...

------------------------------------------------------------------------------------------------------------------------------------
--St�da
------------------------------------------------------------------------------------------------------------------------------------

--Ta bort jobbet

USE master
GO



IF (DB_ID('Baseline') IS NOT NULL)
BEGIN
	ALTER DATABASE Baseline SET SINGLE_USER WITH ROLLBACK IMMEDIATE
	DROP DATABASE Baseline
END



