--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.


--J�mf�r nedan fr�ga med olika compat levels
USE AdventureworksDW
ALTER DATABASE current SET COMPATIBILITY_LEVEL = 140 --2017
ALTER DATABASE current SET COMPATIBILITY_LEVEL = 150 --2019
ALTER DATABASE current SET COMPATIBILITY_LEVEL = 160 --2022, funkar inte om inte SQL Server 2022

SELECT
 SUM(s.OrderQuantity * s.UnitPrice)
,COUNT(DISTINCT s.CurrencyKey)
,COUNT(s.Freight)
,COUNT(p.EnglishProductName)
,COUNT(t.SalesTerritoryCountry)
,COUNT(pc.EnglishProductCategoryName)
,COUNT(c.CurrencyName)
,SUM(r.AnnualRevenue)
,psc.EnglishProductSubcategoryName
,t.SalesTerritoryCountry
,d.CalendarYear
FROM FactResellerSalesXL AS s
 INNER JOIN DimDate AS d ON s.OrderDateKey = d.DateKey
 INNER JOIN DimProduct AS p ON s.ProductKey = p.ProductKey
 INNER JOIN DimSalesTerritory AS t ON s.SalesTerritoryKey = t.SalesTerritoryKey
 INNER JOIN DimProductSubcategory AS psc ON p.ProductSubcategoryKey = psc.ProductSubcategoryKey
 INNER JOIN DimProductCategory AS pc ON psc.ProductCategoryKey = pc.ProductCategoryKey
 INNER JOIN DimCurrency AS c ON c.CurrencyKey = s.CurrencyKey
 INNER JOIN DimReseller AS r ON r.ResellerKey = s.ResellerKey
GROUP BY psc.EnglishProductSubcategoryName, d.CalendarYear, t.SalesTerritoryCountry
ORDER BY CalendarYear DESC



---------------------------------------------------------------------------
--Optimizer fixes
---------------------------------------------------------------------------
USE Adventureworks

--Trace flag 4199, samlingsflagga f�r all fixar

--fr�n och med 2016 (med compat level 2016)
-- �r de fixar som fanns vid RTM p�

--P� db niv� be om fixar efter RTM
ALTER DATABASE SCOPED CONFIGURATION SET QUERY_OPTIMIZER_HOTFIXES = ON

--P� query niv� med hint
SELECT * FROM Sales.SalesOrderDetail 
ORDER BY OrderQty
OPTION (USE HINT ('ENABLE_QUERY_OPTIMIZER_HOTFIXES'))



---------------------------------------------------------------------------
--CE, Cardinality Estimator.
--Hur m�nga rader ut fr�n en operator i en exekveringsplan
---------------------------------------------------------------------------
USE Adventureworks

SELECT * FROM Sales.SalesOrderDetail AS s
WHERE s.OrderQty = 14
ORDER BY OrderQty

CREATE INDEX x ON Sales.SalesOrderDetail(OrderQty)

SELECT name, d.compatibility_level FROM sys.databases AS d

--Exekveringsplanen, den yttersta (SELECT l�ngst till v�nster) operatorn visar CEn

--Kompatibilitetsniv�n p� databasen p�verkar vilken "CE" vi f�r.
ALTER DATABASE Adventureworks SET COMPATIBILITY_LEVEL = 110 --2012 -> 70
ALTER DATABASE Adventureworks SET COMPATIBILITY_LEVEL = 120 --2014
ALTER DATABASE Adventureworks SET COMPATIBILITY_LEVEL = 130 --2016
ALTER DATABASE Adventureworks SET COMPATIBILITY_LEVEL = 140 --2017
ALTER DATABASE Adventureworks SET COMPATIBILITY_LEVEL = 150 --2019


--Kan s�tta till 70 trots h�gre kompatibilitetsniv� p� databasen (inst�llningen kom i 2016)
ALTER DATABASE SCOPED CONFIGURATION SET LEGACY_CARDINALITY_ESTIMATION = ON
ALTER DATABASE SCOPED CONFIGURATION SET LEGACY_CARDINALITY_ESTIMATION = OFF

--Fr�n och med 2016 kan ange som query hint att k�ra CE 70
SELECT * FROM Sales.SalesOrderDetail 
ORDER BY OrderQty 
OPTION (USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'))

--Traceflagga 9481 tvingar CE 70
SELECT * FROM Sales.SalesOrderDetail 
ORDER BY OrderQty
OPTION (QUERYTRACEON 9481)

--Traceflagga 2312 tvingar fram 120 CE om db compat �r �ldre 
SELECT * FROM Sales.SalesOrderDetail 
ORDER BY OrderQty
OPTION (QUERYTRACEON 2312)

--Fr�n och med 2017 CU 10 kan man ange "vilken optimizer" med hint. 
--G�r override p� db compat level inst�llningen.
SELECT * FROM Sales.SalesOrderDetail 
ORDER BY OrderQty
OPTION (USE HINT ('QUERY_OPTIMIZER_COMPATIBILITY_LEVEL_140'))

--Se denna f�r diskussion om CE
-- https://docs.microsoft.com/en-us/sql/relational-databases/performance/cardinality-estimation-sql-server


---------------------------------------------------------------------------
--OE, Optimizer Enhancements
---------------------------------------------------------------------------
--Ny funktionalitet i optimizern kr�ver ofta r�tt compat level
--Ex batch mode on rowstore kr�ver compat level 2019
