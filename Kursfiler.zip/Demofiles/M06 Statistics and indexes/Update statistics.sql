--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.


USE Adventureworks

----------------------------------------------------------------------------------------------------
--Estimerar optimizer r�tt?

SELECT * FROM Person.Person

EXEC sp_indexinfo 'Person'

ALTER INDEX IX_Person_LastName_FirstName_MiddleName ON Person.Person DISABLE

SET STATISTICS IO ON

--Klockrent
SELECT FirstName, LastName FROM Person.Person WHERE FirstName = 'Abigail'

--Klockrent
SELECT FirstName, LastName FROM Person.Person WHERE FirstName = 'Aidan'

--N�ra, men inte exakt (Inte med)
SELECT FirstName, LastName FROM Person.Person WHERE FirstName = 'Adrian'

DBCC SHOW_STATISTICS('Person.Person',Person_FirstName) WITH HISTOGRAM 

SET STATISTICS IO ON

----------------------------------------------------------------------------------------------------
--Flera Aidan �n f�rut, 299 stycken
UPDATE Person.Person SET FirstName = 'Aidan' WHERE FirstName < 'Aidan'

--Antar fortfarande 25
SELECT FirstName, LastName FROM Person.Person WHERE FirstName = 'Aidan' --OPTION (RECOMPILE)

--Statistiken gammal
DBCC SHOW_STATISTICS('Person.Person',Person_FirstName) WITH HISTOGRAM 

----------------------------------------------------------------------------------------------------
--�nnu flera Aidan, 6824 stycken
UPDATE Person.Person SET FirstName = 'Aidan' WHERE FirstName < 'f'

--Antar 6695, faktiskt radantal 6824
SELECT FirstName, LastName FROM Person.Person WHERE FirstName = 'Aidan' OPTION (RECOMPILE)

--Fick uppenbarligen en auto-updatering!

--Updatering efter modifierat: 
 --innan 2016:					20% av raderna
 --2016 med compat level 130:	SQRT(1000*#rader)
 --Ex
 --  Antal rader       tidigare        2016
 --    1 000 000	    200 000      32 000
 --   10 000 000	  2 000 000     100 000
 --1 000 000 000	200 000 000   1 000 000
DECLARE @rows bigint = 10000000
SELECT SQRT(1000*@rows)

--trace flag 2371 ger nya algoritmen

--Statistiken, fr�sch, men inte exakt
DBCC SHOW_STATISTICS('Person.Person',Person_FirstName) WITH HISTOGRAM 

----------------------------------------------------------------------------------------------------
--Uppdatera manuellt

--Default
UPDATE STATISTICS Person.Person
DBCC SHOW_STATISTICS('Person.Person',Person_FirstName) WITH HISTOGRAM 
--Samma som f�rut. Samplar om beh�ver l�sa > 8 MB

--G�r den mer exakt
UPDATE STATISTICS Person.Person WITH FULLSCAN
DBCC SHOW_STATISTICS('Person.Person',Person_FirstName) WITH HISTOGRAM 

--Verifiera estimeringen
SELECT FirstName, LastName FROM Person.Person WHERE FirstName = 'Aidan' OPTION (RECOMPILE)


EXEC sp_autostats -- Selektivt sl� av databasens auto-updatering.
GO
--Sl� av uppdatering f�r alla index p� tabellen Production.product
EXEC sp_autostats 'Production.Product', 'ON';
GO

GO
EXEC sp_updatestats		-- Uppdatera all statistik i databasen, d�r det har modifierate minst en rad.

--Uppdatering av statistik kan g� parallellt i 2016 (med compat level 130)
-- I 2017 CU3 fick vi MAXDOP hint f�r ovan


--Maintenance planer
-- Uppdaterar all statistik, �ven om det modifierats 0 rader sen sist.

--ola.hallengren.com
--L�gg till job varje morgon som g�r:
EXECUTE dbo.IndexOptimize
@Databases = 'USER_DATABASES',
@FragmentationLow = NULL,
@FragmentationMedium = NULL,
@FragmentationHigh = NULL,
@UpdateStatistics = 'ALL',
@OnlyModifiedStatistics = 'Y',
@LogToTable = 'Y',
@StatisticsSample = 100 --Eller vad ni nu tycker

--Dock kan ny statistik generera nya planer!





--Om man vill lura optimizer vad g�ller antal rader och pages
--dvs den info som man ser via sys.partitions och sys.dm_db_partition_stats
UPDATE STATISTICS Person.Person WITH ROWCOUNT = 50000000, PAGECOUNT = 500000
UPDATE STATISTICS Person.Person Person_FirstName WITH ROWCOUNT = 50000000, PAGECOUNT = 500000
