--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.

----------------------------------------------------------------------------------------------------------------------------
--�terst�ll Adventureworks
----------------------------------------------------------------------------------------------------------------------------
USE master
GO
RESTORE DATABASE Adventureworks FROM DISK='C:\demodatabases\Course_demodatabases\AdventureWorks2014_2019.bak'
WITH REPLACE
,MOVE 'AdventureWorks_Data' TO 'C:\DemoDatabases\DbFiles\a\AdventureWorks_Data.mdf'
,MOVE 'AdventureWorks_Log'  TO 'C:\DemoDatabases\DbFiles\a\AdventureWorks_Log.ldf'


----------------------------------------------------------------------------------------------------
--Vilken statistik finns?

USE Adventureworks

SELECT * 
FROM sys.stats 
WHERE object_id = OBJECT_ID('Sales.SalesOrderDetail')

SELECT * FROM Sales.SalesOrderDetail

CREATE STATISTICS ...

--Det verkar finnas auto-genererad kolumnstatistik
--Vilken kolumn?
DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', '_WA_Sys_00000006_44CA3770')
--Vi kommer att titta mer p� detaljer om statistiken strax...

DROP STATISTICS Sales.SalesOrderDetail._WA_Sys_00000006_44CA3770;


--Finns det statistik p� OrderQty?
DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', 'OrderQty')

--Nedanst�ende fr�ga kommer att skapa kolumnstatistik
SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = 34

--Finns det nu statistik p� OrderQty?
DBCC SHOW_STATISTICS('Sales.SalesOrderDetail', 'OrderQty')

-------------------------------------------------------------------------------------------------
--Vi ska leka med Person.Person

--Skapa index - b�r med sig statistik
CREATE INDEX Person_FirstName ON Person.Person (FirstName)

SELECT * FROM sys.stats WHERE object_id = OBJECT_ID('Person.Person')


SELECT * FROM Person.Person

--Selektivitet?
SELECT FirstName, LastName FROM Person.Person WHERE FirstName = 'Abigail';
--Klockrent

--Notera tre delar i stastistik output
DBCC SHOW_STATISTICS('Person.Person', Person_FirstName)

-------------------------------
--Header
DBCC SHOW_STATISTICS('Person.Person', Person_FirstName) WITH STAT_HEADER 

-------------------------------
--Density
DBCC SHOW_STATISTICS('Person.Person', Person_FirstName) WITH DENSITY_VECTOR

--Hur r�knas den fram?
SELECT COUNT(DISTINCT FirstName) FROM Person.Person
SELECT 1.0/COUNT(DISTINCT FirstName) FROM Person.Person
SELECT FirstName, LastName FROM Person.Person WHERE FirstName = 'Abigail'

--Varf�r finns den? Ibland kan vi ej g� p� histogrammet. Exempel:
DECLARE @f Name = N'Abigail'
SELECT FirstName, LastName FROM Person.Person WHERE FirstName = @f

--N�r vi inte kan g� p� histogrammet, hur kalkyleras?
-- =
--Om densitet finns, anv�nd den.  Om ej
--Innan 2014 (gamla CE)
--Rader i tbl	Est rader	%
--1				1			100
--625			125			20
--10 000		1000		10
--160 000		8000		5
--2 560 000		64000		2
--(returnerade rader) = (rader i tbl) exp(3/4)

--Fr�n och med 2014
--Rader i tbl	Est rader	%
--1				1			100
--625			25			4
--10 000		100			1
--160 000		400			0.25
--2 560 000		1600		0.0625
--(returnerade rader) = roten ur (rader i tbl)

--F�r andra predikat ( >, BETWEEN etc) g�ller h�rdkodade % satser


--Om dessa kolumner finns i index/statistik:
--(a, b, c)

--S� har vi densitet f�r f�ljande kombinationer:
--(a)
--(a, b)
--(a, b, c)

--Histogrammet
DBCC SHOW_STATISTICS('Person.Person',Person_FirstName) WITH HISTOGRAM 

--I 2016 sp1 s� fick vi �ven sys.dm_db_stats_histogram() som alternativ till ovan

--Hur m�nga Abigail? J�mf�r mot histogrammet.
SELECT COUNT(*) FROM Person.Person WHERE FirstName = 'Abigail';


--Skapa egen statistik
CREATE STATISTICS myStats ON Person.Person(FirstName, LastName) WITH FULLSCAN
DBCC SHOW_STATISTICS('Person.Person',myStats) WITH DENSITY_VECTOR 
DBCC SHOW_STATISTICS('Person.Person',myStats) WITH HISTOGRAM 

