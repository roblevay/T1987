--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.


RAISERROR('K�r inte allt!', 20, 1) WITH LOG
GO

--------------------------------------------------------------------------------------------------------------------
--�terst�ll AdventureworksDW
--------------------------------------------------------------------------------------------------------------------

USE master
RESTORE DATABASE [AdventureWorksDW] FROM  DISK = 'C:\demodatabases\Course_demodatabases\AdventureworksDW2016_2019.bak' 
WITH  MOVE 'AdventureWorksDW_Data' TO 'C:\demodatabases\Dbfiles\a\AdventureWorksDW_Data.mdf'
, MOVE 'AdventureWorksDW_Log' TO 'C:\demodatabases\Dbfiles\a\AdventureWorksDW_Log.ldf'
, REPLACE

GO

USE AdventureworksDW
GO

--B�rja med denna
--Hugo Kornelis "lift" http://www.sqlservercentral.com/stairway/121631/

--Niko Neugebauer har m�nga blog poster om CS teknologin
-- https://www.nikoport.com/columnstore/
-- https://github.com/NikoNeugebauer/CISL Columnstore script library

--N�r kom vad, vad g�ller columnstore
-- https://docs.microsoft.com/en-us/sql/relational-databases/indexes/columnstore-indexes-what-s-new
--I korthet:
--2012:		NC, (tabell R/O)
--2014:		CL (f�r CL tabell R/W)
--2016:		R/W oavsett CS ix. 
--			Compression delay
--			Rad ix p� CL CS tabell
--			NC CS med WHERE
--			FK mot CL CS tabell
--2022:		ORDER f�r kolumnindex i syntax n�r man skapar indexet
-- CS Data loading guidance
-- https://docs.microsoft.com/en-us/sql/relational-databases/indexes/columnstore-indexes-data-loading-guidance


-------------------------------------------------------------------------------------------------------------------------
--Exempel p� syntax
DROP TABLE IF EXISTS fp

SELECT * INTO fp FROM FactProductInventory

SELECT TOP(100) * FROM fp

--fp �r nu en heap tabell
EXEC sp_indexinfo fp

--Skapa icke-cklustrat columnstore index (i detta exempel med alla kolumner)
CREATE NONCLUSTERED COLUMNSTORE INDEX Ix_3
ON fp(ProductKey, DateKey, MovementDate, UnitCost, UnitsIn, UnitsOut, UnitsBalance)

--Fortfarande en heap tabell, med icke-klustrat columnstore index
EXEC sp_indexinfo fp

--Ta bort index
DROP INDEX Ix_3 ON fp 

--G�r om tabellen till en klustrad tabell, d�r det klustrade indexet �r ett kolumnindex
CREATE CLUSTERED COLUMNSTORE INDEX ix_4 ON fp 
--Notera, vi anger inga kolumner

--Nu en CS klustrad tabell
EXEC sp_indexinfo fp

-- L�gg till en rad
INSERT INTO fp
VALUES (214, 20071230, '2010-12-31', 9.54, 2, 0, 4);
-------------------------------------------------------------------------------------------------------------------------


-------------------------------------------------------------------------------------------------------------------------
--Studera metadata

--Typer av index i denna databas
SELECT distinct type_desc FROM sys.indexes AS i

--Index p� denna tabell
SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('fp')

--V�ra row-groups
SELECT OBJECT_NAME(object_id) AS table_name,  c.index_id, c.row_group_id, c.state_description, c.total_rows
FROM sys.column_store_row_groups AS c
ORDER BY table_name DESC, row_group_id ASC

-- Alla columnstore (compressed) index pages ligger i en LOB allocation unit
SELECT index_id, rows, data_compression_desc, type_desc, total_pages, partition_number
FROM sys.partitions p
  INNER JOIN sys.allocation_units au ON p.partition_id = au.container_id
WHERE OBJECT_NAME(object_id) = 'fp';
-------------------------------------------------------------------------------------------------------------------------



-------------------------------------------------------------------------------------------------------------------------------
EXEC sp_indexinfo FactResellerSalesXL		--Ej komprimerad		2.4  GB
EXEC sp_indexinfo FactResellerSalesXL_CCI	--Klustrat kolumnindex	0.48 GB

DROP INDEX IF EXISTS x ON FactResellerSalesXL
DROP INDEX IF EXISTS xyz ON FactResellerSalesXL

--Sl� p� actual execution plan
SET STATISTICS IO ON
SET STATISTICS TIME ON


--K�r f�rst med pre-2019 compat level, sedan med h�gre compat level
ALTER DATABASE CURRENT SET COMPATIBILITY_LEVEL = 140
ALTER DATABASE CURRENT SET COMPATIBILITY_LEVEL = 150



--Inga kolumnindex involverade
SELECT
 SUM(s.OrderQuantity * s.UnitPrice)
,COUNT(DISTINCT s.CurrencyKey)
,COUNT(s.Freight)
,COUNT(p.EnglishProductName)
,COUNT(t.SalesTerritoryCountry)
,COUNT(pc.EnglishProductCategoryName)
,psc.EnglishProductSubcategoryName
,t.SalesTerritoryCountry
,d.CalendarYear
FROM FactResellerSalesXL AS s
 INNER JOIN DimDate AS d ON s.OrderDateKey = d.DateKey
 INNER JOIN DimProduct AS p ON s.ProductKey = p.ProductKey
 INNER JOIN DimSalesTerritory AS t ON s.SalesTerritoryKey = t.SalesTerritoryKey
 INNER JOIN DimProductSubcategory AS psc ON p.ProductSubcategoryKey = psc.ProductSubcategoryKey
 INNER JOIN DimProductCategory AS pc ON psc.ProductCategoryKey = pc.ProductCategoryKey
GROUP BY psc.EnglishProductSubcategoryName, d.CalendarYear, t.SalesTerritoryCountry
ORDER BY CalendarYear DESC



--Mot en tabell med Clustered Columnstore Index (CCI)
SELECT
 SUM(s.OrderQuantity * s.UnitPrice)
,COUNT(DISTINCT s.CurrencyKey)
,COUNT(s.Freight)
,COUNT(p.EnglishProductName)
,COUNT(t.SalesTerritoryCountry)
,COUNT(pc.EnglishProductCategoryName)
,psc.EnglishProductSubcategoryName
,t.SalesTerritoryCountry
,d.CalendarYear
FROM FactResellerSalesXL_CCI AS s
 INNER JOIN DimDate AS d ON s.OrderDateKey = d.DateKey
 INNER JOIN DimProduct AS p ON s.ProductKey = p.ProductKey
 INNER JOIN DimSalesTerritory AS t ON s.SalesTerritoryKey = t.SalesTerritoryKey
 INNER JOIN DimProductSubcategory AS psc ON p.ProductSubcategoryKey = psc.ProductSubcategoryKey
 INNER JOIN DimProductCategory AS pc ON psc.ProductCategoryKey = pc.ProductCategoryKey
GROUP BY psc.EnglishProductSubcategoryName, d.CalendarYear, t.SalesTerritoryCountry
ORDER BY CalendarYear DESC

--Fr�n 2019 kan vi f� "batch mode" �ven utan kolumnindex. Kr�ver Enterprise Edition



-------------------------------------------------------------------------------------------------------------------------------
--Meta-data f�r rowgroups, segments etc

--En rad per row-group
SELECT OBJECT_NAME(object_id) AS table_name,  c.index_id, c.row_group_id, c.state_description, c.total_rows
FROM sys.column_store_row_groups AS c
WHERE OBJECT_NAME(c.object_id) = 'FactResellerSalesXL_CCI'
ORDER BY table_name DESC, row_group_id ASC

--Varf�r inte en miljon rader f�r alla utom den som processades sist?
--Parallelliseing. Gissningsvis byggdes detta index p� en maskin med 8 k�rnor.


-- V�ra segment
SELECT s.column_id,  COL_NAME(ic.object_id, ic.column_id) as column_name, count(*) as segment_count, SUM(row_count) AS antal_rader
FROM sys.column_store_segments s 
INNER JOIN sys.partitions p ON s.partition_id = p.partition_id 
LEFT JOIN sys.index_columns ic ON p.object_id = ic.object_id AND p.index_id = ic.index_id AND s.column_id = ic.index_column_id
WHERE OBJECT_NAME(p.object_id) = 'FactResellerSalesXL_CCI'
GROUP BY s.column_id,  COL_NAME(ic.object_id, ic.column_id)
ORDER by s.column_id
GO

--Min och maxv�rde f�r varje segment, etc
CREATE OR ALTER PROC GetSegmentAlignment 
@tablename sysname
AS
SELECT
-- OBJECT_NAME(i.object_id) AS TableName
--,i.name AS IndexName
--,i.type_desc AS IndexType
 COL_NAME(ic.object_id, ic.column_id) as ColumnName
--,p.partition_number
,s.segment_id
,s.min_data_id
,s.max_data_id
,s.row_count
,s.on_disk_size
FROM sys.column_store_segments AS s
INNER JOIN sys.partitions AS p ON p.hobt_id = s.hobt_id
INNER JOIN sys.indexes AS i ON   i.object_id = p.object_id AND  i.index_id = p.index_id
LEFT  JOIN sys.index_columns AS ic ON ic.object_id = i.object_id AND  ic.index_id = i.index_id AND  ic.index_column_id = s.column_id
WHERE OBJECT_NAME(p.object_id) = @tablename
AND ic.column_id IS NOT NULL
ORDER BY   --TableName, IndexName,
           s.column_id, p.partition_number, s.segment_id
GO

--Hur ser det ut?
EXEC GetSegmentAlignment 'FactResellerSalesXL_CCI'
--Varje rowgroup inneh�ller rader fr�n hela datumspannet, i stort sett


/* Stoppa h�r

-------------------------------------------------------------------------------------------------------------------------------
--Indexunderh�ll och m�jlighet till row-group elimination

--Bygg bara om indexet, rakt upp och ner. 2 minuter 35 sek
ALTER INDEX ALL ON FactResellerSalesXL_CCI REBUILD

EXEC GetSegmentAlignment 'FactResellerSalesXL_CCI'
--Ungef�r 8 grupper med f�rre �n 1 mill rader pga 8 k�rnor p� min maskin

--Exempel p� en fr�ga
SELECT Avg(UnitPrice) AS avgUnitPtice, SUM(SalesAmount) AS SumSalesAmt
FROM FactResellerSalesXL_CCI 
WHERE OrderDate >= '2014-03-01' AND OrderDate < '2014-07-01'
--Hur m�nga segment skippades? Inte m�nga.
--Notera antal logical reads (l�s noggrant). Ca 12000 f�r mig.

--T�nk om vi kunde f� MSSQL att l�sa i datumordning n�r det bygger indexet...

--Skapa om col-index will rad-index (med l�mplig nyckel/sortering)
--Skapa nu om rad-index till col-index

--G�r om till klustrat row-store index. 3 minuter.
CREATE CLUSTERED INDEX IndFactResellerSalesXL_CCI ON FactResellerSalesXL_CCI (OrderDate)
WITH DROP_EXISTING

--G�r om till klustrat col-store index. 3 minuter med MAXOP 1.
CREATE CLUSTERED COLUMNSTORE INDEX IndFactResellerSalesXL_CCI ON FactResellerSalesXL_CCI
WITH (DROP_EXISTING = ON, MAXDOP = 1)
--MAXDOP 1 g�r att inte 8 k�rnor parallellt processar sista delm�ngden av datat


EXEC GetSegmentAlignment 'FactResellerSalesXL_CCI'
--Ungef�r 8 grupper med f�rre �n 1 mill rader pga 8 k�rnor p� min maskin


--Blev prestanda f�r fr�gan b�ttre?
SELECT Avg(UnitPrice) AS avgUnitPtice, SUM(SalesAmount) AS SumSalesAmt
FROM FactResellerSalesXL_CCI 
WHERE OrderDate >= '2014-03-01' AND OrderDate < '2014-07-01'
--Nu l�ste den bara ett segment ist�llet f�r 11
--1143 logical reads ist�llet f�r 12000

--I 2022 har vi ORDERED col-store index. 
--Se Columnstore Ordered.sql.

-------------------------------------------------------------------------------------------------------------------------------
--Fr�gor med h�g selektivitet
SELECT TOP(10) * FROM FactResellerSalesXL_CCI AS s

--F�r exemplets skull, ta bort PK (s� att b-tree IX f�rsvinner)
ALTER TABLE FactResellerSalesXL_CCI DROP CONSTRAINT PK_FactResellerSalesXL_CCI_SalesOrderNumber_SalesOrderLineNumber

EXEC sp_indexinfo FactResellerSalesXL		--Ej komprimmerad		2.4  GB
EXEC sp_indexinfo FactResellerSalesXL_CCI	--Klustrat kolumnindex	0.48 GB


SET STATISTICS IO ON

--J�mf�r kostnad
SELECT s.UnitPrice, s.OrderQuantity FROM FactResellerSalesXL AS s WHERE SalesOrderNumber = 'SO100000'
--4 I/O (CL IX Seek)

SELECT s.UnitPrice, s.OrderQuantity FROM FactResellerSalesXL_CCI AS s WHERE SalesOrderNumber = 'SO100000'
--6157 I/O (CS CL IX Scan)

-------------------------------------------------------------------------------------------------------------------------------
--En variant, tabellen �r columnstore
--skapa ett row-store icke-klustrade index p� tabellen som har det klustrade columnstore indexet
CREATE NONCLUSTERED INDEX x2 ON FactResellerSalesXL_CCI(SalesOrderNumber) 

SELECT s.UnitPrice, s.OrderQuantity FROM FactResellerSalesXL_CCI AS s WHERE SalesOrderNumber = 'SO100000'
--1077 I/O
--Intressant att den kan g�ra SEEK trots att col-store inte har "nycklar"
--ColStoreLoc1000 = Scalar Operator(ColStoreLoc1000)
--Ovanst�ende pekar p� r�tt row-group

--Om vi t�cker indexet?
CREATE NONCLUSTERED INDEX x2 ON FactResellerSalesXL_CCI(SalesOrderNumber) INCLUDE(UnitPrice, OrderQuantity)
WITH DROP_EXISTING

SELECT s.UnitPrice, s.OrderQuantity FROM FactResellerSalesXL_CCI AS s WHERE SalesOrderNumber = 'SO100000'
--4 I/O (den r�r inte col-store ix)


--St�da
DROP INDEX x2  ON FactResellerSalesXL_CCI


-------------------------------------------------------------------------------------------------------------------------------
--En annan variant, tabellen �r row-store
--Mer realistiskt exempel f�r en blandmilj� (OLTP)

EXEC sp_indexinfo FactResellerSalesXL

DROP INDEX xyz ON FactResellerSalesXL

--Skapa ett icke-klustrat col-store index p� row-store tabell - f�r v�r "analys/rapport-fr�ga"
CREATE NONCLUSTERED COLUMNSTORE INDEX x3 ON FactResellerSalesXL(OrderQuantity, UnitPrice, OrderDateKey, ProductKey, SalesTerritoryKey)
--WHERE OrderDateKey < 20170101		--Inte dom fr�n i �r...
--WITH (COMPRESSION_DELAY = 1440 MINUTES)	--Dr�j en dag med att komprimmera raderna, b�de CL och NC

--G�r hand-i-hand med filtret p� index ovan
--CREATE NONCLUSTERED INDEX ix_datekey ON FactResellerSalesXL(OrderDateKey)
--WHERE OrderDateKey >= 20170101	
--Tabellen �r i �vrigt or�rd, vad g�ller vilka index som finns

--Sl� p� archive compression
EXEC sp_indexinfo 'FactResellerSalesXL_CCI' --481 MB
ALTER TABLE FactResellerSalesXL_CCI REBUILD WITH (DATA_COMPRESSION =  COLUMNSTORE_ARCHIVE) --ca 1 minut
EXEC sp_indexinfo 'FactResellerSalesXL_CCI' --379 MB
--Detta b�r bara g�ras f�r partitionerad tabell och partitioner man s�llan accessar!



-------------------------------------------------------------------------------------------------------------------------------
--St�da
DROP INDEX IF EXISTS x ON FactResellerSalesXL
DROP INDEX IF EXISTS x3 ON FactResellerSalesXL
DROP INDEX IF EXISTS ix_datekey ON FactResellerSalesXL
