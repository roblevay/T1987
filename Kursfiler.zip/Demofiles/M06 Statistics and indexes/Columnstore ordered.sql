--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.

--Vi ska importea ca 60% av datat fr�n FactResellerSalesXL till ny tabell, NewFact
--Vi skapar rad-clustrat index p� NewFact, s� att vi senare kan f� segmentuppradning p� OrderDate

USE AdventureworksDW

-----------------------------------------------------------------------------------------------------
--K�rning 1: "Gamla s�ttet"
-----------------------------------------------------------------------------------------------------
DROP TABLE IF EXISTS NewFact
GO

--Skapa tabell med 7 mill rader. 13 sek.
SELECT * INTO NewFact 
FROM FactResellerSalesXL 
WHERE UnitPrice < 400

--Tabellen �r nu en heap-tabell
EXEC sp_indexinfo 'NewFact'

--Litet utval av datat
SELECT TOP(100) * FROM NewFact

--Skapa cl rad index p� OrderDate, 1 minut
CREATE CLUSTERED INDEX NewFact ON NewFact(OrderDateKey)

--Skapa om det till clustered columnstore index, 1 minut 29 sek
CREATE CLUSTERED COLUMNSTORE INDEX NewFact ON NewFact
WITH (DROP_EXISTING = ON, MAXDOP = 1)

--Nu b�r vi ha fin segment-uppradning p� kolumnen OrderDateKey. 8 segment (0-7).
EXEC GetSegmentAlignment 'NewFact'--, 'OrderDateKey'
--Skapa ovan proc med "GetSegmentAlignment.sql"



--Ladda nu resten av datat. 77 sekunder.
INSERT INTO NewFact
SELECT * 
FROM FactResellerSalesXL 
WHERE UnitPrice >= 400

--Hur ser det ut nu?
EXEC GetSegmentAlignment 'NewFact'--, 'OrderDateKey'
--Vi har nu 13 segment, dvs 5 nya. 
--De nya �r 8-12, och d�r �r data "all over the place".


---------------------------------------------------------
--Innan 2022 fick vi g�ra nedan om vi vill st�da upp det:

--Skapa om tabellen till rad-klustrat index p� OrderDateKey, 1.45
CREATE CLUSTERED INDEX NewFact ON NewFact(OrderDateKey) WITH (DROP_EXISTING = ON)

--Och skapa till klustrat columnstore index.1.50
CREATE CLUSTERED COLUMNSTORE INDEX NewFact ON NewFact WITH (DROP_EXISTING = ON, MAXDOP = 1)

--Hur ser det ut nu?
EXEC GetSegmentAlignment 'NewFact'--, 'OrderDateKey'
--12 segment, fint uppdadade p� OrderDateKey 


-----------------------------------------------------------------------------------------------------
--K�rning 2: "Nya s�ttet", men med f�r liten tempdb (dvs "soft sort")
-----------------------------------------------------------------------------------------------------
DROP TABLE IF EXISTS NewFact
GO

--Skapa tabell med 7 mill rader. 2 sek.
SELECT * INTO NewFact 
FROM FactResellerSalesXL 
WHERE UnitPrice < 400

--Skapa clustered columns store ORDERED index. 1:14 min.
CREATE CLUSTERED COLUMNSTORE INDEX NewFact ON NewFact ORDER(OrderDateKey) WITH(MAXDOP = 1)


--Notera kolumnen columns_store_order_ordinal
SELECT i.name, i.type_desc, c.column_id, COL_NAME(c.object_id, c.column_id) as ColumnName, c.column_store_order_ordinal 
FROM sys.indexes AS i
INNER JOIN sys.index_columns AS c ON i.index_id = c.index_id AND i.object_id = c.object_id
WHERE i.object_id = OBJECT_ID('NewFact')

--Vi b�r ha fin segment-uppradning p� kolumnen OrderDateKey. 8 segment (0-7).
EXEC GetSegmentAlignment 'NewFact', 'OrderDateKey'


--Ladda nu resten av datat. 60 sekunder.
INSERT INTO NewFact
SELECT * 
FROM FactResellerSalesXL 
WHERE UnitPrice >= 400

--Hur ser det ut nu?
EXEC GetSegmentAlignment 'NewFact', 'OrderDateKey'
--Vi har nu 13 segment, dvs 5 nya. 
--De nya �r 8-12, och d�r �r data "all over the place".


--Vi kan g�ra n�gon av nedanst�ende:

--F�r nedanst�ende s� blir det lika som innan. Dvs f�rsta 8 segment bra, sista 5 i oordning.
ALTER INDEX NewFact ON NewFact REBUILD WITH (MAXDOP = 1)
--Hur blev det?
EXEC GetSegmentAlignment 'NewFact', 'OrderDateKey'
--Lika illa med 4GB tempdb

--Inte riktigt samma segment-utseende med denna, men datat fortfarande i oordning
CREATE CLUSTERED COLUMNSTORE INDEX NewFact ON NewFact ORDER(OrderDateKey) WITH(DROP_EXISTING = ON, MAXDOP = 1)
--Hur blev det?
EXEC GetSegmentAlignment 'NewFact', 'OrderDateKey'
--Nu blev det bra med tillr�ckligt stor tempdb.

--Dvs, datat i oordning pga att sorteringen inte f�r plats i tempdb.


-----------------------------------------------------------------------------------------------------
--K�rning 3: "Nya s�ttet", med tillr�ckligt stor tempdb
-----------------------------------------------------------------------------------------------------
ALTER DATABASE tempdb MODIFY FILE (name = tempdev, size = 2GB)
ALTER DATABASE tempdb MODIFY FILE (name = temp2, size = 2GB)
--K�r nu enligt "K�rning 2", ovan

--Man kan anv�nda denna f�r att se i exekveringsplanen om det �r en soft sort. 
--Ej supportad, anv�nd ej i produktion.
DBCC TRACEON (8666)

--St�ng sen av med denna.
DBCC TRACEOFF (8666)

--Se denna f�r mer detaljer:
-- https://www.red-gate.com/simple-talk/databases/sql-server/t-sql-programming-sql-server/ordered-columnstore-indexes-in-sql-server-2022/

