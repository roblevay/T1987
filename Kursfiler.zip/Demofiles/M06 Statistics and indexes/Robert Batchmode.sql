CREATE DATABASE BatchModeDemo;
GO
USE BatchModeDemo;
GO
ALTER DATABASE BatchModeDemo SET COMPATIBILITY_LEVEL = 150;

USE BatchModeDemo;
GO
DROP TABLE IF EXISTS Sales;
CREATE TABLE Sales (
    ID BIGINT IDENTITY PRIMARY KEY,
    Product NVARCHAR(50),
    Quantity INT,
    Price DECIMAL(10,2),
    SaleDate DATETIME
);
GO

-- Infoga 10 miljoner rader
INSERT INTO Sales (Product, Quantity, Price, SaleDate)
SELECT 
    'Product ' + CAST(ABS(CHECKSUM(NEWID())) % 1000 AS NVARCHAR),
    ABS(CHECKSUM(NEWID())) % 100,
    RAND() * 100,
    DATEADD(DAY, -ABS(CHECKSUM(NEWID())) % 365, GETDATE())
FROM master.dbo.spt_values t1
CROSS JOIN master.dbo.spt_values t2
WHERE t1.type = 'P' AND t2.type = 'P';
GO

GO

--2. Kontrollera om Batch Mode anv�nds
SELECT Product, SUM(Quantity) AS TotalQuantity, AVG(Price) AS AvgPrice
FROM Sales
GROUP BY Product


