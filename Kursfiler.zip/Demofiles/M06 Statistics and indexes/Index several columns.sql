--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Index p� mer �n en kolumn
USE Adventureworks

--Vi ska leka med denna tabell, f�rnamn och efternamn
SELECT * FROM Person.Person

--Hur m�nga finns det av varje FirstName
SELECT FirstName, COUNT(*) AS antal
FROM Person.Person AS p
GROUP BY FirstName
ORDER BY antal DESC

--Hur m�nga finns det av varje LastName
SELECT LastName, COUNT(*) AS antal
FROM Person.Person AS p
GROUP BY LastName
ORDER BY antal DESC


-- 103 Richard
-- 211 Diaz
--   1 Richard Diaz

--Vilka index finns det?
EXEC sp_helpindex 'Person.Person'
EXEC sp_help 'Person.Person'
EXEC sp_indexinfo 'Person'		--P� min websida

--Disable de som kan st�ra v�rat exempel
ALTER INDEX Person_FirstName ON Person.Person DISABLE
GO
ALTER INDEX IX_Person_LastName_FirstName_MiddleName ON Person.Person DISABLE
GO

--T�nk er denna fr�ga
SELECT FirstName, p.LastName, p.EmailPromotion
FROM Person.Person AS p
WHERE 1 = 1
AND FirstName = 'Richard'	--103
AND LastName = 'Diaz'		--211

--Indexalternativ
--(LastName)
--(FirstName)
--(LastName, FirstName)
--(FirstName, LastName)
--(LastName) (FirstName)
--(LastName, FirstName) (FirstName, LastName)

SET STATISTICS IO ON

EXEC sp_indexinfo 'Person'

-- 103 Richard
-- 211 Diaz
--   1 Richard Diaz
SET STATISTICS IO ON
--Vi provar lite alternativ, kollar exekveringsplan etc
SELECT p.FirstName, p.LastName, p.EmailPromotion
FROM Person.Person AS p
WHERE 1 = 1
AND FirstName = 'Richard' --103
AND LastName = 'Diaz'	  --211

-- 103 Richard
-- 211 Diaz
--   1 Richard Diaz
---------------------------------------------------------------------------------------------
CREATE NONCLUSTERED INDEX x ON Person.Person(LastName)
WITH DROP_EXISTING
--Seek p� LastName, med Lookup, 659 pages
---------------------------------------------------------------------------------------------
CREATE NONCLUSTERED INDEX x ON Person.Person(FirstName)
WITH DROP_EXISTING
--Seek p� FirstName, med Lookup, 326 pages
---------------------------------------------------------------------------------------------
CREATE NONCLUSTERED INDEX x ON Person.Person(LastName, FirstName)
WITH DROP_EXISTING
--Seek p� LastName, FirstName, med Lookup, 5 pages
---------------------------------------------------------------------------------------------
CREATE NONCLUSTERED INDEX x ON Person.Person(LastName)
WITH DROP_EXISTING
CREATE NONCLUSTERED INDEX x2 ON Person.Person(FirstName)
--Seek p� LastName
--Seek p� FirstName
--Join av de tv�. Lookup, 9 pages


---------------------------------------------------------------------------------------------
--Index som t�cker fr�ga ("covering index"), alla kolumner i nyckeln
SELECT p.FirstName, p.LastName, p.EmailPromotion
FROM Person.Person AS p
WHERE 1 = 1
AND FirstName = 'Richard'
AND LastName = 'Diaz'

EXEC sp_indexinfo 'Person'
SET STATISTICS IO ON

DROP INDEX IF EXISTS x2 ON Person.Person
CREATE INDEX x ON Person.Person(LastName, FirstName, EmailPromotion)
WITH DROP_EXISTING
--Seek p� LastName, 2 pages

--Index som "driver" fr�gan i nyckeln, �vriga som included
CREATE INDEX x ON Person.Person(LastName, FirstName)
INCLUDE(EmailPromotion)
WITH DROP_EXISTING
--Seek p� LastName, 2 pages


--Nu vill vi ha MiddleName ocks�
SELECT p.FirstName, p.LastName, p.EmailPromotion, p.MiddleName
FROM Person.Person AS p
WHERE 1 = 1
AND FirstName = 'Richard'
AND LastName = 'Diaz'





--St�da
ALTER INDEX Person_FirstName ON Person.Person REBUILD
GO
ALTER INDEX IX_Person_LastName_FirstName_MiddleName ON Person.Person REBUILD
GO
DROP INDEX x ON Person.Person
DROP INDEX x2 ON Person.Person

