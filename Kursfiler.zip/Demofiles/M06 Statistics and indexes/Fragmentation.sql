--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.

--J�mf�r fragmentering mellan heap och index
USE tempdb

--------------------------------------------------------------------------------------------------------------------------------

DROP TABLE IF EXISTS PhoneLog

--Heap tabell/klustread tabell
CREATE TABLE dbo.PhoneLog
--( PhoneLogID int IDENTITY(1,1) PRIMARY KEY NOT NULL, --F�rsta k�rningen, HEAP
(PhoneLogID int IDENTITY(1,1) PRIMARY KEY NONCLUSTERED NOT NULL, --F�rsta k�rningen, HEAP
--( PhoneLogID int IDENTITY(1,1) PRIMARY KEY CLUSTERED NOT NULL, --Andra k�rningen, klustrad
  LogRecorded datetime2 NOT NULL INDEX IX_PhoneLog_LogRecorded,
  PhoneNumberCalled nvarchar(200) NOT NULL,
  CallDurationMs int NOT NULL
)

--CREATE CLUSTERED INDEX  myindex ON tbl(c1, c2)
--CREATE NONCLUSTERED INDEX  myindex ON tbl(c1, c2)

EXEC sp_helpindex 'PhoneLog'
EXEC sp_indexinfo 'PhoneLog' --finns p� min hemsida

SELECT OBJECT_NAME(object_id), * 
FROM sys.indexes 
WHERE object_id = OBJECT_ID(N'PhoneLog')

--Vilka tabeller �r heaps respektive klustrade?
SELECT OBJECT_SCHEMA_NAME(object_id), OBJECT_NAME(object_id), type_desc--*
FROM sys.indexes 
WHERE OBJECTPROPERTYEX(object_id, 'IsMsShipped') = 0
AND type_desc IN('HEAP', 'CLUSTERED', 'CLUSTERED COLUMNSTORE')
ORDER BY type_desc

--Hur m�nga index av varje typ?
SELECT type_desc, COUNT(*)
FROM sys.indexes 
WHERE OBJECTPROPERTYEX(object_id, 'IsMsShipped') = 0
GROUP BY type_desc

--Ladda data
USE tempdb
SET NOCOUNT ON
DECLARE @Counter int = 0
WHILE @Counter < 50000 BEGIN
  INSERT PhoneLog (LogRecorded, PhoneNumberCalled, CallDurationMs)
    VALUES(SYSDATETIME(),'999-9999',CAST(RAND() * 1000 AS int));
  SET @Counter += 1
END
GO

SELECT * FROM PhoneLog

-- Modifiera varannan rad
UPDATE dbo.PhoneLog 
SET PhoneNumberCalled = PhoneNumberCalled + REPLICATE('x', 180)
WHERE PhoneLogID % 2 = 1

SELECT * FROM PhoneLog

--Fragmentering
SELECT * FROM sys.dm_db_index_physical_stats(NULL, NULL, NULL, NULL, DEFAULT)

SELECT DB_NAME(database_id), OBJECT_SCHEMA_NAME(object_id, database_id), OBJECT_NAME(object_id, database_id), * 
FROM sys.dm_db_index_physical_stats(DB_ID(),NULL,NULL,NULL,DEFAULT) 

SELECT * FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('PhoneLog'),NULL,NULL,DEFAULT) 
SELECT * FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('PhoneLog'),NULL,NULL,'LIMITED')
SELECT * FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('PhoneLog'),NULL,NULL,'DETAILED') WHERE index_level = 0
SELECT * FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('PhoneLog'),NULL,NULL,'SAMPLED') 
--Notera forwarded record count f�r heap
--Notera avg_fragmentation_in_percent och page_count f�r klustrade tabellen


EXEC sp_indexinfo 'Phonelog'

SET STATISTICS IO ON
SELECT * FROM PhoneLog 
SET STATISTICS IO OFF
--24147 I/O, 305 ms som heap (1428 I/O, 140 ms efter defrag)
--2525 I/O, 32 ms som klustrad som cl (1440 efter defrag)

EXEC sp_indexinfo 'PhoneLog'

--Bygg om heap (bygger ocks� om alla icke-klustrade index)
ALTER TABLE dbo.PhoneLog REBUILD WITH(ONLINE = ON) --ONLINE = ON kr�ver EE
-- Se http://karaszi.com/rebuild-all-fragmented-heaps


--Defragmentera index
ALTER INDEX ALL ON dbo.PhoneLog REORGANIZE
ALTER INDEX ALL ON dbo.PhoneLog REBUILD WITH(ONLINE = ON) --ger ny fr�sch statistik, ONLINE = ON kr�ver EE

--Kan avbryta och forts�tta rebuild i 2017
ALTER INDEX PK_Votes__Id ON Votes REBUILD WITH(ONLINE = ON, RESUMABLE = ON)
--Kan automatiskt "elevera" vanlig rebuild till resumable
SELECT * FROM sys.database_scoped_configurations where name like '%eleva%'
--2019 kan CREATE vara resumable

--FILLFACTOR
ALTER INDEX ALL ON dbo.PhoneLog REBUILD WITH(ONLINE = ON, FILLFACTOR = 80) 
SELECT  * FROM sys.indexes

--F�r column-store index:
-- Reorg p�skyndar tuple-mover, 
--  dvs komprierar st�ngda row-groups direkt 
--  ist�llet f�r att v�nta p� asynkron bakgrundsprocess
--  2016 g�r lite mer, 
--     se https://blogs.msdn.microsoft.com/sqlserverstorageengine/2016/03/08/columnstore-index-merge-policy-for-reorganize/
--     och http://www.nikoport.com/2015/12/25/columnstore-indexes-part-74-row-groups-merging-cleanup-sql-server-2016-edition/
-- Rebuild skapar ett nytt "fr�sht" index med nya dictionary, fimpar delete-bitmap, etc, etc.


--Fragmentering
SELECT * FROM sys.dm_db_index_physical_stats(DB_ID(),OBJECT_ID('dbo.PhoneLog'),NULL,NULL,'DETAILED') WHERE index_level = 0

--Se nedan om fragmentering i B-Tree index:
-- https://sqlblog.karaszi.com/index-fragmentation-revisited/

--�ven MS avr�der numer fr�n att defragmentera regelbundet:
--"Microsoft does not recommend performing index maintenance indiscriminately."
-- https://learn.microsoft.com/en-us/sql/relational-databases/indexes/reorganize-and-rebuild-indexes

--St�da (ej, f�r senare demo)
--DROP TABLE dbo.PhoneLog

--Maintenance planer
-- ola.hallengren.com
