--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

-- https://www.sqlskills.com/blogs/kimberly/removing-duplicate-indexes/
-- Brents sp_blitzindex har ocks� parameter som bla letar efter dublettindex

CREATE INDEX x ON t (c1)
CREATE INDEX x2 ON t (c1) --"bokstavlig" dublett

CREATE INDEX x ON p(e, f)
CREATE INDEX x2 ON p(e) --"funktionell" dublett

