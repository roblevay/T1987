--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.


USE Adventureworks

DROP INDEX IF EXISTS x ON Sales.SalesOrderDetail
DROP INDEX IF EXISTS ix_OrderQty ON Sales.SalesOrderDetail

EXEC sp_indexinfo 'SalesOrderDetail'

--------------------------------------------------------------------------------------------------------------------------------------
--N�gra fr�gor som skulle m� bra av index

SELECT * 
FROM Sales.SalesOrderDetail AS d
WHERE OrderQty = 34
--Titta p� exekveringsplanen.
--Hur smart var den rekommendationen?
GO 

--K�r dessa f�r att samla ihop lite rekommendationer
SELECT * 
FROM Sales.SalesOrderDetail AS d 
WHERE OrderQty = 34
GO 3

SELECT d.SalesOrderID, d.ModifiedDate
FROM Sales.SalesOrderDetail AS d 
WHERE OrderQty = 34
GO 15

SELECT d.SalesOrderID, d.LineTotal
FROM Sales.SalesOrderDetail AS d 
WHERE OrderQty = 34
GO 10


--------------------------------------------------------------------------------------------------------------------------------------
--Missing index vyerna

--En rad per f�reslaget index
SELECT OBJECT_SCHEMA_NAME(object_id, database_id), OBJECT_NAME(object_id, database_id), * 
FROM sys.dm_db_missing_index_details

SELECT * FROM sys.dm_db_missing_index_group_stats

--Ger koppling mellan details och stats
SELECT * FROM sys.dm_db_missing_index_groups

--Joina de tre vyerna
SELECT OBJECT_SCHEMA_NAME(object_id, database_id), OBJECT_NAME(object_id, database_id), equality_columns, inequality_columns, included_columns, user_seeks, user_scans, last_user_seek, avg_total_user_cost, avg_user_impact
FROM sys.dm_db_missing_index_details AS d 
INNER JOIN sys.dm_db_missing_index_groups AS g ON d.index_handle = g.index_handle 
INNER JOIN sys.dm_db_missing_index_group_stats AS s ON g.index_group_handle = s.group_handle 


--I 2019 fick vi �ven denna:
SELECT * FROM sys.dm_db_missing_index_group_stats_query

--Dvs vi kan f� med sql fr�gan som genererade v�r "missing index"
SELECT
 OBJECT_SCHEMA_NAME(object_id, database_id)
,OBJECT_NAME(object_id, database_id)
,equality_columns
,inequality_columns
,included_columns
,s.user_seeks
,s.user_scans
,s.last_user_seek
,s.avg_total_user_cost
,s.avg_user_impact
,t.text
FROM sys.dm_db_missing_index_details AS d 
INNER JOIN sys.dm_db_missing_index_groups AS g ON d.index_handle = g.index_handle 
INNER JOIN sys.dm_db_missing_index_group_stats AS s ON g.index_group_handle = s.group_handle 
INNER JOIN sys.dm_db_missing_index_group_stats_query AS q ON q.group_handle = s.group_handle
CROSS APPLY sys.dm_exec_sql_text(q.last_sql_handle) AS t
--------------------------------------------------------------------------------------------------------------------------------------
--sp_indexinfo, p� min web-site. Andra parametern.
EXEC sp_indexinfo
EXEC sp_indexinfo @tblPat = 'SalesOrderDetail', @missing_ix = 1
EXEC sp_indexinfo @tblPat = '%', @missing_ix = 1

--------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------

--Glenn Berry:
-- https://glennsqlperformance.com/resources/
-- Missing Indexes for all databases by Index Advantage  (Query 29) (Missing Indexes All Databases)
SELECT CONVERT(decimal(18,2), user_seeks * avg_total_user_cost * (avg_user_impact * 0.01)) AS [index_advantage], 
migs.last_user_seek, mid.[statement] AS [Database.Schema.Table],
mid.equality_columns, mid.inequality_columns, mid.included_columns,
migs.unique_compiles, migs.user_seeks, migs.avg_total_user_cost, migs.avg_user_impact
FROM sys.dm_db_missing_index_group_stats AS migs WITH (NOLOCK)
INNER JOIN sys.dm_db_missing_index_groups AS mig WITH (NOLOCK)
ON migs.group_handle = mig.index_group_handle
INNER JOIN sys.dm_db_missing_index_details AS mid WITH (NOLOCK)
ON mig.index_handle = mid.index_handle
ORDER BY index_advantage DESC OPTION (RECOMPILE);

-- Getting missing index information for all of the databases on the instance is very useful
-- Look at last user seek time, number of user seeks to help determine source and importance
-- Also look at avg_user_impact and avg_total_user_cost to help determine importance
-- SQL Server is overly eager to add included columns, so beware
-- Do not just blindly add indexes that show up from this query!!!

--------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
--Brent Ozar
-- https://www.brentozar.com/first-aid/
EXEC sp_blitzindex


--------------------------------------------------------------------------------------------------
--Database Engine Tuning Advisor
--------------------------------------------------------------------------------------------------
USE AdventureworksDW

SELECT
 SUM(s.OrderQuantity * s.UnitPrice)
,psc.EnglishProductSubcategoryName
,t.SalesTerritoryCountry
,d.CalendarYear
FROM FactResellerSalesXL AS s
 INNER JOIN DimDate AS d ON s.OrderDateKey = d.DateKey
 INNER JOIN DimProduct AS p ON s.ProductKey = p.ProductKey
 INNER JOIN DimSalesTerritory AS t ON s.SalesTerritoryKey = t.SalesTerritoryKey
 INNER JOIN DimProductSubcategory AS psc ON p.ProductSubcategoryKey = psc.ProductSubcategoryKey
 INNER JOIN DimProductCategory AS pc ON psc.ProductCategoryKey = pc.ProductCategoryKey
GROUP BY psc.EnglishProductSubcategoryName, d.CalendarYear, t.SalesTerritoryCountry


--------------------------------------------------------------------------------------------------
--Hur ofta har index anv�nts

SELECT * FROM sys.dm_db_index_usage_stats

SELECT DB_NAME(database_id), OBJECT_SCHEMA_NAME(object_id, database_id), OBJECT_NAME(object_id, database_id), * 
FROM sys.dm_db_index_usage_stats
WHERE DB_NAME(database_id) = 'AdventureworksDW'
--WHERE user_seeks < 100 AND user_scans < 100 AND user_updates > 100
ORDER BY DB_NAME(database_id);


--Lagra i tabell s� att den informationen �verlever omstart av SQL Server:
-- https://www.sqlserverscience.com/performance/capturing-index-usage-stats/



--------------------------------------------------------------------------------------------------
--Djupare information om indexanv�ndning
SELECT * FROM sys.dm_db_index_operational_stats(NULL, NULL, NULL, NULL) AS t
WHERE t.forwarded_fetch_count > 0


/*Fr�gan ger dig en lista �ver heap-tabeller d�r forwarded fetches sker, 
vilket kan orsaka prestandaproblem. 
Detta �r en indikation p� att du b�r �verv�ga att optimera dessa tabeller, 
antingen genom att l�gga till klustrade index eller genom att 
omstrukturera datan f�r att undvika behovet av forwarding pointers.*/