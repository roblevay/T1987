--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

USE AdventureworksDW


---------------------------------------------------------------------------------

--Are below SARG?

-- WHERE LEFT(LastName,2) = N'Ac'	No
-- WHERE LastName LIKE N'Ac%'		Yes	

-- WHERE 100 < ABS(BusinessEntityID)	No
-- WHERE 100 < BusinessEntityID			YEs

-- WHERE ReorderPoint - 500 BETWEEN 250 AND 750			No
-- WHERE ReorderPoint BETWEEN 250 + 500 AND 750 + 500	Yes, is transformed to below ("Constant folding"):
-- WHERE ReorderPoint BETWEEN 750 AND 1250				

-- WHERE CONVERT(ModifiedDate...) = '2015-01-02'						No
-- WHERE ModifiedDate >= '2015-01-02' AND ModifiedDate < '2015-01-03'	Yes

---------------------------------------------------------------------------------
--A couple of examples

USE AdventureworksDW

--Table to play with
SELECT TOP(10) OrderDate, * FROM FactResellerSalesXL



--Create index on OrderDate
CREATE INDEX x ON FactResellerSalesXL(OrderDate)
WITH DROP_EXISTING


---------------------------------------------------------------------------------------------------------------
--Orders from 2004, 0.
SET STATISTICS IO ON

--Alternative 1, not SARG
SELECT *
FROM FactResellerSalesXL AS s
WHERE DATEPART(YEAR, s.OrderDate) = 2004
--Index scan, with lookup, 53576 pages

--Alternative 2, SARG
SELECT *
FROM FactResellerSalesXL AS s
WHERE s.OrderDate >= '20040101' AND s.OrderDate < '20050101'
--Index seek, with lookup, 4 pages


---------------------------------------------------------------------------------------------------------------
--Orders from 2014-04-02, 27.
SET STATISTICS IO ON

SELECT CONVERT(varchar(10), GETDATE() , 120)

--Alternative 1, not SARG
SELECT *
FROM FactResellerSalesXL AS s
WHERE CONVERT(varchar(10), OrderDate , 120) = '2014-04-02'
--Table scan, 325 127 pages

--Alternative 2, SARG
SELECT *
FROM FactResellerSalesXL AS s
WHERE s.OrderDate >= '2014-04-02' AND s.OrderDate < '2014-04-03'
--Index seek, with lookup, 122 pages

--Can we catch these in a trace? 
--Not reliably, since that event is generated for all conversions.
SELECT CONVERT(varchar(10), OrderDate , 120), *
FROM FactResellerSalesXL AS s
WHERE  s.OrderDate >= '2014-04-02' AND s.OrderDate < '2014-04-03'

--In SQL Server 2022 we will get new events for these types of "anti-patterns"



--Can create a computed column on the expression, tar n�gon minut
ALTER TABLE FactResellerSalesXL ADD OrderDateCompCol AS CONVERT(varchar(10), OrderDate , 120) --PERSISTED
SELECT TOP(199) * FROM FactResellerSalesXL
CREATE INDEX xyz ON FactResellerSalesXL(OrderDateCompCol)
--CREATE INDEX xyz ON FactResellerSalesXL(CONVERT(varchar(10), OrderDate , 120)) --Kan ej skapa index p� en formel i MSSQL

SELECT *
FROM FactResellerSalesXL AS s
WHERE CONVERT(varchar(10), OrderDate , 120) = '2014-04-02'

DROP INDEX xyz ON FactResellerSalesXL
ALTER TABLE FactResellerSalesXL DROP COLUMN OrderDateCompCol
