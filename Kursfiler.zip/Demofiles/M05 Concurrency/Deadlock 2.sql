--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.


BEGIN TRAN

UPDATE Adventureworks.Production.Product
SET Color = 'Black'
WHERE ProductID = 3

SELECT p.ProductID, p.Color, p.ListPrice
FROM Adventureworks.Production.Product AS p


--Vilken vi nu vill g�ra...
ROLLBACK
COMMIT
