--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.


RAISERROR('H�rru, k�r inte allt!', 20, 1) WITH LOG

USE Adventureworks

--Notera inst�llningar f�r databaser
SELECT name, snapshot_isolation_state, is_read_committed_snapshot_on 
FROM sys.databases

--Vi kommer att modifiera denna rad
SELECT c.CustomerID, c.ModifiedDate
FROM Sales.Customer AS c
WHERE c.CustomerID = 2

--K�r Query1 i andra scriptet

--Notera effeken av dirty read, i READ UNCOMMITTED
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

SELECT c.CustomerID, c.ModifiedDate
FROM Sales.Customer AS c --WITH (NOLOCK)
WHERE c.CustomerID = 2

--Oj d�. vi ser en modifikation som inte �r committad

--Vi k�r READ COMMITTED ist�llet, den som �r default
--I Azure SQL database �r READ_COMMITTED_SNAPSHOT p�, kan anv�nda READCOMMITTEDLOCK
SET TRANSACTION ISOLATION LEVEL READ COMMITTED

SELECT c.CustomerID, c.ModifiedDate
FROM Sales.Customer AS c --WITH (READCOMMITTEDLOCK) --Om man i Azure will ha pessimistiskt read committed
WHERE c.CustomerID = 2

--Jaha, nu h�nger vi, v�ntat.
--K�r Query2 i andra scriptet


--Nu visar vi att READ COMMITTED ej ger repeterbar l�sning
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
BEGIN TRANSACTION
	SELECT c.CustomerID, c.ModifiedDate
	FROM Sales.Customer AS c
	WHERE c.CustomerID = 2

--K�r Query3 i andra scriptet

	SELECT c.CustomerID, c.ModifiedDate
	FROM Sales.Customer AS c
	WHERE c.CustomerID = 2
COMMIT
--Hupp! Inte repeterbar l�sning


--Vi anv�nder REPEATABLE READ ist�llet
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ

BEGIN TRANSACTION
	SELECT c.CustomerID, c.ModifiedDate
	FROM Sales.Customer AS c
	WHERE c.CustomerID = 2

--K�r Query4 i andra scriptet, notera att den �r blockerad
	SELECT c.CustomerID, c.ModifiedDate
	FROM Sales.Customer AS c
	WHERE c.CustomerID = 2
COMMIT
--Och d�rmed hade vi repeterbar l�sning!

SELECT c.CustomerID, c.ModifiedDate
FROM Sales.Customer AS c
WHERE c.CustomerID = 2--1900

--Men REPEATABLE READ till�ter fantomrader
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ

BEGIN TRANSACTION
	SELECT COUNT(*) AS CustCount 
	FROM Sales.Customer AS c
	WHERE c.TerritoryID = 5
--176

--K�r Query5 i andra scriptet

	SELECT COUNT(*) AS CustCount 
	FROM Sales.Customer AS c
	WHERE c.TerritoryID = 5
COMMIT
--Hupp! 177

--Vi g�r om det, men i SERIALIZABLE ist�llet
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
	SELECT COUNT(*) AS CustCount 
	FROM Sales.Customer AS c
	WHERE c.TerritoryID = 5
--177

--K�r Query5 i andra scriptet
--Den �r nu blockerad!

	SELECT COUNT(*) AS CustCount 
	FROM Sales.Customer AS c
	WHERE c.TerritoryID = 5
COMMIT
--Ah, bra! 177

------------------------------------------------------------------------------------------------------------
--Nu k�r vi READ COMMITTED, men med READ_COMMITTED_SNAPSHOT p�slaget

--S�tt READ_COMMITTED_SNAPSHOT, f�r inte ha n�n session i databasen
USE master
GO
ALTER DATABASE Adventureworks SET SINGLE_USER WITH ROLLBACK IMMEDIATE
WAITFOR DELAY '00:00:02'
ALTER DATABASE Adventureworks SET READ_COMMITTED_SNAPSHOT ON
WAITFOR DELAY '00:00:02'
ALTER DATABASE Adventureworks SET MULTI_USER WITH ROLLBACK IMMEDIATE
GO
USE Adventureworks

--Se till att vi har ett k�nt datum
UPDATE Sales.Customer
SET ModifiedDate = '1900-01-01'
WHERE CustomerID = 2

--K�r Query6 i andra scriptet
SET TRANSACTION ISOLATION LEVEL READ COMMITTED

BEGIN TRANSACTION 
	SELECT c.CustomerID, c.ModifiedDate
	FROM Sales.Customer AS c
	WHERE c.CustomerID = 2
--Nu �r vi inte blockerade, vi ser senaste kommittade v�rdet!

--K�r Query7 i andra scriptet

	SELECT c.CustomerID, c.ModifiedDate
	FROM Sales.Customer AS c
	WHERE c.CustomerID = 2
COMMIT
--Men, inte repeterbar l�sning


------------------------------------------------------------------------------------------------------------
--D� k�r vi sann snapshot ist�llet

--Vi sl�r av READ_COMMITTED_SNAPSHOT, beh�vs inte f�r exemplet, men f�r att st�da
--Vi till�ter sann SNAPSHOT, h�r beh�ver vi egentligen inte vara ensamma i databasen!
USE master
GO
ALTER DATABASE Adventureworks SET SINGLE_USER WITH ROLLBACK IMMEDIATE
WAITFOR DELAY '00:00:02'
ALTER DATABASE Adventureworks SET READ_COMMITTED_SNAPSHOT OFF
ALTER DATABASE Adventureworks SET ALLOW_SNAPSHOT_ISOLATION ON
ALTER DATABASE Adventureworks SET MULTI_USER
GO
USE Adventureworks

--Se till att vi har ett k�nt datum
UPDATE Sales.Customer
SET ModifiedDate = '1900-01-01'
WHERE CustomerID = 2

--K�r Query6 i andra scriptet
SET TRANSACTION ISOLATION LEVEL SNAPSHOT

BEGIN TRANSACTION 
	SELECT c.CustomerID, c.ModifiedDate
	FROM Sales.Customer AS c
	WHERE c.CustomerID = 2
--Nu �r vi inte blockerade, vi se gamla v�rdet!

--K�r Query7 i andra scriptet

	SELECT c.CustomerID, c.ModifiedDate
	FROM Sales.Customer AS c
	WHERE c.CustomerID = 2
--Vi ser fortfarande gamla v�rdet!
--Vi har repeterbar l�sning

COMMIT
--Nu d�?
SELECT c.CustomerID, c.ModifiedDate
FROM Sales.Customer AS c
WHERE c.CustomerID = 2


--Nu ska vi se en update conflict i SNAPSHOT

--Se till att vi har ett k�nt datum
UPDATE Sales.Customer
SET ModifiedDate = '1900-01-01'
WHERE CustomerID = 2



--K�r Query6 i andra scriptet

SET TRANSACTION ISOLATION LEVEL SNAPSHOT

BEGIN TRANSACTION 
	SELECT c.CustomerID, c.ModifiedDate
	FROM Sales.Customer AS c
	WHERE c.CustomerID = 2

--Vi ser gamla v�rdet, som v�ntat

--Men om vi nu vill modifiera samma rad?
	UPDATE Sales.Customer
	SET ModifiedDate = '2050-06-06'
	WHERE CustomerID = 2

--Blockerad �n s� l�nge

--K�r Query7 i andra scriptet

--Notera felmeddelandet!

--Notera att SQL Server avlutade transaktionen!
SELECT @@TRANCOUNT
COMMIT
--St�da
USE master
GO
ALTER DATABASE Adventureworks SET SINGLE_USER WITH ROLLBACK IMMEDIATE
WAITFOR DELAY '00:00:02'
ALTER DATABASE Adventureworks SET ALLOW_SNAPSHOT_ISOLATION OFF
ALTER DATABASE Adventureworks SET MULTI_USER


--Det finns en lock timeout (ms), default �r o�ndlig (-1)
SET LOCK_TIMEOUT 3000
--Error 1222 fr�n sql server om man v�ntar l�ngre tid �n ovan p� ett l�s
SET LOCK_TIMEOUT -1 --Default, o�ndligt
