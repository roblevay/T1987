--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.


RAISERROR('H�rru, k�r inte allt!', 20, 1) WITH LOG

USE Adventureworks

--Query1
BEGIN TRANSACTION
	UPDATE Sales.Customer
	SET ModifiedDate = '9999-12-31'
	WHERE CustomerID = 2

--Query2
ROLLBACK

--Query3
UPDATE Sales.Customer
SET ModifiedDate = '9999-12-31'
WHERE CustomerID = 2

--Query4
UPDATE Sales.Customer
SET ModifiedDate = '1900-01-01'
WHERE CustomerID = 2

--Query5
DECLARE @id int
INSERT INTO Sales.Customer (PersonID, StoreID, TerritoryID, rowguid, ModifiedDate)
VALUES(17182, NULL, 5, NEWID(), GETDATE())
SET @id = SCOPE_IDENTITY()
SELECT * FROM Sales.Customer WHERE CustomerID = @id

SELECT DB_NAME()

--Query6
BEGIN TRANSACTION
	UPDATE Sales.Customer
	SET ModifiedDate = '9999-12-31'
	WHERE CustomerID = 2

	SELECT c.CustomerID, c.ModifiedDate
	FROM Sales.Customer AS c --WITH(REPEATABLEREAD)
	WHERE c.CustomerID = 2
-- Query7
COMMIT

--ROLLBACK ?
--Ger ej error till andra




SELECT c.CustomerID, c.ModifiedDate
FROM Sales.Customer AS c WITH(REPEATABLEREAD)
WHERE c.CustomerID = 2
