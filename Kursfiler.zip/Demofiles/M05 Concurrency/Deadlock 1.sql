--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.


--Skapa nedanst�ende f�r att f�nga deadlocks:
IF EXISTS (SELECT * FROM sys.server_event_sessions WHERE name = 'Deadlocks')
    DROP EVENT SESSION [Deadlocks] ON SERVER;
GO
CREATE EVENT SESSION [Deadlocks] ON SERVER 
ADD EVENT sqlserver.xml_deadlock_report(
    ACTION(sqlserver.database_name))
ADD TARGET package0.event_file(SET filename=N'C:\X\Deadlocks',max_file_size=(1024),max_rollover_files=(3))
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO

--Autostarta vid SQL Server boot
-- ALTER EVENT SESSION [Deadlocks] ON SERVER 
--  WITH (STARTUP_STATE=ON)

 --Starta
ALTER EVENT SESSION Deadlocks 
ON SERVER
STATE = START


--Generera deadlock
BEGIN TRAN

UPDATE Adventureworks.Production.Product
SET Color = 'Soylent gr�n'
WHERE ProductID = 2

SELECT p.ProductID, p.Color, p.ListPrice
FROM Adventureworks.Production.Product AS p


--Vilken vi nu vill g�ra...
ROLLBACK
COMMIT

--SET DEADLOCK_PRIORITY LOW | HIGH | NORMAL | ...

--Hur m�nga millisekunder vill vi v�nta max p� ett 
--l�s?
--SET LOCK_TIMEOUT 2000

--Analysera med Brent Ozars sp_blitzlock
EXEC sp_blitzlock

 @EventSessionname = 'Deadlocks'



