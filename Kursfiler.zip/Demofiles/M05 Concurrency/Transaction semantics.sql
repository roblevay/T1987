--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

RAISERROR('K�r inte allt!', 21, 1) WITH LOG
GO

SELECT 'hej'

--Auto-commit, "implicit transaktion", default
UPDATE...

INSERT ...


--Explicit transaktion
BEGIN TRAN 
	UPDATE...
	DELETE...
	INSERT...
COMMIT --ROLLBACK


--Sl� av auto-commit
SET IMPLICIT_TRANSACTIONS ON
SELECT --eller delete, insert, update, -.....
--Nu har det startats en transaktion
COMMIT --ROLLBACK



--N�stlade transaktioner, undvik
BEGIN TRAN
 UPDATE
   BEGIN TRAN
    DELETE
   COMMIT
 INSERT
COMMIT


SELECT @@TRANCOUNT

BEGIN TRAN  -- +1
COMMIT		-- -1
ROLLBACK	-- ->0

BEGIN TRAN
UPDATE
  BEGIN TRAN
   DELETE
  ROLLBACK
INSERT
ROLLBACK

SELECT s.session_id, s.transaction_isolation_level, s.open_transaction_count
FROM sys.dm_exec_sessions as s
ORDER BY open_transaction_count DESC

/* transaction_isolation_level
0 = Unspecified
1 = ReadUncommitted
2 = ReadCommitted
3 = RepeatableRead
4 = Serializable
5 = Snapshot
*/

--Se upp! Def finns ingen rollback!
BEGIN TRAN
	INSERT
	UPDATE --Ponera en error
	DELETE
COMMIT

--Felhantering / transaktionshantering
BEGIN TRY
  BEGIN TRAN
   INSERT
   UPDATE
   DELETE
  COMMIT
END TRY

BEGIN CATCH
 ROLLBACK
 RAISERROR --eller THROW
END CATCH


--Annat s�tt att jobba
SET XACT_ABORT ON --Batchen termineras vid en error, och transaktionen rullas tillbaka
BEGIN TRAN
	INSERT
	UPDATE
	DELETE
COMMIT


-- http://www.sommarskog.se/error_handling/Part1.html



--Savepoint (m�jligg�r partiell rollback)
BEGIN TRAN V�rdel�stNamn
UPDATE
  SAVE TRAN myTran
  DELETE
  ROLLBACK TRAN myTran
INSERT
COMMIT


--Visar �ldsta �ppna transaktionen
DBCC OPENTRAN(Adventureworks)

--Vad hindrar att loggen t�ms?
SELECT d.name, d.log_reuse_wait_desc FROM sys.databases AS d
