--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

USE tempdb
SET NOCOUNT ON

DROP TABLE IF EXISTS t
GO

CREATE TABLE t(c1 int identity, c2 char(200) default 'hej')
GO

INSERT INTO t(c2)
SELECT TOP(10000) 'Hej' FROM sys.columns a, sys.columns b
GO

SELECT * FROM t


BEGIN TRAN
UPDATE t SET c2 = 'HUPPSAN' WHERE c1 = 2

--K�r nu nedan i en annan session
SELECT * FROM t
WHERE c1 = 5 

--Blockerad, SQL Server m�ste titta p� varje rad.

ROLLBACK

--Se till att vi har ett l�mpligt index
CREATE INDEX x ON t(c1)
--Och g�r nu om ovan
--Inte blockerad
