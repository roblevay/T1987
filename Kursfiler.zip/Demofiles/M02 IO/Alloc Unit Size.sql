--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Blanda inte ihop Allocation Unit Size och Block Size:
-- https://blog.purestorage.com/what-is-sql-servers-io-block-size/

/*
I SQL Server och generell lagringsterminologi finns det en skillnad mellan **Block Size** och **Allocation Unit Size**, �ven om de b�da �r relaterade till hur data lagras och hanteras. H�r �r en f�rklaring av vad varje begrepp inneb�r och hur de skiljer sig �t:

### 1. **Block Size (SQL Server)**
- **Block Size** avser storleken p� de grundl�ggande datalagringsblocken som SQL Server anv�nder f�r att lagra information i sitt buffertcache och p� disken. I SQL Server lagras data i **sidor** om 8 KB.
  
  - En **data page** i SQL Server �r alltid 8 KB.
  - N�r SQL Server skriver eller l�ser data fr�n disk g�r den det i dessa 8 KB-block, och detta g�ller f�r alla I/O-operationer.
  - Block Size �r d�rf�r fast och definierad av SQL Server och styr hur den l�ser/skriver sm� segment av data till disken.

### 2. **Allocation Unit Size (filsystemniv�)**
- **Allocation Unit Size**, eller **Cluster Size**, �r ett filsystemkoncept som avg�r den minsta m�ngden data som kan tilldelas p� en diskpartition. Denna inst�llning best�ms vid formatering av en h�rddisk och kan vara olika beroende p� filsystem (t.ex. NTFS) och storleken p� partitionen.
  
  - Det kan vara till exempel 4 KB, 8 KB, 64 KB, osv., och det best�mmer hur stora "block" disken anv�nder f�r att hantera filer.
  - Om filens storlek inte fyller hela allokeringsenheten anv�nds �nd� hela den enheten p� disken.
  - F�r SQL Server �r en vanlig rekommendation att st�lla in **Allocation Unit Size** till 64 KB f�r databaser, eftersom SQL Server arbetar med stora datastrukturer som kan dra nytta av st�rre enheter.

### Skillnader och samband:
- **Block Size** i SQL Server �r alltid 8 KB och relaterar till SQL Server's egna interna datastrukturer. Den avg�r hur SQL Server hanterar data internt och hur den l�ser/lagrar data till sitt buffer cache.
  
- **Allocation Unit Size** �r p� filsystemniv� och avg�r hur disken hanterar allokering av utrymme f�r alla filer, inklusive SQL Server-datafiler. Ju st�rre Allocation Unit Size �r, desto b�ttre prestanda kan du f� f�r stora filer som databaser, eftersom f�rre allokeringsenheter beh�ver hanteras.

### Rekommendationer:
- F�r SQL Server �r det ofta rekommenderat att anv�nda en **Allocation Unit Size** p� 64 KB eftersom detta b�ttre matchar de stora m�ngder data som SQL Server hanterar.
  
- **Block Size** p� 8 KB �r fast i SQL Server och kan inte �ndras.

### Exempel:
- Om din **Allocation Unit Size** �r satt till 64 KB, och SQL Server's **Block Size** �r 8 KB, betyder det att n�r SQL Server skriver data till disk, s� kan upp till 8 SQL Server-block (64 KB totalt) skrivas i en allokeringsenhet. Detta matchar allts� v�l med hur SQL Server skriver stora m�ngder data effektivt.

Sammanfattningsvis kan man s�ga att **Block Size** (8 KB) �r SQL Server�s interna enhet f�r att hantera data, medan **Allocation Unit Size** �r en inst�llning p� filsystemniv� som styr hur datafiler och annan lagring hanteras p� disken.
*/