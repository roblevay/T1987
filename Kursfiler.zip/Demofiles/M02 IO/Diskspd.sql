--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

-- https://gallery.technet.microsoft.com/DiskSpd-a-robust-storage-6cd2f223
-- http://www.brentozar.com/archive/2015/09/getting-started-with-diskspd/
-- https://www.brentozar.com/archive/2019/11/how-to-use-crystaldiskmark-7-to-test-your-sql-servers-storage/

--20 sekunder
C:\diskspd\Diskspd.exe -b8K -d20 -h -L -o2 -t4 -r -w30 -c50M c:\diskspd\io.dat
C:\diskspd\Diskspd.exe -b64K -d20 -h -L -o2 -t4 -r -w30 -c50M c:\diskspd\io.dat

BACKUP DATABASE Adventureworks TO DISK='NUL'

--Visa Crystaldiskmark p� C:\Crystaldiskmark


										  