--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

-- Lasta med skrivningar
SET NOCOUNT ON
DECLARE @start datetime2(0) = SYSDATETIME()

WAITFOR DELAY '00:00:00'
WHILE DATEDIFF(ss, @start, SYSDATETIME()) < 300
BEGIN
	INSERT TSQL..insertTarget (date1)
	VALUES (GETDATE())

	WAITFOR DELAY '00:00:02';
END
