--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

-- Lasta med l�sningar
SET NOCOUNT ON
DECLARE @start datetime2(0) = SYSDATETIME()

WAITFOR DELAY '00:00:00'
WHILE DATEDIFF(ss, @start, SYSDATETIME()) < 300
BEGIN
	DBCC DROPCLEANBUFFERS
	SELECT AVG(d.LineTotal) FROM Adventureworks.Sales.SalesOrderDetail AS d

	WAITFOR DELAY '00:00:02';
END