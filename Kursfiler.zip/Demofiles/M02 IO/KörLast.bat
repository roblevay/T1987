start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastSkriv.sql
start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastRead.sql
start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastSkriv.sql
start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastRead.sql
start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastSkriv.sql
start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastRead.sql
start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastSkriv.sql
start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastRead.sql
start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastSkriv.sql
start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastRead.sql
start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastSkriv.sql
start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastRead.sql
start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastSkriv.sql
start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastRead.sql
start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastSkriv.sql
start SQLCMD /STK\A /i"C:\Kursfiler\Kurser\10987\10987_TiborDemo\Module 02"\LastRead.sql
pause