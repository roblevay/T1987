--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

/*
Example of plan forcing through Query Store
*/
--OBS, ska k�ras p� SQL Server 2022!

/**********************************************************************************************
Setup
**********************************************************************************************/

USE Adventureworks
GO

/*
--Ska funka med l�gre compatibility levels
ALTER DATABASE CURRENT SET COMPATIBILITY_LEVEL = 100
*/

--Det finns ett g�ng XE events kring detta, s�k f�r "hints"
SELECT p.name AS package, o.name, o.description
FROM sys.dm_xe_objects AS o
 INNER JOIN sys.dm_xe_packages AS p ON p.guid = o.package_guid
WHERE o.object_type = 'event'
AND o.name LIKE '%hint%'
ORDER BY name

--Nedan b�r g� parallellt
SELECT * FROM Sales.SalesOrderDetail ORDER BY OrderQty DESC

--Har vi n�gra hints?
SELECT	* FROM sys.query_store_query_hints

--Leta upp fr�gan via Query Store
SELECT query_sql_text, q.query_id
FROM sys.query_store_query_text qt
INNER JOIN sys.query_store_query q ON  qt.query_text_id = q.query_text_id
WHERE query_sql_text like N'%FROM Sales.SalesOrderDetail ORDER BY OrderQty%' and query_sql_text not like N'%query_store%';
GO

--Notera query_id fr�n ovan 8

--Sl�ng p� en hint
EXEC sp_query_store_set_hints @query_id=2, @value = N'OPTION(MAXDOP 1 )'

--B�r g� seriellt nu
SELECT * FROM Sales.SalesOrderDetail ORDER BY OrderQty DESC

--Notera Actual plan, finns info om att vi hintade via Query Store

--Info om v�ra hints
SELECT	* FROM sys.query_store_query_hints

--Remove the hint
EXEC sp_query_store_clear_hints @query_id = 2
GO

--Reset compat level
ALTER DATABASE CURRENT SET COMPATIBILITY_LEVEL = 160
