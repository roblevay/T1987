--S�tt Freight = 5 % av SubTotal f�r alla ordrar under 2012.

USE AdventureWorks;
GO
--*****Cursor*****
DECLARE @SalesOrderID int, 
        @SubTotal money;

DECLARE cur CURSOR LOCAL FAST_FORWARD FOR
    SELECT SalesOrderID, SubTotal
    FROM Sales.SalesOrderHeader
    WHERE OrderDate >= '20120101'
      AND OrderDate <  '20130101';

OPEN cur;

FETCH NEXT FROM cur INTO @SalesOrderID, @SubTotal;

WHILE @@FETCH_STATUS = 0
BEGIN
    -- �D�ligt� exempel: en rad i taget
    UPDATE Sales.SalesOrderHeader
    SET Freight = @SubTotal * 0.05
    WHERE SalesOrderID = @SalesOrderID;

    FETCH NEXT FROM cur INTO @SalesOrderID, @SubTotal;
END

CLOSE cur;
DEALLOCATE cur;
GO

--****Vanlig uppdatering************
USE AdventureWorks;
GO

-- S�tt frakten till 5 % av SubTotal f�r order under 2012
UPDATE soh
SET    Freight = soh.SubTotal * 0.05
FROM   Sales.SalesOrderHeader AS soh
WHERE  soh.OrderDate >= '20120101'
  AND  soh.OrderDate <  '20130101';
