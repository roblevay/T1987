--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

RAISERROR('K�r inte allt, h�rru!', 20, 1) WITH LOG
GO

--Jobba med plan cachen
USE Adventureworks

-------------------------------------------------------------------------------------------------------------------------------------------------------
--Hashar och handles:
-------------------------------------------------------------------------------------------------------------------------------------------------------

--SQL Handle, en per unik batch/procedure (trigger, function)
--Hashning av SQL texten. Inkluderar kommatecken, mellanslag etc.

--Plan Handle, en per exekveringsplan
--Hashning av exekveringsplanen. En SQL handle kan generera flera Plan Handles

--Query Hash
--Hash f�r query, parameteriserad.
--Dvs samma fr�ga med olika parametrar f�r samma Query Hash
...WHERE c = 23
...WHERE c = 45

...WHERE c = @1
...WHERE c = @1

--Query Plan Hash
--Samma som ovan, men f�r planen

--Exempel

DBCC FREEPROCCACHE
GO
SELECT p.FirstName, p.LastName, p.Title FROM Person.Person AS p WHERE p.FirstName = 'Joe'
GO
SELECT p.FirstName, p.LastName, p.Title FROM Person.Person AS p WHERE p.FirstName = 'Lisa'
GO
SELECT p.FirstName, p.LastName, p.Title FROM Person.Person AS p WHERE p.FirstName = 'Lisa'
GO

SELECT sql_handle, plan_handle, execution_count, query_hash, sql.text
FROM sys.dm_exec_query_stats AS qs
CROSS APPLY sys.dm_exec_sql_text (qs.plan_handle) AS sql
WHERE sql.text LIKE '%FROM Person.Person%'

SELECT * FROM sys.dm_exec_query_stats

-------------------------------------------------------------------------------------------------------------------------------------------------------
--Exempel p� fr�ga som h�mtar dyra fr�gor fr�n plancachen
-------------------------------------------------------------------------------------------------------------------------------------------------------
SELECT TOP(100)
    query_hash, query_plan_hash,
    cached_plan_object_count,
    execution_count,
    total_cpu_time_ms, total_elapsed_time_ms,
    total_logical_reads, total_logical_writes, total_physical_reads,
    sample_database_name, sample_object_name,
    sample_statement_text, query_plan
	
FROM
(
    SELECT
        query_hash, query_plan_hash,
        COUNT (*) AS cached_plan_object_count,
        MAX (plan_handle) AS sample_plan_handle,
        SUM (execution_count) AS execution_count,
        SUM (total_worker_time)/1000 AS total_cpu_time_ms,
        SUM (total_elapsed_time)/1000 AS total_elapsed_time_ms,
        SUM (total_logical_reads) AS total_logical_reads,
        SUM (total_logical_writes) AS total_logical_writes,
        SUM (total_physical_reads) AS total_physical_reads
    FROM sys.dm_exec_query_stats
    GROUP BY query_hash, query_plan_hash
) AS plan_hash_stats
CROSS APPLY
(
    SELECT TOP 1
        qs.sql_handle AS sample_sql_handle, qp.query_plan,
        qs.statement_start_offset AS sample_statement_start_offset,
        qs.statement_end_offset AS sample_statement_end_offset,
        CASE
            WHEN [database_id].value = 32768 THEN 'ResourceDb'
            ELSE DB_NAME (CONVERT (int, [database_id].value))
        END AS sample_database_name,
        OBJECT_NAME (CONVERT (int, [object_id].value), CONVERT (int, [database_id].value)) AS sample_object_name,
        SUBSTRING (
            sql.[text],
            (qs.statement_start_offset/2) + 1,
            (
                (
                    CASE qs.statement_end_offset
                        WHEN -1 THEN DATALENGTH(sql.[text])
                        WHEN 0 THEN DATALENGTH(sql.[text])
                        ELSE qs.statement_end_offset
                    END
                    - qs.statement_start_offset
                )/2
            ) + 1
        ) AS sample_statement_text
    FROM sys.dm_exec_sql_text(plan_hash_stats.sample_plan_handle) AS sql 
    INNER JOIN sys.dm_exec_query_stats AS qs ON qs.plan_handle = plan_hash_stats.sample_plan_handle
    CROSS APPLY sys.dm_exec_plan_attributes (plan_hash_stats.sample_plan_handle) AS [object_id]
    CROSS APPLY sys.dm_exec_plan_attributes (plan_hash_stats.sample_plan_handle) AS [database_id]
	CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
    WHERE [object_id].attribute = 'objectid'
        AND [database_id].attribute = 'dbid'
) AS sample_query_text
ORDER BY total_cpu_time_ms DESC;


-------------------------------------------------------------------------------------------------------------------------------------------------------
--Lite allm�nt om plan cachen
-------------------------------------------------------------------------------------------------------------------------------------------------------

--Info om cache hanterarna
SELECT *
FROM sys.dm_os_memory_cache_counters
WHERE name in ('Object Plans','SQL Plans','Bound Trees');


-------------------------------------------------------------------------------------------------------------------------------------------------------
--Kostnad f�r planer, samt lite annat
-------------------------------------------------------------------------------------------------------------------------------------------------------
SELECT 
 p.objtype
,p.usecounts
,e.original_cost
,e.current_cost
,p.size_in_bytes
,e.disk_ios_count
,e.context_switches_count
,e.pages_kb AS memory_kB
,e.[type] AS cache_type
,st.[text]
FROM sys.dm_exec_cached_plans AS p
 CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS st
 INNER JOIN sys.dm_os_memory_cache_entries AS e ON p.memory_object_address = e.memory_object_address
WHERE p.cacheobjtype = 'Compiled Plan'
  AND e.type IN ('CACHESTORE_SQLCP','CACHESTORE_OBJCP')
  --AND e.original_cost <> e.current_cost
ORDER BY e.[type], p.objtype, e.current_cost DESC;



------------------------------------------------------------------------------------------------------------------------------------------------------------
--T�m cachen
-------------------------------------------------------------------------------------------------------------------------------------------------------
--T�m buffer pool (data cachen)
CHECKPOINT
DBCC DROPCLEANBUFFERS

--T�m plancachen
DBCC FREEPROCCACHE --WITH NO_INFOMSGS

--T�m plancachen f�r en viss resurspool (om Resource Governor anv�nds)
DBCC FREESYSTEMCACHE ('SQL Plans', 'LimitedIOPool')
DBCC FREESYSTEMCACHE ('LimitedIOPool')

--T�m en viss cache
DBCC FREESYSTEMCACHE('SQL PLANS')

--T�m plancachen f�r viss databas
DBCC FLUSHPROCINDB(4) 

--Kom i 2016
USE Adventureworks
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE; 
USE master
GO

CREATE OR ALTER PROC myproc AS SELECT * FROM AdventureWorks.Person.Person
GO
EXEC myproc
GO
--Ta bort en specifik plan, exempel �r f�r en proc
DECLARE @plan_handle varbinary(64)
SET @plan_handle = (
	SELECT cp.plan_handle--, cp.objtype, cp.usecounts, DB_NAME(st.dbid) AS [DatabaseName]
	FROM sys.dm_exec_cached_plans AS cp CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS st 
	WHERE OBJECT_NAME (st.objectid)	LIKE N'myProc' )

DBCC FREEPROCCACHE (@plan_handle)


SELECT COUNT(*) AS plan_count FROM sys.dm_exec_cached_plans
DBCC FREEPROCCACHE
SELECT COUNT(*) AS plan_count FROM sys.dm_exec_cached_plans

--F�r mer info, se http://www.sqlskills.com/blogs/glenn/eight-different-ways-to-clear-the-sql-server-plan-cache/


-------------------------------------------------------------------------------------------------------------------------------------------------------
--�teranv�ndning av planer
-------------------------------------------------------------------------------------------------------------------------------------------------------

DROP INDEX IF EXISTS x ON Sales.SalesOrderDetail
CREATE INDEX x ON Sales.SalesOrderDetail(OrderQty)
GO

--Proc f�r att studera cachen
CREATE OR ALTER PROC ShowPlans
AS
--Ny version 2022-03-10 
SELECT 
 DB_NAME(sql.dbid) AS db_name_
,OBJECT_NAME(sql.objectid) AS object_name_
,p.cacheobjtype
,p.objtype
,s.execution_count
,s.total_worker_time --Add whatever measures you want
,p.size_in_bytes / 1024 AS size_in_kB
,SUBSTRING (sql.[text],(s.statement_start_offset/2) + 1,((CASE s.statement_end_offset WHEN -1 THEN DATALENGTH(sql.[text]) WHEN 0 THEN DATALENGTH(sql.[text]) ELSE s.statement_end_offset END - s.statement_start_offset)/2) + 1) AS text_query
,sql.text AS text_batch
,qp.query_plan
--,*
FROM sys.dm_exec_query_stats  AS s 
INNER JOIN sys.dm_exec_cached_plans AS p ON s.plan_handle = p.plan_handle
CROSS APPLY sys.dm_exec_sql_text(s.plan_handle) AS sql
CROSS APPLY sys.dm_exec_query_plan(s.plan_handle) AS qp
WHERE sql.dbid <> 32767 --Igorera resursdatabasen
ORDER BY total_worker_time DESC --Whatever you want
--SELECT 
-- c.cacheobjtype
--,c.objtype
--,c.usecounts
--,c.size_in_bytes / 1024 AS size_in_kB
--,OBJECT_NAME(objectid) AS object_name_
--,t.text AS theSql
--FROM sys.dm_exec_cached_plans AS c CROSS APPLY sys.dm_exec_sql_text(c.plan_handle) AS t
--WHERE dbid = DB_ID('Adventureworks')
GO

-------------------------------------------------------------------------------------------------------------------------------------------------------
--Ad-hoc, baserar sig p� exakt text-matchning
-------------------------------------------------------------------------------------------------------------------------------------------------------
USE Adventureworks
SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = 34

--Studera cachen
EXEC ShowPlans

--T�m cachen
DBCC FREEPROCCACHE

--K�r fr�gan igen, med olika v�rden f�r OrderQty
SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = 34
GO
SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = 38
GO
SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = 31
GO
SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = 30
GO 6
SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = 32
GO

EXEC ShowPlans

--"Plan cache bloat"

--Hur mycket minne g�r �t till att cache eng�ngplaner
SELECT 
 c.usecounts
,COUNT(*) AS antal
,SUM(c.size_in_bytes / (1024 * 1024.0)) AS size_in_MB
FROM sys.dm_exec_cached_plans AS c
--WHERE c.usecounts = 1
GROUP BY c.usecounts
ORDER BY usecounts ASC
--Om m�nga GB f�r Usecount = 1, �verv�g "optimize for adhoc workloads"

--K�r "Generate lots of ad-hocs plans.sql"
--DBCC FREEPROCCACHE
--EXEC CreateAdHocPlans @NoOfPlans = 10000

--F�ljande script skapar ad-hoc planer, 27 s
DECLARE @i INT = 1;
DECLARE @sql NVARCHAR(MAX);

WHILE @i <= 500
BEGIN
    -- Skapa en unik SQL-fr�ga med olika strukturer per iteration
    SET @sql = 'SELECT ' + CAST(@i AS NVARCHAR(5)) + ' AS TestColumn ' + 
               ', ' + CAST(@i*2 AS NVARCHAR(10)) + ' AS DoubleValue ' +
               ' FROM sys.objects WHERE object_id = ' + CAST(@i AS NVARCHAR(10)) + ' OR object_id = object_id';

    -- K�r dynamisk SQL f�r att skapa unika ad-hoc query planer
    EXEC sp_executesql @sql;

    SET @i = @i + 1;
END;



--To find the number of single-use cached plans, run the following query:
SELECT objtype,
    cacheobjtype,
    SUM(refcounts) AS AllRefObjects,
    SUM(CAST(size_in_bytes AS BIGINT)) / 1024 / 1024 AS SizeInMB
FROM sys.dm_exec_cached_plans
WHERE objtype = 'Adhoc'
    AND usecounts = 1
GROUP BY objtype, cacheobjtype;

--Hur mycket minne enligt ovan? 
-- 10000 planer, 547 MB
-- 10000 "planer", 4.3 MB

--Cacha inte eng�ngsplaner
EXEC sp_configure 'optimize for ad hoc workloads', 1
RECONFIGURE

--Finns �ven p� databasniv�
SELECT * FROM sys.database_scoped_configurations WHERE name = 'OPTIMIZE_FOR_AD_HOC_WORKLOADS'

--G�r om det f�rsta testet

--Notera Compiled Plan Stub. Inte f�rr�n vid andra exekveringen s� blir det en "riktig" plan.

--Notera dock att vi inte sparar CPU och att vi tappar "sp�rbarhet" i Query Store. Inte sj�lvklart...
-- https://bornsql.ca/blog/dont-optimize-for-ad-hoc-workloads-as-a-best-practice/

--�terst�ll
EXEC sp_configure 'optimize for ad hoc workloads', 0
RECONFIGURE

--Ovan sparar bara minne.
--Om ni har symptom enligt nedan...:
-- H�g CPU
-- H�g oms�ttning i plancachen (planer f�rsvinner fort)
--   Ovan medf�r att leta efter dyra fr�gor baserat p� plancachen inte funkat
-- H�g Compilations/sec (kanske lika h�g som Batch Requests/sec)
--I s� fall, s� identifiera databasen och �verv�g parameterization forced

--�ldsta planen i cache
SELECT MIN(creation_time)
FROM sys.dm_exec_query_stats;

--Som histogram
WITH
 t AS (
  SELECT
    DATEDIFF_BIG(MINUTE, creation_time, GETDATE()) AS minutes_
   ,DATEDIFF_BIG(HOUR, creation_time, GETDATE()) AS hours_
   ,DATEDIFF_BIG(DAY, creation_time, GETDATE()) AS days_
   FROM sys.dm_exec_query_stats
   )
--SELECT days_, COUNT(*) AS plans FROM t GROUP BY days_ ORDER BY days_
--SELECT hours_, COUNT(*) AS plans FROM t GROUP BY hours_ ORDER BY hours_
SELECT minutes_, COUNT(*) AS plans FROM t GROUP BY minutes_ ORDER BY minutes_



---------------------------------------------------------------------------------------
--Simple Parameterization, ocks� kallat "auto-parametiserad"
-- https://docs.microsoft.com/en-us/previous-versions/sql/sql-server-2008-r2/ms186219(v=sql.105)

DBCC FREEPROCCACHE

SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderID = 43662
GO
SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderID = 43663
GO
SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderID = 43664
GO 6
SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderID = 43665
GO
SELECT * FROM Sales.SalesOrderHeader WHERE SalesOrderID = 1

-- V�rde som vi s�ker p� p�verkar inte planen (= och unikt index)
EXEC ShowPlans
--Notera Prepared. Adhoc �r bara f�r att matcha fr�gan mot plancachen (ingen riktig plan - se storleken)

--Varf�r ena exakt och andra autoparametiserad?


--Tvingad autoparameterisering

ALTER DATABASE Adventureworks SET PARAMETERIZATION FORCED

--G�r om det f�rsta testet

--�terst�ll
ALTER DATABASE Adventureworks SET PARAMETERIZATION SIMPLE



-------------------------------------------------------------------------------------------------------------------------------------------------------
--Explicit parameterisering, anv�nds av m�nga programmeringsgr�nssnitt
-------------------------------------------------------------------------------------------------------------------------------------------------------
SET STATISTICS IO ON
DBCC FREEPROCCACHE

EXEC sp_executesql 
 @stmt =	N'SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = @qty'
,@params =	N'@qty smallint'
,@qty = 1

EXEC ShowPlans

--Notera objtype = Prepared och parameternamnet i theSql kolumnen

--S�k p� annat v�rde, h�gre selektivitet
EXEC sp_executesql 
 @stmt =	N'SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = @qty'
,@params =	N'@qty smallint'
,@qty = 35

EXEC ShowPlans

--Men �r detta optimalt?

--Plan best�ms vid f�rsta exekveringen.
--Antingen cachar vi planer eller ej!
-- Tips: http://www.sommarskog.se/query-plan-mysteries.html

--Kostnad f�r planframtagning kontra run-time (SET STATISTICS TIME ON)
SET STATISTICS IO ON
SET STATISTICS IO OFF
SET STATISTICS TIME ON
DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS
SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = 2
SET STATISTICS TIME OFF


-------------------------------------------------------------------------------------------------------------------------------------------------------
--sp_prepare och sp_execute, anv�nds av vissa programmeringsgr�nssnitt (JDBC)
-------------------------------------------------------------------------------------------------------------------------------------------------------
SET STATISTICS IO ON
DBCC FREEPROCCACHE

--Ta med actual execution plan

--P�minner om sp_executesql, men sniffar inte parametrar (behandlar som ok�nt/variabel).
DECLARE @q1 INT;  
EXEC sp_prepare @q1 OUTPUT,   
    N'@qty int',  
    N'SELECT * FROM Sales.SalesOrderDetail WHERE OrderQty = @qty';  
	SELECT @q1
EXEC sp_execute @q1, N'1';  
EXEC sp_execute @q1, N'34';  
EXEC sp_unprepare @q1;  

--Hur m�nga reader estimeras (filter operatorn)?
--Det spelar ingen roll vilken som k�rs f�rst, den g�r p� 
--  densitet om det finns 
--  annars h�rdkodade procent-satser



-------------------------------------------------------------------------------------------------------------------------------------------------------
--Stored procedures (och triggers, functions)
-------------------------------------------------------------------------------------------------------------------------------------------------------
GO

CREATE OR ALTER PROC GetOrderByQty
 @qty smallint				--"parameter sniffing"
 --WITH RECOMPILE
AS
SELECT * 
FROM Sales.SalesOrderDetail 
WHERE OrderQty = @qty 
--OPTION(RECOMPILE)
--OPTION(OPTIMIZE FOR(@qty = '3')) --"planstabilitet"/f�ruts�gbarhet
--OPTION(OPTIMIZE FOR UNKNOWN) -- Samma som ALTER DATABASE SCOPED CONFIGURATION SET PARAMETER_SNIFFING = OFF;
GO

SET STATISTICS IO ON

--Kostnad 
DBCC FREEPROCCACHE
EXEC GetOrderByQty 34 --(parameter sniffing)
EXEC GetOrderByQty 1
EXEC GetOrderByQty 1 WITH RECOMPILE --Privat plan f�r detta exekveringstillf�lle


--L�gg till WITH RECOMPILE
--Betala f�r planframtagning vid varje exekvering

--L�gg till OPTION(RECOMPILE) (query hint)
--Betala f�r planframtagning vid varje exekvering, bara f�r denna fr�ga

--L�gg till OPTION(OPTIMIZE FOR @a = v�rde) (query hint)
--Vi s�ger utifr�n vilket v�rde selektivitet ska kalkyleras, vi f�r �teranv�ndning

--L�gg till OPTION(OPTIMIZE FOR UNKNOWN) (query hint)
--"Vet ej v�rdet", g� p� h�rdkodade v�rden (eller densitet om det �r g�rbart). Vi f�r �teranv�ning.
--Notera estimated number of rows

--Kan ocks� g�ra sp_recompile 'procnamn'





-------------------------------------------------------------------------------------------------------------------------------------------------------
--Studera planattribut
-------------------------------------------------------------------------------------------------------------------------------------------------------
DBCC FREEPROCCACHE

--Vi har allts� proceduren:
EXEC GetOrderByQty 34

DBCC USEROPTIONS
SELECT @@OPTIONS

--Nu vill vi ha en till plan i cachen, f�r samma procedur
SET ARITHABORT OFF
EXEC GetOrderByQty 1
SET ARITHABORT ON --�terst�ll efter oss



SELECT p.objtype, p.bucketid, p.plan_handle, qp.query_plan, pa.value AS set_options, st.[text]
FROM sys.dm_exec_cached_plans AS p
 CROSS APPLY sys.dm_exec_query_plan(p.plan_handle) AS qp
 CROSS APPLY sys.dm_exec_sql_text(p.plan_handle) AS st 
 CROSS APPLY sys.dm_exec_plan_attributes(p.plan_handle) AS pa
WHERE st.objectid = object_id('GetOrderByQty')
AND pa.attribute = 'set_options'


--Studera plan attribut, fr�ga fr�n ovan
--Notera tv� planer f�r samma fr�ga. Och i detta fall �r dom inte samma

--Titta p� attribut f�r n�gon godtycklig plan

DECLARE @some_plan varbinary(64)

SET @some_plan = (SELECT TOP(1) plan_handle FROM sys.dm_exec_cached_plans)

SELECT * 
FROM  sys.dm_exec_plan_attributes(@some_plan)
WHERE is_cache_key = 1


--Dynamic search conditions
-- https://www.sommarskog.se/dyn-search.html

