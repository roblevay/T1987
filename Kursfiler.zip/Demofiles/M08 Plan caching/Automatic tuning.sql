--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--------------------------------------------------------------------------------------------------------------------
--Automatic Tuning (2017)
--------------------------------------------------------------------------------------------------------------------

--Turn on Query Store, if not already done
/*
ALTER DATABASE AdventureworksDW SET QUERY_STORE = OFF
ALTER DATABASE AdventureworksDW SET QUERY_STORE= ON
SELECT * FROM sys.database_query_store_options;


*/

--Missa inte detta steg!!!
USE AdventureworksDW


ALTER DATABASE AdventureworksDW SET COMPATIBILITY_LEVEL = 150

--------------------------------------------------------------------------------------------
--XE trace to see details
CREATE EVENT SESSION AutomaticTuning ON SERVER 
ADD EVENT qds.automatic_tuning_config_change,
ADD EVENT qds.automatic_tuning_diagnostics,
ADD EVENT qds.automatic_tuning_error,
ADD EVENT qds.automatic_tuning_plan_regression_detection_check_completed,
ADD EVENT qds.automatic_tuning_plan_regression_verification_check_completed,
ADD EVENT qds.automatic_tuning_recommendation_expired,
ADD EVENT qds.automatic_tuning_state_change
WITH (MAX_DISPATCH_LATENCY=1 SECONDS)
GO

ALTER EVENT SESSION AutomaticTuning ON SERVER
STATE = start
--/XE trace
--------------------------------------------------------------------------------------------

--------------------------------------
--See if we can get a recommendation:
USE AdventureworksDW
DROP TABLE IF EXISTS auto_tuned;

CREATE TABLE auto_tuned (
 type int
,name nvarchar(200)
--,index ncci nonclustered columnstore (type)
,index ix_type(type)
)

--A row with the value 1 in the "type" column
INSERT INTO auto_tuned(type, name) VALUES (1, 'Single')

--4,000,000 rows with the value 2 in the "type" column, 28 s
INSERT INTO auto_tuned(type, name) SELECT TOP(999999) 2 AS type, o.name FROM sys.objects, sys.all_columns o
INSERT INTO auto_tuned(type, name) SELECT TOP(999999) 2 AS type, o.name FROM sys.objects, sys.all_columns o
--INSERT INTO auto_tuned(type, name) SELECT TOP(999999) 2 AS type, o.name FROM sys.objects, sys.all_columns o
--INSERT INTO auto_tuned(type, name) SELECT TOP(999999) 2 AS type, o.name FROM sys.objects, sys.all_columns o
--GO

SELECT TOP(10) * FROM auto_tuned 

ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE 
SET STATISTICS IO ON
--Low selectivity, scan
EXECUTE sp_executesql @stmt = N'SELECT COUNT(name) FROM auto_tuned WHERE type = @type', @params = N'@type int', @type = 2

--Run a few times, again with low selectivity (scan), 38 s
EXECUTE sp_executesql @stmt = N'SELECT COUNT(name) FROM auto_tuned WHERE type = @type', @params = N'@type int', @type = 2
GO 30

--Empty the cache and run query with high selectivity
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE
EXECUTE sp_executesql @stmt = N'SELECT COUNT(name) FROM auto_tuned WHERE type = @type', @params = N'@type int', @type = 1

--Now we got seek, which is good with few rows. Note the I/O.
SET STATISTICS IO ON

--But now we also get seek with many rows - here scan is better.
EXECUTE sp_executesql @stmt = N'SELECT COUNT(name) FROM auto_tuned WHERE type = @type', @params = N'@type int', @type = 2
GO

SET STATISTICS IO OFF
--Turn off exec plan

--Run 15 times, so we can compare (query store needs a number of executions) 126 s
EXECUTE sp_executesql @stmt = N'SELECT COUNT(name) FROM auto_tuned WHERE type = @type', @params = N'@type int', @type = 2
GO 15

--SELECT * FROM sys.database_query_store_options;


--We can retrieve "plan regressions" from sys.dm_db_tuning_recommendations
SELECT * FROM sys.dm_db_tuning_recommendations

--Slightly more refined question. Note the JSON...
SELECT reason, score,
      script = JSON_VALUE(details, '$.implementationDetails.script'),
      planForceDetails.*,
      estimated_gain = (regressedPlanExecutionCount+recommendedPlanExecutionCount)
                  *(regressedPlanCpuTimeAverage-recommendedPlanCpuTimeAverage)/1000000,
      error_prone = IIF(regressedPlanErrorCount>recommendedPlanErrorCount, 'YES','NO')
FROM sys.dm_db_tuning_recommendations
  CROSS APPLY OPENJSON (Details, '$.planForceDetails')
				WITH (  query_id int '$.queryId',
						current_plan_id int '$.regressedPlanId',
						recommended_plan_id int '$.recommendedPlanId',
						regressedPlanErrorCount int,
						recommendedPlanErrorCount int,
						regressedPlanExecutionCount int,
						regressedPlanCpuTimeAverage float,
						recommendedPlanExecutionCount int,
						recommendedPlanCpuTimeAverage float
					  ) as planForceDetails;


--We can now execute what we have in the "script" column if we want

--Or we turn on automatic tuning
ALTER DATABASE current SET AUTOMATIC_TUNING ( FORCE_LAST_GOOD_PLAN = ON ) --Force last good plan �r den enda som finns i 2017

--------------------------------------------------------------------------------------------------------------------
--In Azure SQL Database we also have "Automatic index management":
--Add index
--Remove index
--Se:
-- https://docs.microsoft.com/en-us/sql/relational-databases/automatic-tuning/automatic-tuning?view=sql-server-2017

--The internals
-- https://www.microsoft.com/en-us/research/publication/automatically-indexing-millions-of-databases-in-microsoft-azure-sql-database/


--------------------------------------------------------------------------------------------------------------------
--St�da
--------------------------------------------------------------------------------------------------------------------
DROP INDEX IF EXISTS UnitCost ON FactProductInventory
/*
ALTER DATABASE AdventureworksDW SET QUERY_STORE = OFF
*/
