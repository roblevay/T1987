--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Antal och storlek p� alla planer som bara anv�nts en g�ng
SELECT COUNT(*) AS single_use_plans, SUM(size_in_bytes) / 1024.0 / 1024.0 AS size_in_mb
FROM sys.dm_exec_cached_plans
CROSS APPLY sys.dm_exec_sql_text(plan_handle)
WHERE objtype IN ('Adhoc', 'Prepared') 
AND usecounts = 1

--Exempel p� fr�ga f�r att titta p� statistik f�r SQL-fr�gor
SELECT TOP(10) 
 OBJECT_NAME(st.objectid, st.dbid) AS obj_name
,qs.creation_time
,qs.last_execution_time
,SUBSTRING(st.[text], (qs.statement_start_offset/2)+1 ,((CASE statement_end_offset WHEN -1 THEN DATALENGTH(st.[text]) ELSE qs.statement_end_offset END - qs.statement_start_offset)/2)+1) AS statement_text 
,query_plan
,total_worker_time 
,qs.execution_count 
,qs.total_elapsed_time / qs.execution_count AS avg_duration
,[text] AS batch_text
FROM sys.dm_exec_query_stats AS qs 
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st 
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
ORDER BY avg_duration DESC

--Motsvarande f�r bara procedurer
SELECT TOP(10) 
 OBJECT_NAME(st.objectid, st.dbid) AS obj_name
,qs.cached_time
,qs.last_execution_time
,query_plan
,total_worker_time 
,qs.execution_count 
,qs.total_elapsed_time / qs.execution_count AS avg_duration
,[text] AS batch_text
FROM sys.dm_exec_procedure_stats AS qs 
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st 
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
ORDER BY avg_duration DESC;

--J�mf�r de tv�
SELECT * FROM sys.dm_exec_query_stats
SELECT * FROM sys.dm_exec_procedure_stats
SELECT * FROM sys.dm_exec_trigger_stats