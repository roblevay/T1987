--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

-----------------------------------------------------------------------------------------------------------------
--Implicit typ konvertering p� kolumnsidan. Aj aj!
-----------------------------------------------------------------------------------------------------------------
-- http://sqlblog.karaszi.com/match-those-types/
-- https://www.sqlskills.com/blogs/jonathan/finding-implicit-column-conversions-in-the-plan-cache/

USE AdventureworksDW

----------------------------------------------------------------------------------------------------
--Om myFacts finns s� beh�vs inte nedan
EXEC sp_tableinfo 'myFacts'

--"Kopiera" en av tabellerna
DROP TABLE IF EXISTS myFacts
GO

--Detta tar 15 sekunder
SELECT * INTO myFacts FROM FactResellerSalesXL

----------------------------------------------------------------------------------------------------
--L�gg till en kolumn som �r varchar
ALTER TABLE myFacts ADD vCarrierTrackingNumber varchar(40)
GO

----------------------------------------------------------------------------------------------------
--Nu har vi tv� kolumner som ska ha samma info, en nvarchar och en annan varchar

--Tillse att dom har samma info, den tar 60 sekunder
UPDATE myFacts SET vCarrierTrackingNumber = CarrierTrackingNumber

SELECT TOP(10) f.SalesOrderNumber, f.SalesOrderLineNumber, f.CarrierTrackingNumber, f.vCarrierTrackingNumber
FROM myFacts AS f

----------------------------------------------------------------------------------------------------
--Se till att det finns index p� vCarrierTrackingNumber

--Dessa tar 20 sekunder
CREATE INDEX ix_CarrierTrackingNumber ON myFacts(CarrierTrackingNumber)
CREATE INDEX ix_vCarrierTrackingNumber ON myFacts(vCarrierTrackingNumber)
GO

--Vi kommer att s�ka efter B0A99CA6-0EDD
CREATE OR ALTER PROC TypeConversion 
@p_vCarrierTrackingNumber nvarchar(40)							--Parameter matchar inte kolumnens datatyp
AS
SELECT * FROM myFacts WHERE vCarrierTrackingNumber = @p_vCarrierTrackingNumber	--Parameter matchar inte kolumnens datatyp
--SELECT * FROM myFacts WHERE CAST(vCarrierTrackingNumber AS nvarchar(40)) = @p_vCarrierTrackingNumber	--Parameter matchar inte kolumnens datatyp
GO

CREATE OR ALTER PROC NoTypeConversion
@p_vCarrierTrackingNumber varchar(40)							--Nu matchar vi
AS
SELECT * FROM myFacts WHERE vCarrierTrackingNumber = @p_vCarrierTrackingNumber	--Nu matchar vi
GO

--J�mf�r exekveringsplanerna
SET STATISTICS IO ON
EXEC TypeConversion @p_vCarrierTrackingNumber = 'B0A99CA6-0EDD'
EXEC NoTypeConversion @p_vCarrierTrackingNumber = 'B0A99CA6-0EDD'


--Data type precedence
-- https://docs.microsoft.com/en-us/sql/t-sql/data-types/data-type-precedence-transact-sql