/* 0) Kolla aktuellt l�ge */
SELECT name, value, value_in_use
FROM sys.configurations
WHERE name = 'optimize for ad hoc workloads';
GO

/* ========== DEL A: OFF (standardbeteende) ========== */
EXEC sp_configure 'show advanced options', 1; RECONFIGURE;
EXEC sp_configure 'optimize for ad hoc workloads', 0; RECONFIGURE;
GO
DBCC FREEPROCCACHE;
GO

-- K�r en ad hoc-fr�ga EN g�ng
USE AdventureWorks;
GO
SELECT COUNT(*) AS c 
FROM Person.Person 
WHERE FirstName = 'Amy'; -- ADHOC DEMO
GO

-- Inspektera vad som cachats
SELECT TOP (10)
  cp.cacheobjtype,        -- f�rv�ntas: 'Compiled Plan'
  cp.objtype,             -- 'Adhoc'
  cp.usecounts,           -- 1
  cp.size_in_bytes,
  st.text
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) AS st
WHERE st.text LIKE '%ADHOC DEMO%';
GO


/* ========== DEL B: ON (ad hoc-optimering) ========== */
EXEC sp_configure 'optimize for ad hoc workloads', 1; RECONFIGURE;
GO
DBCC FREEPROCCACHE;
GO

-- F�rsta k�rningen: bara en "Compiled Plan Stub" lagras
USE AdventureWorks;
GO
SELECT COUNT(*) AS c 
FROM Person.Person 
WHERE FirstName = 'Amy'; -- ADHOC DEMO
GO

-- Titta i cachen: nu ska du se STUB
SELECT TOP (10)
  cp.cacheobjtype,        -- f�rv�ntas: 'Compiled Plan Stub'
  cp.objtype,             -- 'Adhoc'
  cp.usecounts,           -- 1
  cp.size_in_bytes,
  st.text
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) AS st
WHERE st.text LIKE '%ADHOC DEMO%';
GO

-- Andra k�rningen: nu skapas och lagras full plan
SELECT COUNT(*) AS c 
FROM Person.Person 
WHERE FirstName = 'Amy'; -- ADHOC DEMO
GO

-- Titta igen: nu b�r du se en full 'Compiled Plan'
SELECT TOP (10)
  cp.cacheobjtype,        -- f�rv�ntas: 'Compiled Plan'
  cp.objtype,             -- 'Adhoc'
  cp.usecounts,           -- 1 (eller 2 beroende p� �teranv�ndning)
  cp.size_in_bytes,
  st.text
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) AS st
WHERE st.text LIKE '%ADHOC DEMO%';
GO

/* (Valfritt) Summera minnesbesparing: stub vs full plan */
SELECT 
  cp.cacheobjtype,
  COUNT(*) AS plans,
  SUM(cp.size_in_bytes)/1024.0/1024.0 AS mb
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) AS st
WHERE st.text LIKE '%ADHOC DEMO%'
GROUP BY cp.cacheobjtype;
GO


--�terst�ll!
EXEC sp_configure 'show advanced options', 1; RECONFIGURE;
EXEC sp_configure 'optimize for ad hoc workloads', 0; RECONFIGURE;