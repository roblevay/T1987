
/* =========================================================
   Minimal demo: SIMPLE vs FORCED parameterization
   Kräver AdventureWorks. Kör i 2017/2019/2022.
   ========================================================= */

USE [master]
GO
ALTER DATABASE [AdventureWorks] SET COMPATIBILITY_LEVEL = 150
GO

USE master;
GO
IF DB_ID('AdventureWorks') IS NULL
BEGIN
  RAISERROR('AdventureWorks saknas.',16,1);
  RETURN;
END
GO

-- 0) Stäng av "optimize for ad hoc workloads" för tydlig demo
EXEC sp_configure 'show advanced options', 1;
RECONFIGURE WITH OVERRIDE;
EXEC sp_configure 'optimize for ad hoc workloads', 0;
RECONFIGURE WITH OVERRIDE;

USE AdventureWorks;
GO

/* ---------------------------------------------------------
   Hjälp: hitta två olika ProductID
--------------------------------------------------------- */
DECLARE @Common int = (
  SELECT TOP(1) ProductID
  FROM Sales.SalesOrderDetail
  GROUP BY ProductID
  ORDER BY COUNT(*) DESC
);
DECLARE @Rare int = (
  SELECT TOP(1) ProductID
  FROM Sales.SalesOrderDetail
  GROUP BY ProductID
  ORDER BY COUNT(*) ASC
);
PRINT CONCAT('Common=',@Common, ' Rare=', @Rare);

/* =========================================================
   DEL A: SIMPLE (default)  -> oftast två Adhoc, ingen reuse
   ========================================================= */
ALTER DATABASE AdventureWorks SET PARAMETERIZATION SIMPLE;
GO
DBCC FREEPROCCACHE; DBCC DROPCLEANBUFFERS;
GO

-- Batch 1 (en literal)
SELECT SalesOrderDetailID, SalesOrderID, ProductID, OrderQty, UnitPrice
FROM Sales.SalesOrderDetail
WHERE ProductID = 870;   -- byt gärna till @Common
GO

-- Batch 2 (annan literal)
SELECT SalesOrderDetailID, SalesOrderID, ProductID, OrderQty, UnitPrice
FROM Sales.SalesOrderDetail
WHERE ProductID = 897;   -- byt gärna till @Rare
GO

-- Inspektera: för SIMPLE ser du typiskt Adhoc-rader (literaltext)
SELECT cp.objtype, cp.cacheobjtype, cp.usecounts, cp.size_in_bytes/1024 size_kb,
       st.text
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) AS st
WHERE DB_NAME(st.dbid) = DB_NAME()
  AND st.text LIKE '%FROM Sales.SalesOrderDetail%'
  AND (st.text LIKE '%ProductID = 870%' OR st.text LIKE '%ProductID = 897%')
ORDER BY cp.objtype, cp.usecounts DESC;
GO


/* =========================================================
   DEL B: FORCED -> en Prepared-plan med parameter och reuse
   ========================================================= */
ALTER DATABASE AdventureWorks SET PARAMETERIZATION FORCED;
GO
DBCC FREEPROCCACHE; DBCC DROPCLEANBUFFERS;
GO

-- Batch 1
SELECT SalesOrderDetailID, SalesOrderID, ProductID, OrderQty, UnitPrice
FROM Sales.SalesOrderDetail
WHERE ProductID = 870;
GO

-- Batch 2
SELECT SalesOrderDetailID, SalesOrderID, ProductID, OrderQty, UnitPrice
FROM Sales.SalesOrderDetail
WHERE ProductID = 897;
GO

-- Leta specifikt efter en Prepared-plan med parameter (@…)
SELECT TOP (20)
       cp.objtype, cp.cacheobjtype, cp.usecounts, cp.size_in_bytes/1024 size_kb,
       st.text
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) AS st
WHERE DB_NAME(st.dbid) = DB_NAME()
  --AND cp.objtype = 'Prepared'
  --AND st.text LIKE '%FROM Sales.SalesOrderDetail%'
  --AND st.text LIKE '%ProductID = @%'
ORDER BY cp.usecounts DESC;
GO



-- Återställ om du vill
ALTER DATABASE AdventureWorks SET PARAMETERIZATION SIMPLE;
GO
EXEC sp_configure 'optimize for ad hoc workloads', 0;
RECONFIGURE WITH OVERRIDE;
GO

/* =====================================================================
   2) OPTIMIZE FOR AD HOC WORKLOADS (INSTANCE setting)
      - When ON, the first execution of an ad hoc query stores a "compiled plan stub".
      - On the second execution, SQL Server replaces the stub with a full plan.
      - This saves MEMORY (fewer full plans for one-off queries) but not CPU.
   ===================================================================== */

PRINT '--- 2) OPTIMIZE FOR AD HOC WORKLOADS DEMO ---';

-- NOTE: This is an instance-level setting via sp_configure.
--       There is no separate database-level setting. (Effect is visible per DB.)

-- Show current setting
EXEC sp_configure 'show advanced options', 1;
RECONFIGURE WITH OVERRIDE;
EXEC sp_configure 'optimize for ad hoc workloads';

-- Turn it ON for the lab
EXEC sp_configure 'optimize for ad hoc workloads', 1;
RECONFIGURE WITH OVERRIDE;

DBCC FREEPROCCACHE;
GO

-- First execution of an ad hoc query -> expect a plan STUB
SELECT COUNT(*) AS cnt
FROM Sales.SalesOrderDetail
WHERE ProductID = 870;
GO

-- Inspect cached entry -> expect "Compiled Plan Stub" with usecounts = 1
SELECT TOP (20)
       cp.cacheobjtype, cp.objtype, cp.usecounts, cp.size_in_bytes/1024 AS size_kb,
       st.text
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) AS st
WHERE cp.objtype = 'Adhoc'
  AND st.text LIKE '%FROM Sales.SalesOrderDetail%ProductID = 870%'
ORDER BY cp.usecounts DESC;
GO

-- Second execution of the same ad hoc text -> stub should be replaced by full plan
SELECT COUNT(*) AS cnt
FROM Sales.SalesOrderDetail
WHERE ProductID = 870;
GO

-- Inspect cached entry again -> expect "Compiled Plan" with higher size and usecounts >= 1
SELECT TOP (20)
       cp.cacheobjtype, cp.objtype, cp.usecounts, cp.size_in_bytes/1024 AS size_kb,
       st.text
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) AS st
WHERE (st.text LIKE '%FROM Sales.SalesOrderDetail%ProductID = 870%')
ORDER BY cp.usecounts DESC;
GO

-- Restore default OFF (if desired) after demo
EXEC sp_configure 'optimize for ad hoc workloads', 0;
RECONFIGURE WITH OVERRIDE;
GO


/* =====================================================================
   3) METHODS USED BY APIs
      a) sp_executesql – does parameter sniffing
      b) sp_prepare / sp_execute – no sniffing (like T-SQL variable semantics)
   ===================================================================== */

PRINT '--- 3a) sp_executesql (parameter sniffing) ---';

DBCC FREEPROCCACHE;
GO

-- Use the earlier-discovered @Rare and @Common values
DECLARE @Common int, @Rare int;
SELECT TOP (1) @Common = ProductID
FROM Sales.SalesOrderDetail GROUP BY ProductID ORDER BY COUNT(*) DESC;
SELECT TOP (1) @Rare = ProductID
FROM Sales.SalesOrderDetail GROUP BY ProductID ORDER BY COUNT(*) ASC;

-- Compile for RARE first -> plan becomes selective (loops + lookups likely)
DECLARE @stmt nvarchar(max) = N'
SELECT SalesOrderDetailID, SalesOrderID, ProductID, OrderQty, UnitPrice
FROM Sales.SalesOrderDetail
WHERE ProductID = @p';
DECLARE @params nvarchar(100) = N'@p int';

EXEC sp_executesql @stmt, @params, @p = 897;   -- first execution (compile happens here)
EXEC sp_executesql @stmt, @params, @p = 870; -- reuses the SAME (sniffed) plan
GO

-- Inspect plan XML and see the compiled parameter value inside <ParameterList>
SELECT TOP (5)
       cp.usecounts,
       st.text,
       qp.query_plan
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) AS st
CROSS APPLY sys.dm_exec_text_query_plan(cp.plan_handle, DEFAULT, DEFAULT) AS qp
WHERE st.text LIKE '%WHERE ProductID = @p%'
ORDER BY cp.usecounts DESC;
GO


PRINT '--- 3b) sp_prepare / sp_execute (no parameter sniffing) ---';

DBCC FREEPROCCACHE;
GO

-- Prepare a statement (optimizer does NOT sniff a specific value; behaves like UNKNOWN)
DECLARE @handle int;
EXEC sp_prepare @handle OUTPUT,
                N'@p int',
                N'SELECT SalesOrderDetailID, SalesOrderID, ProductID, OrderQty, UnitPrice
                  FROM Sales.SalesOrderDetail
                  WHERE ProductID = @p';

-- Execute with RARE then COMMON (same prepared plan, no sniffing effect)
EXEC sp_execute @handle, @Rare;
EXEC sp_execute @handle, @Common;

-- Show the single prepared plan and its XML (estimates are density-based/generic)
SELECT TOP (5)
       cp.usecounts,
       st.text,
       qp.query_plan
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) AS st
CROSS APPLY sys.dm_exec_text_query_plan(cp.plan_handle, DEFAULT, DEFAULT) AS qp
WHERE cp.objtype = 'Prepared'
  AND st.text LIKE '%WHERE ProductID = @p%'
ORDER BY cp.usecounts DESC;

-- Clean up prepared handle
EXEC sp_unprepare @handle;
GO


/* =====================================================================
   4) OBJECT PLANS (stored procedures) – does parameter sniffing
   ===================================================================== */

PRINT '--- 4) Stored procedure (parameter sniffing) ---';

DBCC FREEPROCCACHE;
GO

CREATE OR ALTER PROC dbo.Demo_GetSOD_ByProduct
    @ProductID int
AS
BEGIN
    SET NOCOUNT ON;
    SELECT SalesOrderDetailID, SalesOrderID, ProductID, OrderQty, UnitPrice
    FROM Sales.SalesOrderDetail
    WHERE ProductID = @ProductID;
END
GO

DECLARE @Common int, @Rare int;
SELECT TOP (1) @Common = ProductID
FROM Sales.SalesOrderDetail GROUP BY ProductID ORDER BY COUNT(*) DESC;
SELECT TOP (1) @Rare = ProductID
FROM Sales.SalesOrderDetail GROUP BY ProductID ORDER BY COUNT(*) ASC;

-- Compile for RARE first, then reuse for COMMON -> classic sniffing demo
EXEC dbo.Demo_GetSOD_ByProduct @ProductID = @Rare;
EXEC dbo.Demo_GetSOD_ByProduct @ProductID = @Common;
GO

-- Inspect the cached plan and see the compiled parameter value in XML
SELECT TOP (5)
       cp.usecounts,
       st.text,
       qp.query_plan
FROM sys.dm_exec_cached_plans AS cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) AS st
CROSS APPLY sys.dm_exec_text_query_plan(cp.plan_handle, DEFAULT, DEFAULT) AS qp
WHERE st.text LIKE '%Demo_GetSOD_ByProduct%'
ORDER BY cp.usecounts DESC;
GO

-- Quick fixes (compare behavior)
CREATE OR ALTER PROC dbo.Demo_GetSOD_ByProduct_Recompile
    @ProductID int
AS
BEGIN
    SET NOCOUNT ON;
    SELECT SalesOrderDetailID, SalesOrderID, ProductID, OrderQty, UnitPrice
    FROM Sales.SalesOrderDetail
    WHERE ProductID = @ProductID
    OPTION (RECOMPILE);  -- per-execution plan; no sniffing persistence
END
GO

CREATE OR ALTER PROC dbo.Demo_GetSOD_ByProduct_Unknown
    @ProductID int
AS
BEGIN
    SET NOCOUNT ON;
    SELECT SalesOrderDetailID, SalesOrderID, ProductID, OrderQty, UnitPrice
    FROM Sales.SalesOrderDetail
    WHERE ProductID = @ProductID
    OPTION (OPTIMIZE FOR UNKNOWN);  -- generic, density-based
END
GO

EXEC dbo.Demo_GetSOD_ByProduct_Recompile @ProductID = @Rare;
EXEC dbo.Demo_GetSOD_ByProduct_Recompile @ProductID = @Common;

EXEC dbo.Demo_GetSOD_ByProduct_Unknown @ProductID = @Rare;
EXEC dbo.Demo_GetSOD_ByProduct_Unknown @ProductID = @Common;
GO


/* =====================================================================
   CLEANUP (optional)
   ===================================================================== */
-- DROP PROC IF EXISTS dbo.Demo_GetSOD_ByProduct;
-- DROP PROC IF EXISTS dbo.Demo_GetSOD_ByProduct_Recompile;
-- DROP PROC IF EXISTS dbo.Demo_GetSOD_ByProduct_Unknown;

-- Ensure database parameterization back to SIMPLE (default)
ALTER DATABASE AdventureWorks SET PARAMETERIZATION SIMPLE;
GO

-- Ensure 'optimize for ad hoc workloads' back to OFF (instance default)
EXEC sp_configure 'show advanced options', 1;
RECONFIGURE WITH OVERRIDE;
EXEC sp_configure 'optimize for ad hoc workloads', 0;
RECONFIGURE WITH OVERRIDE;
GO
