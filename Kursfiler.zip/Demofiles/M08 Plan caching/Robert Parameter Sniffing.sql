/* ==========================================================
   �VNING: Parameter sniffing & Query Store (alternativ version)
   ========================================================== */

/* ----------------------------------------------------------
   Del 1: Parameter sniffing
   ---------------------------------------------------------- */

-- Steg 1: F�rberedelser (endast f�r labb � ALDRIG i produktion)
DBCC FREEPROCCACHE;     -- rensa plan-cache
DBCC DROPCLEANBUFFERS;  -- rensa buffercache
USE AdventureWorks;
GO

-- Skapa ett index p� ProductID utan INCLUDE f�r att f� Key Lookups
IF NOT EXISTS (
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID('Sales.SalesOrderDetail')
      AND name = 'IX_LabAlt_SOD_ProductID'
)
CREATE INDEX IX_LabAlt_SOD_ProductID
ON Sales.SalesOrderDetail(ProductID);
GO

/* ----------------------------------------------------------
   Steg 2: Hitta ett vanligt och ett ovanligt ProductID
   ---------------------------------------------------------- */
DECLARE @Common int, @Rare int;

SELECT TOP (1) @Common = ProductID
FROM Sales.SalesOrderDetail
GROUP BY ProductID
ORDER BY COUNT(*) DESC;  -- flest f�rekomster

SELECT TOP (1) @Rare = ProductID
FROM Sales.SalesOrderDetail
GROUP BY ProductID
ORDER BY COUNT(*) ASC;   -- minst f�rekomster

SELECT CommonProductID = @Common, RareProductID = @Rare;
GO

/* ----------------------------------------------------------
   Steg 3: Skapa en procedure som kan sniffas
   ---------------------------------------------------------- */
CREATE OR ALTER PROC dbo.LabAlt_GetDetails
    @ProductID int
AS
BEGIN
    SET NOCOUNT ON;
    SELECT SalesOrderDetailID, SalesOrderID, ProductID, OrderQty, UnitPrice
    FROM Sales.SalesOrderDetail
    WHERE ProductID = @ProductID;
END
GO

/* ----------------------------------------------------------
   Steg 4: Demonstrera parameter sniffing
   ---------------------------------------------------------- */
SET STATISTICS IO ON;
SET STATISTICS TIME ON;

-- F�rsta k�rningen med ovanligt v�rde (snabb plan med Nested Loops)
EXEC dbo.LabAlt_GetDetails @ProductID = 897;  -- byt mot ditt ovanliga id

-- Samma plan �teranv�nds nu �ven f�r vanligt v�rde (blir l�ngsammare)
EXEC dbo.LabAlt_GetDetails @ProductID = 870;  -- byt mot ditt vanliga id

SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
GO

/* ----------------------------------------------------------
   Steg 5: Tv� snabba l�sningar
   ---------------------------------------------------------- */

-- A: Tvinga ny kompilering vid varje k�rning
CREATE OR ALTER PROC dbo.LabAlt_GetDetails_Recompile
    @ProductID int
AS
BEGIN
    SET NOCOUNT ON;
    SELECT SalesOrderDetailID, SalesOrderID, ProductID, OrderQty, UnitPrice
    FROM Sales.SalesOrderDetail
    WHERE ProductID = @ProductID
    OPTION (RECOMPILE);
END
GO

-- Testa igen
EXEC dbo.LabAlt_GetDetails_Recompile @ProductID = 897;
EXEC dbo.LabAlt_GetDetails_Recompile @ProductID = 870;
GO

-- B: Ignorera sniffat v�rde och v�lj generisk plan
CREATE OR ALTER PROC dbo.LabAlt_GetDetails_Unknown
    @ProductID int
AS
BEGIN
    SET NOCOUNT ON;
    SELECT SalesOrderDetailID, SalesOrderID, ProductID, OrderQty, UnitPrice
    FROM Sales.SalesOrderDetail
    WHERE ProductID = @ProductID
    OPTION (OPTIMIZE FOR UNKNOWN);
END
GO

EXEC dbo.LabAlt_GetDetails_Recompile @ProductID = 897;
EXEC dbo.LabAlt_GetDetails_Recompile @ProductID = 870;
GO

/* ----------------------------------------------------------
   Steg 6: St�dning
   ---------------------------------------------------------- */
DROP PROC IF EXISTS dbo.LabAlt_GetDetails;
DROP PROC IF EXISTS dbo.LabAlt_GetDetails_Recompile;
DROP PROC IF EXISTS dbo.LabAlt_GetDetails_Unknown;
-- DROP INDEX IX_LabAlt_SOD_ProductID ON Sales.SalesOrderDetail;
GO

/* ==========================================================
   Del 2: Query Store
   ========================================================== */

-- Steg 1: Aktivera Query Store f�r AdventureWorks
ALTER DATABASE AdventureWorks SET QUERY_STORE = ON;
ALTER DATABASE AdventureWorks SET QUERY_STORE (OPERATION_MODE = READ_WRITE);
GO

-- Skapa index om det inte finns (samma som ovan, men f�r s�kerhets skull)
IF NOT EXISTS (
  SELECT 1 FROM sys.indexes 
  WHERE object_id = OBJECT_ID('Sales.SalesOrderDetail')
    AND name = 'IX_LabAlt_SOD_ProductID'
)
CREATE INDEX IX_LabAlt_SOD_ProductID
ON Sales.SalesOrderDetail(ProductID);
GO

-- Skapa test-procedur
CREATE OR ALTER PROC dbo.LabAlt_GetDetails_QS
    @ProductID int
AS
BEGIN
  SET NOCOUNT ON;
  SELECT SalesOrderDetailID, SalesOrderID, ProductID, OrderQty, UnitPrice
  FROM Sales.SalesOrderDetail
  WHERE ProductID = @ProductID;
END
GO

-- Steg 3: Generera tv� olika planer
DBCC FREEPROCCACHE;

EXEC dbo.LabAlt_GetDetails_QS @ProductID = 712;  -- ovanligt v�rde
EXEC sp_recompile 'dbo.LabAlt_GetDetails_QS';
EXEC dbo.LabAlt_GetDetails_QS @ProductID = 776;  -- vanligt v�rde
GO

-- Steg 4: Lista planer i Query Store
SELECT 
  qsq.query_id, qsp.plan_id,
  rs.avg_duration * 1.0 / 1000 AS avg_duration_ms,
  rs.avg_logical_io_reads,
  qsp.is_forced_plan
FROM sys.query_store_query_text AS qst
JOIN sys.query_store_query AS qsq ON qst.query_text_id = qsq.query_text_id
JOIN sys.query_store_plan  AS qsp ON qsq.query_id = qsp.query_id
JOIN sys.query_store_runtime_stats AS rs ON qsp.plan_id = rs.plan_id
WHERE qsq.object_id = OBJECT_ID('dbo.LabAlt_GetDetails_QS')
ORDER BY avg_duration_ms DESC;
GO

-- Steg 6: Avforcering (vid behov)
-- EXEC sp_query_store_unforce_plan @query_id = <query_id>, @plan_id = <plan_id>;
GO
