--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.


--Query Store
--General best practices:
-- https://www.sqlskills.com/blogs/erin/query-store-best-practices/

--Check best practices using Powershell:
-- https://jesspomfret.com/query-store-bp-dbatools/
-- Regarding powershell : dbatools.io

-- sp_quickiestore, find expensive queries in query store
-- https://www.erikdarlingdata.com/sp_quickiestore/introducing-sp_quickiestore-find-your-worst-queries-in-query-store-fast/

--Query Store toolbox at GitHub
-- https://github.com/channeladvisor/qdstoolbox

--------------------------------------------------------------------------------------------------------------------
--Query store is on by default for new databases:
-- Azure SQL Database
-- Azure SQL Managed Instance
-- SQL Server 2022
--------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------
--Note: QS will capture many plans if you have ad-hoc workload. Check result from below before you consider turning on query store:
SELECT 
 c.usecounts
,COUNT(*) AS #plans
,SUM(c.size_in_bytes / (1024 * 1024.0)) AS size_in_MB
FROM sys.dm_exec_cached_plans AS c
--WHERE usecounts = 1
GROUP BY c.usecounts
ORDER BY usecounts ASC

--Group by database
SELECT 
 c.usecounts
,DB_NAME(CAST(a.value AS sysname))
,COUNT(*) AS #plans
,SUM(c.size_in_bytes / (1024 * 1024.0)) AS size_in_MB
FROM sys.dm_exec_cached_plans AS c
 CROSS APPLY sys.dm_exec_plan_attributes(c.plan_handle) AS a
 WHERE a.attribute = 'dbid'
GROUP BY c.usecounts, DB_NAME(CAST(a.value AS sysname))
ORDER BY usecounts ASC, #plans DESC
--------------------------------------------------------------------------------------------------------------------


--------------------------------------------------------------------------------------------------------------------
--Restore AdventureworksDW
--------------------------------------------------------------------------------------------------------------------
USE master
GO
RESTORE DATABASE AdventureworksDW FROM DISK='C:\demodatabases\Course_demodatabases\AdventureworksDW2016_2019.bak'
WITH MOVE 'AdventureWorksDW_Data' TO 'C:\DemoDatabases\DbFiles\a\AdventureWorksDW_Data.mdf'
,MOVE 'AdventureWorksDW_Log'  TO 'C:\DemoDatabases\DbFiles\a\AdventureWorksDW_Log.ldf'
,REPLACE
--'
--GO


USE AdventureworksDW
GO
--------------------------------------------------------------------------------------------------------------------
--Procedure that we will use
--------------------------------------------------------------------------------------------------------------------
SELECT TOP(199) *  FROM FactProductInventory AS f

GO

CREATE OR ALTER PROC GetProductInventoryByUnitCost
  @UnitCost money
AS
SELECT f.ProductKey, f.MovementDate, f.UnitsBalance, f.UnitsIn, f.UnitsOut
FROM FactProductInventory AS f
WHERE f.UnitCost = @UnitCost

--The column UnitCost
--High selectivity: 787.74, 959.02, 796.97
--Low selectivity: 0.19, 0.20
GO

--------------------------------------------------------------------------------------------------------------------
--Verify index
--------------------------------------------------------------------------------------------------------------------
EXEC sp_indexinfo 'FactProductInventory'

DROP INDEX IF EXISTS UnitCost ON FactProductInventory
GO
CREATE NONCLUSTERED INDEX UnitCost ON FactProductInventory(UnitCost)

EXEC sp_indexinfo 'FactProductInventory'
--We now have an index on the UnitCost column


--------------------------------------------------------------------------------------------------------------------
--No node for Query Store in SSMS if it isn't turned on
--------------------------------------------------------------------------------------------------------------------



--------------------------------------------------------------------------------------------------------------------
--Turn on Query Store
--------------------------------------------------------------------------------------------------------------------

--Using T-SQL
/*
ALTER DATABASE AdventureworksDW SET QUERY_STORE  (
 OPERATION_MODE = READ_WRITE
,QUERY_CAPTURE_MODE = ALL
,INTERVAL_LENGTH_MINUTES = 1
,DATA_FLUSH_INTERVAL_SECONDS = 60
) --In reality we want more sane parameters
*/

SELECT * FROM sys.database_query_store_options

/* options:



OPERATION_MODE: OFF, READ_WRITE, READ_ONLY
It switches to READ_ONLY if it reaches max capacity. See the sys.database_query_store_options readonly_reason column.

DATA_FLUSH_INTERVAL_SECONDS = 900
900 is 15 minutes.
 NOTE: SQL server writes QS data to disk at shutdown. Can, for example, affect the planned failover time.
  TF 7745 Causes this to be skipped. Should be default IMO.

INTERVAL_LENGTH_MINUTES = 60
Aggregation period in minutes. Allowed values ??are 1, 5, 10, 14, 60, 1440.

MAX_PLANS_PER_QUERY = 200
 Introduced in 2017. 
 
WAIT_STATISTICS_CAPTURE_MODE = ON
 Introduced in 2017. 

CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 367)
 
MAX_STORAGE_SIZE_MB = 
 Default 100 before 2019, 1000 from 2019. Consider increasing to 5GB to 10 GB.
 If the size is reached, then switches to READ_ONLY (can also happen with the below enabled)

SIZE_BASED_CLEANUP_MODE: AUTO, OFF
AUTO (default) means it is cleaned based on CLEANUP_POLICY and MAX_STORAGE_SIZE_MB.

QUERY_CAPTURE_MODE: ALL (default innan 2019), AUTO (default from 2019), NONE, CUSTOM
 ALL: As the name suggests, can provide a lot of Qs and plans!
 NONE: Capture no new Qs, but record are kept for existing ones
 AUTO: Only catch Qs that "take up significant resources"
 CUSTOM: See below
 QUERY_CAPTURE_POLICY = (
     STALE_CAPTURE_POLICY_THRESHOLD = 7 DAYS, --A query must have met *any* of below within this time period
	 EXECUTION_COUNT = 30, 
	 TOTAL_COMPILE_CPU_TIME_MS = 1000, 
	 TOTAL_EXECUTION_CPU_TIME_MS = 100))
   )
*/


--Ex: incease to 5 GB
ALTER DATABASE [AdventureworksDW] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, MAX_STORAGE_SIZE_MB = 5000)


--Show GUI (Db, Properties, Query Store)

--------------------------------------------------------------------------------------------------------------------
--Verify selectivity, based on parameter sniffing
--------------------------------------------------------------------------------------------------------------------
SET STATISTICS IO ON
GO
DBCC FREEPROCCACHE
GO
EXEC GetProductInventoryByUnitCost @UnitCost = 787.74 --High selectivity, index seek,     6 I/O
EXEC GetProductInventoryByUnitCost @UnitCost = 959.02 --High selectivity, index seek,     6 I/O
EXEC GetProductInventoryByUnitCost @UnitCost = 0.19   --Low selectivity, index seek, 83476 I/O
EXEC GetProductInventoryByUnitCost @UnitCost = 0.20   --Low selectivity, index seek, 78108 I/O
GO 10
DBCC FREEPROCCACHE
GO
EXEC GetProductInventoryByUnitCost @UnitCost = 0.19   --Low selectivity, table scan   3858 I/O
EXEC GetProductInventoryByUnitCost @UnitCost = 0.20   --Low selectivity, table scan   3858 I/O
EXEC GetProductInventoryByUnitCost @UnitCost = 787.74 --High selectivity, table scan   3858 I/O
EXEC GetProductInventoryByUnitCost @UnitCost = 959.02 --High selectivity, table scan   3858 I/O
GO 10

--------------------------------------------------------------------------------------------------------------------
--Run the SQL queries again
--------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------
--Show size for the QS tables (Properties, Query Store)
--------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------
--Show GUI
--------------------------------------------------------------------------------------------------------------------
/*

Overall Resource Consumption
Use as a baseline. What does resource consumption look like over time, based on what we have in QS.
*/

--Open Top Resource Consuming Queries
--Change to "Logical reads"

--Refresh

--Note the Query ID (x-axis on the left chart)
--Open Tracked Queries, fill in this ID

--Open Overall Resource Consumption

--Open Top Resource Consuming Queries
--Force the plan that does the table scan
--Run again and verify we always get 3858 I/O

--Force plan uses "Plan Guides"

--------------------------------------------------------------------------------------------------------------------
--Catalog views
--------------------------------------------------------------------------------------------------------------------

--How is QS set up?
SELECT * FROM sys.database_query_store_options

--Plan affecting options
SELECT * FROM sys.query_context_settings

--Execution plans
SELECT * FROM sys.query_store_plan

--Queries with aggregate statistics
SELECT * FROM sys.query_store_query

--Text for queries
SELECT * FROM sys.query_store_query_text

--Wait stats
SELECT * FROM sys.query_store_wait_stats

--Run-time data
SELECT * FROM sys.query_store_runtime_stats

--Start and end for intervals
SELECT * FROM sys.query_store_runtime_stats_interval



--------------------------------------------------------------------------------------------------------------------
--Examples of SQL queries to analyze data in the Query Store
--------------------------------------------------------------------------------------------------------------------

--10 most recently run queries (according to QS)
SELECT TOP(10) qt.query_sql_text, q.query_id, qt.query_text_id, p.plan_id, rs.last_execution_time, CAST(p.query_plan  AS xml) AS the_plan
FROM sys.query_store_query_text	AS qt
 INNER JOIN sys.query_store_query AS q ON qt.query_text_id = q.query_text_id
 INNER JOIN sys.query_store_plan	AS p ON q.query_id = p.query_id 
 INNER JOIN sys.query_store_runtime_stats AS rs ON p.plan_id = rs.plan_id
ORDER BY last_execution_time DESC

SELECT * FROM sys.query_store_runtime_stats

--Number of executions for each query
SELECT q.query_id, qt.query_text_id, qt.query_sql_text, SUM(rs.count_executions) AS total_execution_count
FROM sys.query_store_query_text	AS qt
 INNER JOIN sys.query_store_query AS q ON qt.query_text_id = q.query_text_id
 INNER JOIN sys.query_store_plan	AS p ON q.query_id = p.query_id 
 INNER JOIN sys.query_store_runtime_stats AS rs ON p.plan_id = rs.plan_id
GROUP BY q.query_id, qt.query_text_id, qt.query_sql_text
ORDER BY total_execution_count DESC

--10 questions with the longest average execution time in the last hour
SELECT TOP(10) 
 qt.query_sql_text
,q.query_id
,qt.query_text_id
,p.plan_id
,CAST(GETUTCDATE() AS time(1)) AS current_utc_time
,CAST(rs.last_execution_time AS time(1)) AS last_execution_utc_time
,rs.avg_duration
FROM sys.query_store_query_text	AS qt
 INNER JOIN sys.query_store_query AS q ON qt.query_text_id = q.query_text_id
 INNER JOIN sys.query_store_plan AS p ON q.query_id = p.query_id 
 INNER JOIN sys.query_store_runtime_stats AS rs ON p.plan_id = rs.plan_id
WHERE rs.last_execution_time > DATEADD(HOUR, -1, GETUTCDATE())
ORDER BY rs.avg_duration DESC

--20 queries with highest average logical I/O last 24 hours, including number of rows and executions
SELECT TOP(20) qt.query_sql_text, q.query_id, qt.query_text_id, p.plan_id,rs.runtime_stats_id, CAST(rsi.start_time AS time(1)) AS start_time, CAST(rsi.end_time AS time(1)) AS end_time, rs.avg_logical_io_reads,rs.avg_rowcount, rs.count_executions
FROM sys.query_store_query_text AS qt
 INNER JOIN sys.query_store_query AS q ON qt.query_text_id = q.query_text_id
 INNER JOIN sys.query_store_plan AS p ON q.query_id = p.query_id 
 INNER JOIN sys.query_store_runtime_stats AS rs ON p.plan_id = rs.plan_id
 INNER JOIN sys.query_store_runtime_stats_interval AS rsi ON rsi.runtime_stats_interval_id = rs.runtime_stats_interval_id
WHERE rsi.start_time >= DATEADD(HOUR, -24, GETUTCDATE())
ORDER BY rs.avg_logical_io_reads DESC

--Questions with more than 1 plan
WITH Query_MultPlans
AS
(
SELECT COUNT(*) AS cnt, q.query_id
FROM sys.query_store_query_text qt
 INNER JOIN sys.query_store_query q ON qt.query_text_id = q.query_text_id
 INNER JOIN sys.query_store_plan p ON p.query_id = q.query_id
GROUP BY q.query_id
HAVING COUNT(DISTINCT plan_id) > 1
)
SELECT q.query_id, OBJECT_NAME(object_id) AS ContainingObject,
query_sql_text, plan_id, CAST(p.query_plan AS xml) AS plan_xml,
CAST(p.last_compile_start_time AS time(1)) AS last_compile_start_time, CAST(p.last_execution_time AS time(1)) AS last_execution_time
FROM Query_MultPlans qm 
INNER JOIN sys.query_store_query q ON qm.query_id = q.query_id
INNER JOIN sys.query_store_plan p ON q.query_id = p.query_id
INNER JOIN sys.query_store_query_text qt ON qt.query_text_id = q.query_text_id
ORDER BY query_id, plan_id

--Forced plans
SELECT * FROM sys.query_store_plan WHERE is_forced_plan = 1


--Now possibly see "Automatic tuning 2017.sql", which requires Query Store to be turned on
