--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.

USE myOLTP

--Index typer?
SELECT DISTINCT type_desc
FROM sys.indexes AS i

SELECT object_name(OBJECT_ID), * FROM sys.indexes WHERE type_desc = 'NONCLUSTERED HASH'

SELECT * FROM sys.dm_db_xtp_hash_index_stats
-- ca 1000000 buckets, 600000 tomma, avg chain och 8 max chain

--Vi kan �ndra bucket-count i 2016
ALTER TABLE dbo.MemoryTable
  ALTER INDEX PK_myTable REBUILD WITH(BUCKET_COUNT = 200)

SELECT * FROM sys.dm_db_xtp_hash_index_stats
-- ca 100000 buckets, 65  tomma, 7 avg chain och 23 max chain
--Duration f�r scan gick ner fr�n 330ms till 290 ms

--�terst�ll till bra v�rde
ALTER TABLE dbo.MemoryTable
  ALTER INDEX PK_myTable REBUILD WITH(BUCKET_COUNT = 1000000)
