--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.

--F�ruts�tter att "fil" och filgrupp finns, enligt vad Memory Optimization Advisor har genererat
USE myOLTP 
SET NOCOUNT ON

--Undvik autogrow
ALTER DATABASE myOLTP  MODIFY FILE (NAME = myOLTP, size = 500MB)
ALTER DATABASE myOLTP  MODIFY FILE (NAME = myOLTP_log, size = 2GB)
GO

--Ta bort tabeller, om dom finns
IF OBJECT_ID('SelectSingleRowsMemory') IS NOT NULL DROP PROC SelectSingleRowsMemory
IF OBJECT_ID('SelectSingleRowsDisk') IS NOT NULL DROP PROC SelectSingleRowsDisk
IF OBJECT_ID('InsertDataMulti') IS NOT NULL DROP PROC InsertDataMulti
IF OBJECT_ID('timing') IS NOT NULL DROP TABLE timing
IF OBJECT_ID('num_rows') IS NOT NULL DROP TABLE num_rows
IF OBJECT_ID('DiskTable') IS NOT NULL DROP TABLE DiskTable
IF OBJECT_ID('MemoryTable') IS NOT NULL DROP TABLE MemoryTable
GO

--Tabell f�r timing
CREATE TABLE timing(id int IDENTITY(1, 1) PRIMARY KEY, the_event varchar(150), rows_ int, duration_seconds decimal(9,1))

--Tabell f�r antal rader
CREATE TABLE num_rows(type_ varchar(20), num_rows int)

--Skapa "traditionell" disk-baserad tabell
CREATE TABLE DiskTable
(id int NOT NULL PRIMARY KEY NONCLUSTERED
,some_number int NOT NULL
,date_value datetime NULL
,c4 char(5) NULL
,c5 varchar(30) NULL
,c6 bigint NOT NULL
,INDEX IX_some_number NONCLUSTERED (some_number)
)

--Skapa motsvarande minnesoptimerad tabell
--Studera syntax!!!
CREATE TABLE MemoryTable
(
 id int NOT NULL CONSTRAINT PK_myTable PRIMARY KEY NONCLUSTERED HASH WITH (BUCKET_COUNT = 1000000)	--Hash index
,some_number int NOT NULL
,date_value datetime NULL
,c4 char(5) NULL
,c5 varchar(30) NULL
,c6 bigint NOT NULL
,INDEX IX_some_number NONCLUSTERED (some_number)								--BW-Tree index
)
WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_AND_DATA)						--Options

/*
--Approp� hash index, exempel
(a, b)
a = 23 AND b = 45 --Ja, index kan anv�ndas
a = 23	--Nej
b = 45	--Nej
a > 45	--Nej
*/

--Notera C-koden (som inte finns h�r)
--C:\DemoDatabases\DbFiles\a\xtp

--------------------------------------------------------------------------------------------------------------
--L�gg nu till data
--K�r allt nedanst�ende, g� igenom koden under tiden som det k�rs
--tar drygt 1 minut med 1'', 100'
--------------------------------------------------------------------------------------------------------------

--T�m tabeller, om det finns data
DELETE FROM MemoryTable
TRUNCATE TABLE DiskTable
TRUNCATE TABLE timing
TRUNCATE TABLE num_rows

INSERT INTO num_rows(type_, num_rows)
VALUES
 ('ONE_TRAN', 1000000)


--Insert till disk-tabell, en transaktion
DECLARE @theId int, @dt_init datetime2, @start_val int, @max_val int
DECLARE @num_rows int = (SELECT num_rows FROM num_rows WHERE type_ = 'ONE_TRAN')
SET @theID = (SELECT CASE WHEN MAX(id) IS NULL THEN 0 ELSE MAX(id) END + 1 FROM DiskTable)
SET @start_val = @theId
SET @max_val = @start_val + @num_rows - 1

SET @dt_init = SYSDATETIME()
BEGIN TRAN
	WHILE @theId <= @max_val
	BEGIN
		INSERT INTO DiskTable VALUES (@theId, @theId, GETDATE(), 'hej', 'Hej p� er', 8922787)
		SET @theId += 1
	END
COMMIT
INSERT INTO timing(the_event, rows_, duration_seconds) VALUES('Disk based, one transaction', @max_val - @start_val + 1, DATEDIFF(MILLISECOND, @dt_init, SYSDATETIME()) / 1000.)
GO


--Insert till minnesoptimerad tabell, en transaktion
DECLARE @theId int, @dt_init datetime2, @start_val int, @max_val int
DECLARE @num_rows int = (SELECT num_rows FROM num_rows WHERE type_ = 'ONE_TRAN')
SET @theID = (SELECT CASE WHEN MAX(id) IS NULL THEN 0 ELSE MAX(id) END + 1 FROM MemoryTable)
SET @start_val = @theId
SET @max_val = @start_val + @num_rows - 1

SET @dt_init = SYSDATETIME()
BEGIN TRAN
	WHILE @theId <= @max_val
	BEGIN
		INSERT INTO MemoryTable VALUES (@theId, @theId, GETDATE(), 'hej', 'Hej p� er', 8922787)
		SET @theId += 1
	END
COMMIT
INSERT INTO timing(the_event, rows_, duration_seconds) VALUES('Memory optimized, one transaction', @max_val - @start_val + 1, DATEDIFF(MILLISECOND, @dt_init, SYSDATETIME())/1000.)
GO

SELECT * FROM timing ORDER BY rows_ DESC, id


/*
-- Antal rader
SELECT COUNT(*) FROM dbo.DiskTable
SELECT COUNT(*) FROM dbo.MemoryTable
*/