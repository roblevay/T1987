/*
============================================================
 SQL Server Memory Configuration Demos
 Robert Levay – SQL Server 2019, AdventureWorks/AdventureWorksDW
------------------------------------------------------------
 OBS: Dessa demos är avsedda för labb/test – inte produktion!
 Vissa steg rensar cache eller sänker max server memory temporärt.
============================================================
*/

/******************************************************
 0. BASLINE – NUVARANDE KONFIGURATION OCH MINNE
******************************************************/

-- Nuvarande min/max
SELECT name, value_in_use AS [MB]
FROM sys.configurations
WHERE name IN ('min server memory (MB)', 'max server memory (MB)')
ORDER BY name;

-- Processminne
SELECT 
  physical_memory_kb/1024 AS sqlserver_process_memory_MB,
  locked_page_allocations_kb/1024 AS locked_pages_MB,
  process_physical_memory_low, process_virtual_memory_low
FROM sys.dm_os_process_memory;

-- Memory clerks
SELECT TOP (20)
  clerks.type, 
  SUM(clerks.pages_kb)/1024.0 AS MB
FROM sys.dm_os_memory_clerks AS clerks
GROUP BY clerks.type
ORDER BY MB DESC;

-- Buffercache per databas
SELECT 
  DB_NAME(database_id) AS database_name,
  COUNT(*) * 8 / 1024.0 AS buffer_pool_MB
FROM sys.dm_os_buffer_descriptors
GROUP BY database_id
ORDER BY buffer_pool_MB DESC;


/******************************************************
 1. VISA OCH ÄNDRA MIN/MAX SERVER MEMORY
******************************************************/

-- Läs
SELECT name, value_in_use AS [MB]
FROM sys.configurations
WHERE name IN ('min server memory (MB)', 'max server memory (MB)');

-- Sätt (exempel)
EXEC sys.sp_configure 'show advanced options', 1;
RECONFIGURE WITH OVERRIDE;

EXEC sys.sp_configure 'min server memory (MB)', 512;
EXEC sys.sp_configure 'max server memory (MB)', 4096;
RECONFIGURE WITH OVERRIDE;

-- Skriver ut återställningskommandon (för att snabbt kunna backa)
DECLARE @min INT = (SELECT value_in_use FROM sys.configurations WHERE name='min server memory (MB)');
DECLARE @max INT = (SELECT value_in_use FROM sys.configurations WHERE name='max server memory (MB)');
PRINT '-- Återställ dessa värden:';
PRINT 'EXEC sp_configure ''min server memory (MB)'',' + CAST(@min AS varchar(10)) + ';';
PRINT 'EXEC sp_configure ''max server memory (MB)'',' + CAST(@max AS varchar(10)) + ';';
PRINT 'RECONFIGURE WITH OVERRIDE;';


/******************************************************
 2. DEMO: RESOURCE_SEMAPHORE (Memory Grants)
******************************************************/

-- Tillfälligt sänk max memory (t.ex. 1024 MB)
EXEC sys.sp_configure 'show advanced options', 1; RECONFIGURE WITH OVERRIDE;
EXEC sys.sp_configure 'max server memory (MB)', 1024;
RECONFIGURE WITH OVERRIDE;

-- Rensa cache (endast labb)
CHECKPOINT;
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;

-- Öppna flera fönster och kör denna fråga samtidigt
USE AdventureWorks2019;
GO
SELECT TOP (2000000)
       p.ProductID, sod.SalesOrderID, sod.LineTotal
FROM Sales.SalesOrderDetail AS sod
JOIN Production.Product AS p ON p.ProductID = sod.ProductID
CROSS JOIN (SELECT 1 AS n FROM sys.all_objects) AS x
ORDER BY LineTotal DESC
OPTION (MAXDOP 1, RECOMPILE);

-- Kolla waits
SELECT wait_type, waiting_tasks_count, wait_time_ms/1000.0 AS wait_s
FROM sys.dm_os_wait_stats
WHERE wait_type LIKE 'RESOURCE_SEMAPHORE%';

-- Aktuella frågor med grants
SELECT r.session_id, r.status, r.wait_type, rq.requested_memory_kb, rq.granted_memory_kb
FROM sys.dm_exec_requests AS r
JOIN sys.dm_exec_query_memory_grants AS rq ON r.session_id = rq.session_id;

-- Återställ (byt 4096 mot ditt normala värde)
EXEC sys.sp_configure 'max server memory (MB)', 4096;
RECONFIGURE WITH OVERRIDE;


/******************************************************
 3. DEMO: PAGEIOLATCH (Disk I/O vid kall cache)
******************************************************/

-- Baseline
IF OBJECT_ID('tempdb..#before_waits') IS NOT NULL DROP TABLE #before_waits;
SELECT wait_type, waiting_tasks_count, wait_time_ms
INTO #before_waits
FROM sys.dm_os_wait_stats
WHERE wait_type LIKE 'PAGEIOLATCH%';

CHECKPOINT;
DBCC DROPCLEANBUFFERS;

-- Skanna stor tabell i DW
USE AdventureWorksDW2019;
GO
SELECT SUM(SalesAmount) AS total_sales
FROM dbo.FactInternetSales
OPTION (MAXDOP 1, RECOMPILE);

-- Jämför före/efter
WITH after_waits AS (
  SELECT wait_type, waiting_tasks_count, wait_time_ms
  FROM sys.dm_os_wait_stats
  WHERE wait_type LIKE 'PAGEIOLATCH%'
)
SELECT a.wait_type,
       (a.waiting_tasks_count - b.waiting_tasks_count) AS delta_tasks,
       (a.wait_time_ms - b.wait_time_ms)/1000.0         AS delta_wait_s
FROM after_waits AS a
JOIN #before_waits AS b ON a.wait_type = b.wait_type
ORDER BY delta_wait_s DESC;


/******************************************************
 4. DEMO: RESOURCE_SEMAPHORE_QUERY_COMPILE (Kompilering)
******************************************************/

-- Sänk max memory igen (t.ex. 1024)
EXEC sys.sp_configure 'max server memory (MB)', 1024;
RECONFIGURE WITH OVERRIDE;

-- Kör loop med varierande queries i flera sessioner
USE AdventureWorks2019;
GO
DECLARE @i int = 1;
WHILE @i <= 200
BEGIN
    DECLARE @sql nvarchar(max) =
      N'SELECT COUNT(*) 
        FROM Sales.SalesOrderDetail 
        WHERE LineTotal > ' + CAST(@i * 10 AS nvarchar(10)) + N'
        OPTION (RECOMPILE, MAXDOP 1);';
    EXEC (@sql);
    SET @i += 1;
END

-- Kolla waits
SELECT wait_type, waiting_tasks_count, wait_time_ms/1000.0 AS wait_s
FROM sys.dm_os_wait_stats
WHERE wait_type LIKE 'RESOURCE_SEMAPHORE_QUERY_COMPILE';

-- Återställ
EXEC sys.sp_configure 'max server memory (MB)', 4096;
RECONFIGURE WITH OVERRIDE;


/******************************************************
 5. BERÄKNA "LAGOM" MAX SERVER MEMORY
******************************************************/

DECLARE @totalMB bigint;
SELECT @totalMB = total_physical_memory_kb/1024
FROM sys.dm_os_sys_memory;

SELECT 
  total_ram_MB              = @totalMB,
  rule1_leave_MB            = CASE WHEN @totalMB <= 16384 
                                   THEN @totalMB / 4
                                   ELSE (16384/4) + ((@totalMB-16384)/8) 
                              END,
  rule2_leave_MB            = CASE WHEN @totalMB*0.10 > 4096 THEN CAST(@totalMB*0.10 AS int) ELSE 4096 END,
  suggested_max_server_MB_r1= @totalMB - (
                                   CASE WHEN @totalMB <= 16384 
                                        THEN @totalMB / 4 
                                        ELSE (16384/4) + ((@totalMB-16384)/8) 
                                   END),
  suggested_max_server_MB_r2= @totalMB - CASE WHEN @totalMB*0.10 > 4096 THEN CAST(@totalMB*0.10 AS int) ELSE 4096 END;


/******************************************************
 6. LIVE-ÖVERVAKNING
******************************************************/

-- Väntetopp
SELECT TOP (10) wait_type, waiting_tasks_count, wait_time_ms/1000.0 AS wait_s
FROM sys.dm_os_wait_stats
WHERE waiting_tasks_count > 0
ORDER BY wait_time_ms DESC;

-- Aktiva queries + deras memory grants
SELECT TOP (20)
  r.session_id, r.status, r.cpu_time, r.total_elapsed_time,
  mg.requested_memory_kb, mg.granted_memory_kb, mg.max_used_memory_kb,
  DB_NAME(r.database_id) AS dbname,
  SUBSTRING(t.text, 
    (r.statement_start_offset/2)+1,
    CASE WHEN r.statement_end_offset = -1 
         THEN LEN(t.text) 
         ELSE (r.statement_end_offset - r.statement_start_offset)/2 + 1 END) AS stmt
FROM sys.dm_exec_requests AS r
LEFT JOIN sys.dm_exec_query_memory_grants AS mg
  ON r.session_id = mg.session_id
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) AS t
ORDER BY mg.requested_memory_kb DESC, r.total_elapsed_time DESC;

-- SLUT
