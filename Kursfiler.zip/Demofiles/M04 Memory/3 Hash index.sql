--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.

USE myOLTP

SET STATISTICS IO ON--> Funkar bara p� diskoptimerad

--Exekveringplan n�r hash-index anv�nds (ingen speciell ikon f�r hash-index)
SELECT * FROM MemoryTable AS m WHERE m.id = 34
GO

--In?
SELECT * FROM MemoryTable AS m WHERE m.id IN(34, 36)


--J�mf�r mot disk tabell med NC index
SELECT * FROM DiskTable AS m WHERE m.id = 34
GO

--Hash-index anv�nds BARA f�r =
SELECT * FROM MemoryTable AS m WHERE m.id BETWEEN 34 AND 40
GO


--J�mf�r mot disk tabell med NC index
SELECT * FROM DiskTable AS m WHERE m.id BETWEEN 34 AND 40
GO

--BW-Tree index, allts� inte Hash index?
SELECT * FROM MemoryTable AS m WHERE m.some_number BETWEEN 34 AND 40
GO

--J�mf�r mot disk tabell med NC index
SELECT * FROM DiskTable AS m WHERE m.some_number BETWEEN 34 AND 40
GO


--Ingen rapportering vad g�ller I/O fr�n STATISTICS IO eller SQL Trace

--Kolla SQL Trace skillnad i CPU och duration (sl� av exec plan)
SET STATISTICS IO OFF