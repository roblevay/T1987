--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.

USE myOLTP

------------------------------------------------------------------------------------------------------------------
--DMV f�r XTP
------------------------------------------------------------------------------------------------------------------
SELECT OBJECT_NAME(m.object_id), m.*
FROM sys.dm_db_xtp_table_memory_stats m
 INNER JOIN sys.sysobjects o ON m.object_id = o.id
 
--Bucket information mm.
SELECT OBJECT_NAME(object_id) AS name, *
FROM sys.dm_db_xtp_hash_index_stats



--Index stats 
SELECT OBJECT_NAME(object_id) AS name, *
FROM sys.dm_db_xtp_index_stats
 INNER JOIN sys.sysobjects o ON object_id = o.id

--Checkpoint statistics of the current database
SELECT * FROM sys.dm_db_xtp_checkpoint_stats
CHECKPOINT
SELECT * FROM sys.dm_db_xtp_checkpoint_stats

--Information about checkpoint files, like the type of 
--file (DATA or DELTA files), its size, and relative path.
SELECT * FROM sys.dm_db_xtp_checkpoint_files

--Garbage collection cycles for the current database
SELECT * FROM sys.dm_db_xtp_gc_cycle_stats

--Stats for memory consumers of the current database.
--The view returns a row for each memory consumer that the database engine uses.
SELECT * FROM sys.dm_db_xtp_memory_consumers

--Data and delta files� merge operations
SELECT * FROM sys.dm_db_xtp_merge_requests

--Shows allocated and used memory of user and system tables.
SELECT * FROM sys.dm_db_xtp_table_memory_stats


--Displays information about current transactions in the In-Memory OLTP 
--database engine.
SELECT * FROM sys.dm_db_xtp_transactions

--Information about the garbage-collection (GC) process on memory-optimized tables
SELECT * FROM sys.dm_xtp_gc_stats

--Outputs information about each GC worker queue on the server, and various statistics about each
SELECT * FROM sys.dm_xtp_gc_queue_stats

--Information on system level memory consumers for In-Memory OLTP
SELECT * FROM sys.dm_xtp_system_memory_consumers

--Reports statistics about transactions that have run since the server started
SELECT * FROM sys.dm_xtp_transaction_stats

