--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Lite om memory clerks

--Vilka typer?
SELECT DISTINCT type FROM sys.dm_os_memory_clerks 



SELECT c.type, c.name, pages_kb/1024. AS pages_MB, awe_allocated_kb/1024. AS awe_allocated_MB
FROM sys.dm_os_memory_clerks AS c
ORDER BY pages_MB DESC

--Kan vi rampa upp BP lite?
SELECT COUNT(RevisionNumber) FROM AdventureworksDW.dbo.FactResellerSalesXL_PageCompressed
--SELECT TOP(10) * FROM AdventureworksDW.dbo.FactResellerSalesXL_CCI

--MEMORYCLERK_SOSNODE sp�rar och hanterar minnesanv�ndning f�r en nod i SQLOS, vilket innefattar schemal�ggare 
--och resursallokering relaterat till CPU och I/O. Det �r en av m�nga minnesklienter 
--i SQL Server som hj�lper till att h�lla koll p� hur systemets resurser anv�nds och 
--allokeras p� en detaljerad niv�.

--Kan ocks� anv�nda:
SELECT x.physical_memory_kb / 1024 AS physical_memory_Mb, x.committed_kb / 1024 AS committed_Mb
FROM sys.dm_os_sys_info AS x

--Se tex https://www.sqlservergeeks.com/sys-dm_os_process_memory/

--Se upp f�r nedan output i errorlog-filen
DBCC MEMORYSTATUS


--PLE. Page life expectancy
SELECT * 
FROM sys.dm_os_performance_counters
WHERE counter_name LIKE '%expe%'--Page Life Expectancy i sekunder



--Kommentar fr�n Erland Sommarskog p� forum (https://social.msdn.microsoft.com/Forums/sqlserver/en-US/3d356836-bb90-48ec-b8fd-b7a5dcc8bfe9/sql-server-2016-large-memory-instance-has-procedure-cache-clearing-regularly?forum=sqldatabaseengine):
 --"My favourite is to run a SELECT on sys.dm_os_memory_cache_clock_hands 
 --and see if rounds_count is increasing, 
 --and particularly if it is the internal or external hands that are moving.
 --That is, is the perceived memory pressure internal or external."
SELECT * FROM sys.dm_os_memory_cache_clock_hands  
