--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.

----------------------------------------------------------------------------------------------------------------------------
--Skapa ny databas f�r demo
----------------------------------------------------------------------------------------------------------------------------
USE master
GO
DROP DATABASE IF EXISTS myOLTP
GO
CREATE DATABASE myOLTP
 ON  PRIMARY 
( NAME = N'myOLTP', FILENAME = N'C:\DemoDatabases\DbFiles\a\myOLTP.mdf' , SIZE = 50MB , FILEGROWTH = 64MB )
 LOG ON 
( NAME = N'myOLTP_log', FILENAME = N'C:\DemoDatabases\DbFiles\a\myOLTP_log.ldf' , SIZE = 30MB , FILEGROWTH = 64MB )


--Det finns wizard, h�gerklicka p� tabell, Memory optimization Advisor



----------------------------------------------------------------------------------------------------------------------
--Se till att ha InMemory filgrupp och "fil"
----------------------------------------------------------------------------------------------------------------------
USE master
GO

ALTER DATABASE myOLTP
 ADD FILEGROUP myOLTP_InMemory_FG 
 CONTAINS MEMORY_OPTIMIZED_DATA 
GO

ALTER DATABASE myOLTP 
 ADD FILE ( NAME = N'myOLTP_InMemory'
          , FILENAME = N'C:\DemoDatabases\DbFiles\a\myOLTP_InMemory' )
  TO FILEGROUP myOLTP_InMemory_FG
GO

