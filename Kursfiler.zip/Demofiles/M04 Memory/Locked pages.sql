--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

EXEC sp_configure 'max serv'
EXEC sp_configure 'min serv'



--�r locked pages p�slaget?

--Vi kan se i errorloggen, vid uppstart (andra param �r SQL eller Agent)
EXEC sp_readerrorlog 0, 1, 'lock'

--Eller via DMV (0 om ej p�slaget)
SELECT * FROM sys.dm_os_process_memory

--Sl� p� genom att tilldela "Lock pages in memory" security policy


--Eller �r kanske tom large page allocations p�slaget?
EXEC sp_readerrorlog 0, 1, 'Large'

--Det ser ut som det, men f�r att det ska anv�ndas i n�n 
--omfattning att tala om s� beh�vs ocks� traceflagga 834
--S�tt d� max server memory
--Se https://blogs.msdn.microsoft.com/psssql/2009/06/05/sql-server-and-large-pages-explained/

--Approp� tracelaggor: Vilka �r "aktiva"?
DBCC TRACESTATUS

-- 3226 Skriv inte till errolog vid lyckad backup
DBCC TRACEON(3226)		--Sl� p� en traceflagga f�r denna session
DBCC TRACEOFF(3226)		--Sl� av en traceflagga f�r denna session
DBCC TRACEON(3226, -1)	--Sl� p� en traceflagga globalt (tills n�sta omstart)
DBCC TRACEOFF(3226, -1)	--Sl� av en traceflagga globalt (tills n�sta omstart)

/*
Enable the Lock pages in memory option
On the Start menu, select Run. In the Open box, type gpedit.msc. The Group Policy dialog box opens.
On the Local Group Group Policy console, expand Computer Configuration.
Expand Windows Settings.
Expand Security Settings.
Expand Local Policies.
Select the User Rights Assignment folder. The policies will be displayed in the details pane.
In the pane, scroll to and double-click the Lock pages in memory policy.
In the Local Security Policy Setting dialog box, select Add User or Group.... Add the SQL Server Service account. To determine the service account for the instance of SQL Server, refer to the SQL Server Configuration Manager or query the service_account from sys.dm_server_services. For more information, see sys.dm_server_services.
Select OK.
Restart the instance for this setting to take effect.
*/