--Copyright Tibor Karaszi Konsulting. Not to be used by other than Tibor Karaszi for educational purposes.

USE myOLTP


------------------------------------------------------------------------------------------------------------------
--Visa Native Compilation Advisor
------------------------------------------------------------------------------------------------------------------
--H�gerklicka p� procedur


------------------------------------------------------------------------------------------------------------------
--Natively compiled procedure, alla rader en transaktion
------------------------------------------------------------------------------------------------------------------

IF OBJECT_ID('InsertDataMulti') IS NOT NULL DROP PROC InsertDataMulti
GO

CREATE PROCEDURE InsertDataMulti
 @start_val int, @max_val int
WITH NATIVE_COMPILATION, SCHEMABINDING
AS
BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = 'us_english')
	DECLARE @theId int = @start_val
	WHILE @theId <= @max_val
	BEGIN
		INSERT INTO dbo.MemoryTable VALUES (@theId, @theId, GETDATE(), 'hej', 'Hej p� er', 8922787)
		SET @theId += 1
	END
END;
GO

--Notera C-koden
--C:\DemoDatabases\DbFiles\p\xtp\5

--L�gg till rader, alla i samma transaktion
DECLARE @theId int, @dt_init datetime2, @start_val int, @max_val int
DECLARE @num_rows int = (SELECT num_rows FROM num_rows WHERE type_ = 'ONE_TRAN')
SET @theID = (SELECT CASE WHEN MAX(id) IS NULL THEN 0 ELSE MAX(id) END + 1 FROM MemoryTable)
SET @start_val = @theId
SET @max_val = @start_val + @num_rows - 1

SET @dt_init = SYSDATETIME()
EXEC InsertDataMulti @start_val = @start_val, @max_val = @max_val;
INSERT INTO timing(the_event, rows_, duration_seconds) VALUES('Memory optimized, XTP proc, one transaction', @max_val - @start_val + 1, DATEDIFF(MILLISECOND, @dt_init, SYSDATETIME()) / 1000.0)



------------------------------------------------------------------------------------------------------------------
--Timing?
------------------------------------------------------------------------------------------------------------------
SELECT * FROM timing ORDER BY rows_ DESC, id
GO

------------------------------------------------------------------------------------------------------------------
--Select av enskild rad
------------------------------------------------------------------------------------------------------------------

--Disk baserad
CREATE OR ALTER PROC SelectSingleRowsDisk
 @num_iterations int
AS
DECLARE 
 @theDate datetime, @i int 
SET @i = 1

WHILE @i <= @num_iterations
BEGIN
	SET @theDate = (SELECT date_value FROM DiskTable WHERE id = @i)
	SET @i += 1
END
GO

--Minnesoptimerad (Natively Compiled)
CREATE PROCEDURE SelectSingleRowsMemory
 @num_iterations int
WITH NATIVE_COMPILATION, SCHEMABINDING
AS
BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = 'us_english')
	BEGIN
		DECLARE 
		 @theDate datetime
		,@i int 
		SET @i = 1

		WHILE @i <= @num_iterations
		BEGIN
			SELECT @theDate = date_value FROM dbo.MemoryTable WHERE id = @i
			SET @i += 1
		END
	END
END;
GO


--V�rm upp b�da
EXEC SelectSingleRowsDisk @num_iterations = 1
EXEC SelectSingleRowsMemory @num_iterations = 1

--K�r
DECLARE @dt_init datetime2 = SYSDATETIME(), @iterations int = 2000000
EXEC SelectSingleRowsDisk @num_iterations = @iterations
INSERT INTO timing(the_event, rows_, duration_seconds) VALUES('Disk based, many single row SELECTs', @iterations, DATEDIFF(MILLISECOND, @dt_init, SYSDATETIME()) / 1000.0)
SET @dt_init = SYSDATETIME()
EXEC SelectSingleRowsMemory @num_iterations = @iterations
INSERT INTO timing(the_event, rows_, duration_seconds) VALUES('Memory Optimized, many single row SELECTs', @iterations, DATEDIFF(MILLISECOND, @dt_init, SYSDATETIME()) / 1000.0)
GO

------------------------------------------------------------------------------------------------------------------
--Timing?
------------------------------------------------------------------------------------------------------------------
SELECT * FROM timing ORDER BY rows_ DESC, id


------------------------------------------------------------------------------------------------------------------
--Ta bort rader
------------------------------------------------------------------------------------------------------------------

SELECT COUNT(*) FROM DiskTable
SELECT COUNT(*) FROM MemoryTable


--Ta bort alla rader i disktabell. Anteckna tiden
DELETE FROM DiskTable
--11 sekunder, 1 000 000 rader

--Ta bort alla rader i minnestabell. Anteckna tiden
DELETE FROM MemoryTable;
--2 sekunder, 2 000 000 rader

--Notera att en �nnu st�rre tidsvinst finns vid m�nga samtidiga anv�ndare.
--XTP = helt latchfritt

--OBS: G�r inte att bli av med memory optimized filgrupp!
--S� fort det finns en mem-opt filgrupp s� kr�ver databasen n�gra GB minne vid uppstart

--Har vi databaser med memory optimized tables file groups?
EXEC sp_MSforeachdb 'PRINT ''?'' SELECT * FROM ?.sys.filegroups WHERE type = ''FX'''
SELECT * FROM sys.filegroups WHERE type = 'FX'

--Lek med backup
BACKUP DATABASE myOLTP TO DISK = 'C:\x\myOLTP.bak' WITH INIT
RESTORE HEADERONLY FROM DISK = 'C:\x\myOLTP.bak'
RESTORE FILELISTONLY FROM DISK = 'C:\x\myOLTP.bak' WITH FILE = 1

--St�da
USE master
GO
DROP DATABASE IF EXISTS myOLTP
--