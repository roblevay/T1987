--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

---------------------------------------------------------------------------------------------------------------
--LOB (Large OBject)
USE tempdb

CREATE TABLE t1(c1 int, c2 varchar(max), c3 nvarchar(max), c4 varbinary(max), c5 xml, c6 geography, c7 geometry)
CREATE TABLE t0(c1 int, c2 text,         c3 ntext,         c4 image ) --Gammalmodiga

--Kan �ndra fr�n gammalmodig till ny utan att datat beh�ver "lagras om", 
--dvs omedelbar operation
ALTER TABLE t0 ALTER COLUMN c2 varchar(max)


--LOB (BLOB, CLOB), i eller utanf�r raden?
CREATE TABLE t2(
 c1 int
,c2 varbinary(max)  --BLOB, default �r att ha data i raden, om det f�r plats (large value types out of row)
,c3 image			--BLOB, default �r att ha utanf�r raden (text in row)
)

SELECT name, text_in_row_limit, large_value_types_out_of_row
FROM sys.tables WHERE name IN ('t1', 't0', 't2')

EXEC sp_tableoption t2, 'large value types out of row', 1--lagrar all data utanf�r raden
EXEC sp_tableoption t2, 'text in row', 1--F�r �ldre datatyper, text, image osv


--Ovan lagrar inte om befintligt data
--G�r rebuild f�r det
ALTER TABLE ... REBUILD
ALTER INDEX ... REBUILD


---------------------------------------------------------------------------------------------------------------
--Filestream, visa inte!
DROP TABLE IF EXISTS t2
CREATE TABLE t2(
 c1 int
,c2 varbinary(max) FILESTREAM
)

INSERT INTO t2(c1, c2) 
VALUES(1, 0x2334454456)
--Inneh�ller i kolumnen c2 ligger som egna filer, en fil per "cell" (rad/kolumn)


---------------------------------------------------------------------------------------------------------------
--Row overflow (page overflow)
CREATE TABLE t3(
 c1 int
,c2 varchar(5000)
,c3 varchar(5000)
)

---------------------------------------------------------------------------------------------------------------
--Skillnad prestanda mellan nedanst�ende?
USE Adventureworks
DROP TABLE IF EXISTS t4, t5, t6

CREATE TABLE t4(c1 int IDENTITY, c2 varchar(40))
CREATE TABLE t5(c1 int IDENTITY, c2 varchar(4000))
CREATE TABLE t6(c1 int IDENTITY, c2 varchar(max))

--Vi provar!
INSERT INTO t4 SELECT TOP(500000) 'a' FROM sys.columns AS a CROSS JOIN sys.columns AS b
INSERT INTO t5 SELECT TOP(500000) 'b' FROM sys.columns AS a CROSS JOIN sys.columns AS b
INSERT INTO t6 SELECT TOP(500000) 'c' FROM sys.columns AS a CROSS JOIN sys.columns AS b
--Ja, allokering av utrymme i exekveringsplaner
--"Ha inte st�rre �n n�dv�ndigt"

SELECT TOP(10) * FROM t4
SELECT TOP(10) * FROM t5
SELECT TOP(10) * FROM t6

--Hur stora �r tabellerna?
EXEC sp_tableinfo 't4'
EXEC sp_tableinfo 't5'
EXEC sp_tableinfo 't6'
--8.76 Mb

SELECT * FROM t4 ORDER BY c1 --Ca 53 MB memory grant
SELECT * FROM t5 ORDER BY c1 --Ca 1.4 GB memory grant
SELECT * FROM t6 ORDER BY c1 --Ca 2.7 GB memory grant
--Antar halva storleken av max v�rdet

--Notera varningen i exekveringsplanen, syns eventuellt inte


