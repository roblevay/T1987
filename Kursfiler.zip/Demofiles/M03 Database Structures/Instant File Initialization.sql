--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Instant File Initialization
--SQL Server kan allokera disk f�r datafiler (ej log) utan att det ska initialiseras med hex 00 f�rst.

--Aktiverat genom att service konto f�r SQL Server har windows policy:
-- "Perform Volume Maintenance Tasks"

--Kan g�ras i setup fr�n 2016

--Kolla om p�slaget:

--1: i errorloggen
EXEC sp_readerrorlog 0, 1, 'instant'

--2: via DMV
SELECT servicename, instant_file_initialization_enabled FROM sys.dm_server_services

--3 i SQL Server configuration manager
--Properties p� SQL server tj�nsten