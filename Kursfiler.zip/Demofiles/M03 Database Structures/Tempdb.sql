--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Utforska lite om tempdb

----------------------------------------------------------------------------------------------------------------
--Mixed page allocations
----------------------------------------------------------------------------------------------------------------

SELECT d.name, d.is_mixed_page_allocation_on FROM sys.databases AS d
--Inga mixed page allocations i tempdb l�ngre.
--Trace flagga 1118 innan 2016. Denna trace flagga �r no-op fr�n och med 2016.

--Detta kunde vi st�lla f�r user-db med nedan:
ALTER DATABASE Olf SET MIXED_PAGE_ALLOCATION OFF




----------------------------------------------------------------------------------------------------------------
--"V�xer en s� v�xer alla"
----------------------------------------------------------------------------------------------------------------

SELECT name, is_autogrow_all_files FROM tempdb.sys.filegroups
--Vi v�xer med samma storlek f�r alla filer n�r en grow kickar in. 
--Trace flaga 1117 innan 2016. Denna trace flagga �r no-op fr�n och med 2016.

--Inte p�slaget per default f�r user-db
SELECT name, is_autogrow_all_files FROM Olf.sys.filegroups
SELECT name, is_autogrow_all_files FROM tempdb.sys.filegroups

--St�ller med ALTER DATABASE, MODIFY FILEGROUP
ALTER DATABASE Olf MODIFY FILEGROUP [PRIMARY] AUTOGROW_ALL_FILES 

USE tempdb


----------------------------------------------------------------------------------------------------------------
--Utrymmesallokering
----------------------------------------------------------------------------------------------------------------
USE tempdb

--Utrymme per fil, nul�get
select * from sys.database_files


--Utrymme per fil, startl�get f�r tempdb
select * from sys.master_files

--Nul�get
SELECT 
 'tempdb' AS db_name_
,file_id
,name
,physical_name
,CAST(size AS bigint) * 8192/(1024*1024) AS size_MB
,type_desc
,CASE WHEN is_percent_growth = 1 THEN CAST(growth AS varchar(3)) + ' %' ELSE CAST(growth * 8192/(1024*1024) AS varchar(3)) + ' MB' END AS growth
,CAST(max_size AS bigint) * 8192/(1024*1024) AS max_size_MB
FROM tempdb.sys.database_files
ORDER BY type

--N�sta omstart
SELECT
 DB_NAME(database_id) AS db_name_
,file_id
,name
,physical_name
,CAST(size AS bigint) * 8192/(1024*1024) AS size_MB
,type_desc
,CASE WHEN is_percent_growth = 1 THEN CAST(growth AS varchar(3)) + ' %' ELSE CAST(growth * 8192/(1024*1024) AS varchar(3)) + ' MB' END AS growth
,CAST(max_size AS bigint) * 8192/(1024*1024) AS max_size_MB
FROM master.sys.master_files
WHERE DB_NAME(database_id)  = 'tempdb'
ORDER BY db_name_, type_desc


--V�x tempdb
SELECT * INTO #mTempTable FROM Adventureworks.Sales.SalesOrderDetail
SELECT * INTO #mTempTable2 FROM Adventureworks.Sales.SalesOrderDetail

--Ledigt utrymme per fil
SELECT b.name, b.physical_name, unallocated_extent_page_count AS [free pages], (unallocated_extent_page_count*1.0/128) AS [free space in MB]
FROM sys.dm_db_file_space_usage AS a
 INNER JOIN sys.database_files AS b ON a.file_id = b.file_id


--Utrymme nyttjat i tempdb
SELECT 
 SUM(version_store_reserved_page_count)*1.0/128	AS version_store_MB
,SUM(internal_object_reserved_page_count)*1.0/128 AS internal_object_MB
,SUM(user_object_reserved_page_count)*1.0/128		AS user_object_MB
FROM sys.dm_db_file_space_usage

--Vem anv�nder tempdb?
-- https://blog.sqlauthority.com/2015/01/23/sql-server-who-is-consuming-my-tempdb-now/
-- https://technet.microsoft.com/en-us/library/ms176029%28v=sql.105%29.aspx?f=255&MSPPError=-2147217396

