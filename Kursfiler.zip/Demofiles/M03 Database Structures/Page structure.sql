--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--Titta p� fysiska lagringsstrukturer
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--L�s denna blog-serie f�r bra �versikt!
-- https://www.sqlskills.com/blogs/paul/how-the-on-disk-data-structures-fit-together/


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--Se RID f�r rader
Use Adventureworks

--sys.fn_PhysLocFormatter
--Scalar function som returnerar en kolumn med (File:Page:Slot)
SELECT TOP(100) 
 sys.fn_PhysLocFormatter(%%physloc%%) AS [File:Page:Slot]
,p.FirstName
,p.LastName
,p.ModifiedDate
FROM  Person.Person AS p

--sys.fn_PhysLocCracker
--Table function som returnerar tre kolumner, en f�r varje
SELECT TOP(100)
 f.file_id
,f.page_id
,f.slot_id
,p.FirstName
,p.LastName
,p.ModifiedDate
FROM   Person.Person AS p
CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) AS f


--DMV f�r att "kracka" IAM
SELECT * FROM sys.dm_db_database_page_allocations(DB_ID(), OBJECT_ID('Sales.SalesOrderDetail'), null, null, 'DETAILED') AS a



--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--Pagelayout
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

DROP DATABASE IF EXISTS pubs
RESTORE DATABASE pubs 
FROM DISK = 'C:\DemoDatabases\Pubs\pubs_2012.bak'
WITH
 REPLACE
,MOVE 'pubs' TO 'C:\DemoDatabases\DbFiles\a\pubs.mdf'
,MOVE 'pubs_log' TO 'C:\DemoDatabases\DbFiles\a\pubs_log.ldf'
ALTER AUTHORIZATION ON DATABASE::pubs TO sa

----------------------------------------------------------------------------
--Vilka pages anv�nds av en tabell
----------------------------------------------------------------------------

SELECT * FROM pubs..authors

-- En liten tabell, inte m�nga rader
SELECT --*
 allocated_page_file_id
,allocated_page_page_id
,object_id
,partition_id
,allocation_unit_type_desc
,page_type
,page_type_desc
,index_id
FROM sys.dm_db_database_page_allocations(DB_ID('pubs'), OBJECT_ID('pubs.dbo.authors'), null, null, 'DETAILED');

--Alternativ, gammalmodig, metod
DBCC IND (pubs, authors, -1);

EXEC sp_indexinfo 'authors'

--Lite st�rre tabell
SELECT --*
 allocated_page_file_id
,allocated_page_page_id
,object_id
,partition_id
,allocation_unit_type_desc
,page_type
,page_type_desc
FROM sys.dm_db_database_page_allocations(DB_ID('Adventureworks'), OBJECT_ID('Sales.SalesOrderHeader'), null, null, 'DETAILED');



----------------------------------------------------------------------------
--Hex-dump av page
----------------------------------------------------------------------------
USE pubs

--F�r att f� output fr�n DBCC PAGE till klienten
DBCC TRACEON(3604)

-- Page header och buffer
DBCC PAGE(pubs, 1, 197, 2) --Den enda page f�r det klustrade indexet = datat
DBCC PAGE(pubs, 1, 197, 3) --Den enda page f�r det klustrade indexet = datat
DBCC PAGE(pubs, 1, 197, 1) WITH TABLERESULTS --Den enda page f�r det klustrade indexet = datat
DBCC PAGE(Adventureworks, 1, 85, 1) WITH TABLERESULTS --Den enda page f�r det klustrade indexet = datat

DBCC PAGE(pubs, 1, 200, 0) --Den enda page f�r det icke-klustrade indexet

--Sista parameter �r "printoption":
--0 bara header
--1 dump rad f�r rad
--2 r�-dump utan att koda av rader
--3 dump rad f�r rad, plus kolumn f�r kolumn


----------------------------------------------------------------------------
--Ett till exempel med DBCC PAGE och sys.dm_db_page_info
----------------------------------------------------------------------------

--Table to play with
DROP TABLE IF EXISTS t
CREATE TABLE t(c1 char(3), c2 char(3))
CREATE CLUSTERED INDEX x ON t(c1)
GO

--Table to hold output from DBCC PAGE
DROP TABLE IF EXISTS dbccpage
CREATE TABLE dbccpage(ParentObject_ varchar(200), Object_ varchar(200), Field_ varchar(200), Value_ varchar(1000))
GO

INSERT INTO t VALUES('aaa', 'AAA'), ('aaa', 'A2A'), ('aaa', 'A3A'), ('bbb', 'BBB')

--This doesn't show enough details regarding uniqueifier
SELECT *
FROM t 
CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) AS f
CROSS APPLY sys.dm_db_page_info(DB_ID(), f.file_id, f.page_id, 'Detailed')

--DBCC PAGE to the rescue

--Get output to calling app
DBCC TRACEON(3604)
GO

DECLARE 
 @dbid int = Db_ID()
,@fileno int
,@pageno int
,@sql varchar(1000)

SELECT TOP(1) @fileno = f.file_id, @pageno = page_id
FROM t 
CROSS APPLY sys.fn_PhysLocCracker(%%physloc%%) AS f

SET @sql = CONCAT('DBCC PAGE(', @dbid, ', ', @fileno, ', ', CAST(@pageno AS varchar(10)), ', 1) WITH TABLERESULTS' )
PRINT @sql

INSERT INTO dbccpage
EXEC(@sql)

--Output:
SELECT Field_, Value_
FROM dbccpage
WHERE ParentObject_ LIKE 'DATA:' OR ParentObject_ like 'Slot%'



----------------------------------------------------------------------------
--L�ngre exempel, f�r dom som �r intresserade
----------------------------------------------------------------------------

SELECT * FROM pubs..authors

--Klustrad tabell (klustrat index �r samma som data) p� au_id, samt ett icke-klustrat index p� (au_lname, au_fname)
EXEC sp_indexinfo 'authors'

--F�r att f� output fr�n DBCC PAGE till klienten
DBCC TRACEON(3604)

-- Page header och buffer
DBCC PAGE(pubs, 1, 197, 0)

--L�gg till rad med l�gt au_id (det vi klustrar = sorterar p�)
INSERT INTO authors (au_id, au_lname, au_fname, phone, address, city, state, zip, contract)
VALUES('100-11-1111', 'Svensson', 'Johan', '415 986-7020', '111 V�g', 'Stockholm', 'SW', 34567, 1)

SELECT * FROM authors


-- Samt datat, rad f�r rad (kodar av via row-offset tabellen)
DBCC PAGE(pubs, 1, 197, 1)

--R� dump, nu i den ordning raderna ligger i page
DBCC PAGE(pubs, 1, 197, 2)

--Detaljer f�r varje rad *och* varje kolumn
DBCC PAGE(pubs, 1, 197, 3)

--Exempel p� TABLERESULT, som finns f�r vissa DBCC kommandon
DBCC PAGE(pubs, 1, 197, 1) WITH TABLERESULTS

--Om man vill ma resultatet i tabell (m�sta ha skapat tabellen f�rst)
DROP TABLE mytable
CREATE TABLE mytable(ParentObject varchar(600), Object varchar(600), Field varchar(600), value varchar(600))
INSERT INTO mytable
EXEC('DBCC PAGE(pubs, 1, 197, 1) WITH TABLERESULTS')

SELECT * FROM mytable
