--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--Shared och uniform extents
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

USE Olf
GO

--Skapa procedur som via IAM page summerar allokering
CREATE OR ALTER PROCEDURE show_allocations
@table_name sysname
AS
SELECT 
 a.extent_page_id AS first_page_in_extent
,CASE WHEN MAX(a.is_mixed_page_allocation) = 0 THEN 'Uniform' ELSE 'Shared' END AS extent_type
,COUNT(*) AS pages_owned_by_table
,CASE WHEN MAX(a.is_mixed_page_allocation) = 1 THEN ' ' ELSE CAST(SUM(a.is_allocated) AS char(1)) END AS pages_used_so_far
,MAX(a.extent_file_id) AS file_id_
FROM sys.dm_db_database_page_allocations(DB_ID(), OBJECT_ID(@table_name), null, null, 'DETAILED') AS a
WHERE a.page_type_desc = 'DATA_PAGE'
GROUP BY extent_page_id

--SELECT COUNT(a.is_allocated) AS allocated_pages, a.is_mixed_page_allocation, CASE WHEN a.page_type_desc IS NULL THEN 'reserved_not_used' ELSE a.page_type_desc END AS page_type
--FROM sys.dm_db_database_page_allocations(DB_ID(), OBJECT_ID(@table_name), null, null, 'DETAILED') AS a
--GROUP BY a.page_type_desc, a.is_mixed_page_allocation
GO

--Exempel d�r varje rad kr�ver en egen page (l���nga rader)

--Default i 2016+ �r att inte allokera shared extent (annat �n f�r IAM)
--Tidigare allokerades f�rsta 8 pages fr�n shared extents
--Trace flag 1118 i tidigare versioner = inga shared extents. Trace flagga �r no-op fr�n och med 2016

DROP TABLE IF EXISTS stora_rader_2014
DROP TABLE IF EXISTS stora_rader_2016
GO

CREATE TABLE stora_rader_2014 (col1 int identity, col2 char(8000) default 'hello');
CREATE TABLE stora_rader_2016 (col1 int identity, col2 char(8000) default 'hello');

--Man kan anv�nda gammalmodiga sp_spaceused, men den �r inge vidare
EXEC sp_spaceused 'stora_rader_2014'
EXEC sp_spaceused 'stora_rader_2016'
--Vi k�r v�r egen ist�llet

ALTER DATABASE Olf SET MIXED_PAGE_ALLOCATION ON		--Gamla beteendet
INSERT INTO stora_rader_2014 DEFAULT VALUES
ALTER DATABASE Olf SET MIXED_PAGE_ALLOCATION OFF	--Nya (default) betendet
INSERT INTO stora_rader_2016 DEFAULT VALUES
EXEC show_allocations 'stora_rader_2014' 
EXEC show_allocations 'stora_rader_2016'
GO

--DMV f�r att "kracka" IAM
SELECT * FROM sys.dm_db_database_page_allocations(DB_ID(), OBJECT_ID('Sales.SalesOrderDetail'), null, null, 'DETAILED') AS a

