--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

CREATE TABLE x(
 f1 int
,v2 varchar(20)
,f3 datetime2(0)
,v4 nvarchar(100)
,f5 char(10))

f1f3f5

v2v4

ALTER TABLE x ALTER COLUMN f1 bigint
ALTER TABLE x ADD f6 int

