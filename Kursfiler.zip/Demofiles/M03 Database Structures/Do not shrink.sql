--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Vi ska visa hur illa shrink kan vara
USE master
GO

--Skapa ny databas
DROP DATABASE IF EXISTS MyDb

CREATE DATABASE MyDb
 ON  PRIMARY 
( NAME = 'MyDb', FILENAME = 'C:\demodatabases\dbfiles\a\MyDb.mdf' , SIZE = 50MB , FILEGROWTH = 10MB )
 LOG ON 
( NAME = 'MyDb_log', FILENAME = 'C:\demodatabases\dbfiles\a\MyDb_log.ldf' , SIZE = 200MB , FILEGROWTH = 50MB )
GO

USE MyDb

EXEC sp_dbinfo 'MyDb'

DROP TABLE IF EXISTS dont_shrink

--Skapa tabell att leka med, med en del data
SELECT * INTO dont_shrink FROM Adventureworks.Sales.SalesOrderDetail;

--N�gra rimliga index
CREATE INDEX x1 ON dont_shrink (salesOrderID);
CREATE CLUSTERED INDEX x2 ON dont_shrink (carrierTrackingNumber,SalesOrderId);
--CREATE INDEX x2 ON dont_shrink (carrierTrackingNumber,SalesOrderId);
CREATE INDEX x3 ON dont_shrink (ModifiedDate);

--Fragmentering?
SELECT  f.index_type_desc, f.avg_fragmentation_in_percent, f.page_count, f.avg_page_space_used_in_percent, f.record_count, f.forwarded_record_count
FROM sys.dm_db_index_physical_stats (DB_ID(), OBJECT_ID('dont_shrink'), NULL, NULL, 'DETAILED')  AS f
WHERE index_level = 0

--Borde se bra ut, har nyss skapat v�ra index

--Orsaka lite fragmentering, denna tar ca 15 sekunder (en knapp minut)
DECLARE @i int =1;
WHILE @i <=5
BEGIN
	INSERT INTO dont_shrink
	SELECT SalesOrderID, CarrierTrackingNumber, OrderQty, ProductID, SpecialOfferID, UnitPrice, UnitPriceDiscount, LineTotal, rowguid, ModifiedDate 
	  FROM Adventureworks.Sales.SalesOrderDetail;
	  SET @i = @i +1;
END

--Fragmentering?
--Oj, d�. (ca 25000 pages)

--Vi �r v�l duktiga och defragmenterar
--ALTER TABLE dont_shrink REBUILD
ALTER INDEX x2 ON dont_shrink REBUILD
ALTER INDEX x1 ON dont_shrink REBUILD
ALTER INDEX x3 ON dont_shrink REBUILD

--Fragmentering?
--Ser bra ut (ca 15000 pages)

--Storlek p� databasfilerna (skapades ursprungligen med 50, 200 MB)
EXEC sp_dbinfo
--Jahapp, har haft en del autogrow

--S�g nu att vi tycker att vi har mycket ledigt i databasen

--G�r f�rst shrink med GUI, default

--Hur mycket mindre blev den
EXEC sp_dbinfo
--Varf�r krympte den inte mer?
--Tips, skripta kommando och kolla options

--Vi g�r ett mer seri�st f�rs�k
DECLARE @dt datetime2(3) = SYSDATETIME()
DBCC SHRINKFILE(1, 200)
SELECT DATEDIFF(ms, @dt, SYSDATETIME()) --0.6 sekund n�r tbl �r klustrad, 23.6 sekund n�r heap

--Att flytta en page kr�ver X l�s. Shrink v�ntar f�r evigt p� detta l�s.
--Att flytta en LOB page kr�ver en table scan. F�r varje page!!!
--Att flytta en heap page inneb�r updatering av alla NC index som pekar p� alla rader p� denna page.

--Storlek?
EXEC sp_dbinfo

--Fragmentering?
--Oj, d�

--St�da
USE master
DROP DATABASE MyDb

