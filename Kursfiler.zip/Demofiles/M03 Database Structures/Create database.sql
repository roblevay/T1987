--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Skapa
CREATE DATABASE Olf
ON PRIMARY
 (NAME = OlfData1, FILENAME = 'C:\DemoDatabases\DbFiles\a\OlfData1.mdf', SIZE = 2GB, MAXSIZE = 5GB, FILEGROWTH = 500MB)
,(NAME = OlfData2, FILENAME = 'C:\DemoDatabases\DbFiles\a\OlfData2.ndf', SIZE = 2GB, MAXSIZE = 5GB, FILEGROWTH = 500MB)
,FILEGROUP HistoryData
 (NAME = OlfHist1, FILENAME = N'C:\DemoDatabases\DbFiles\a\OlfHist1.ndf',SIZE = 2GB, FILEGROWTH = 500MB )
LOG ON
(NAME = OlfLog1, FILENAME = 'C:\DemoDatabases\DbFiles\a\OlfLog1.ldf', SIZE = 2GB, MAXSIZE = UNLIMITED, FILEGROWTH = 500MB )
GO

--Kan ocks� l�gga till i efterhand, typ
--ALTER DATABASE ... ADD FILGROUP ...
--ALTER DATABASE ... ADD FILE ...
--ALTER DATABASE ... MODIFY FILE 

SELECT * FROM sys.databases

SELECT * FROM Olf.sys.database_files
SELECT * FROM Olf.sys.filegroups

SELECT DB_NAME(database_id), * FROM sys.master_files

SELECT * FROM sys.dm_db_file_space_usage
SELECT * FROM sys.dm_io_virtual_file_stats(NULL, NULL)

--P� min web-site
EXEC sp_dbinfo
EXEC sp_tableinfo
EXEC sp_indexinfo 'FactResellerSalesXL'






--Hur full �r loggen?
DBCC SQLPERF(logspace)

SELECT * FROM Sales.SalesOrderDetail ORDER BY OrderQty

SELECT d.name, d.log_reuse_wait_desc FROM sys.databases AS d
