--Copyright Tibor Karaszi Konsulting. Not to be used by others for educational purposes.

--Titta p� I/O


--F�r b�sta resultat, starta om SQL Server
SHUTDOWN

DBCC DROPCLEANBUFFERS

--Starta g�rna �ven perfmon, MSSQL$A:Buffer Manager, Page reads/sec

SET STATISTICS IO ON

--Inget index p� CurrencyKey -> table scan
SELECT * FROM AdventureworksDW.dbo.FactResellerSales AS f WHERE f.CurrencyKey > 99999

--Notera att det rapporteras
-- massa logical reads
-- n�gra f� physical reads
-- ett antal read ahead reads


--Hur ser BCHR ut?
SELECT (a.cntr_value * 1.0 / b.cntr_value) * 100.0 as BufferCacheHitRatio
FROM sys.dm_os_performance_counters  AS a
JOIN  (SELECT cntr_value, OBJECT_NAME 
    FROM sys.dm_os_performance_counters  
    WHERE counter_name = 'Buffer cache hit ratio base'
        AND OBJECT_NAME = 'Sqlserver:Buffer Manager') AS b ON  a.OBJECT_NAME = b.OBJECT_NAME
WHERE a.counter_name = 'Buffer cache hit ratio'
AND a.OBJECT_NAME = 'Sqlserver:Buffer Manager'




--Nja, skulle inte tro det!
--Se tex https://www.simple-talk.com/sql/database-administration/great-sql-server-debates-buffer-cache-hit-ratio/

--Man kan �ven g�ra SELECT fr�n en STOR tabell
--och s�tta ner max server memory till ett v�rde l�ngre �n tabellens storlek
--det blir �nnu tydligare!

SELECT * FROM sys.databases