--Anv�nd max 25 procent
SELECT * FROM person.Person
ORDER BY 1,2,3,4
OPTION (MAX_GRANT_PERCENT = 25)
