--Max minne
EXEC sys.sp_configure N'max server memory (MB)', N'6000'
GO
RECONFIGURE WITH OVERRIDE
GO

--Min minne n�r det har uppn�tts
EXEC sys.sp_configure N'min server memory (MB)', N'1000'
GO
RECONFIGURE WITH OVERRIDE
GO
