--Kolla diskhastighet
BACKUP DATABASE Adventureworks TO DISK='nul'--Filen sparas inte
WITH NO_COMPRESSION, INIT
