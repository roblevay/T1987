
CREATE DATABASE [vlfdb]
 ON  PRIMARY 
( NAME = N'vlfdb', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\vlfdb.mdf' , SIZE = 8192KB , FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'vlfdb_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\vlfdb_log.ldf' , SIZE = 1024KB , FILEGROWTH = 1024KB )
GO


--backup av databasen
BACKUP DATABASE vlfdb TO DISK='c:\backup\vlfdb.bak' WITH INIT

--Skapa en tabell med mycket loggning
CREATE TABLE tabellx (Col1 CHAR(8000))
GO
BEGIN TRAN;

INSERT INTO dbo.tabellx
VALUES (REPLICATE('X', 8000));
GO 10000
COMMIT;

--Kolla virtuella logfiler

     DBCC LOGINFO;


--Ta backup och krymp f�r att �tg�rda detta
BACKUP LOG vlfdb TO DISK='c:\backup\vlfdblog.bak' WITH INIT

USE [vlfdb]
GO
DBCC SHRINKFILE (N'vlfdb_log' , 0, TRUNCATEONLY)
GO

