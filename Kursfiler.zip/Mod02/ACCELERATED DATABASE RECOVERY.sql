--ACCELERATED DATABASE RECOVERY

/*F�rdelar:
Snabbare recovery efter omstart. 
Snabbare rollback av stora transaktioner. 
Mer f�ruts�gbara failover-tider i AG och FCI. 

Nackdelar:
�kad anv�ndning av databasutrymme f�r versionslagring. 
Kan ge n�got h�gre I/O-belastning. */

--Aktivera ADR per databas:
ALTER DATABASE AdventureWorks
SET ACCELERATED_DATABASE_RECOVERY = ON;

--Kontrollera status:
SELECT name, is_accelerated_database_recovery_on
FROM sys.databases;

