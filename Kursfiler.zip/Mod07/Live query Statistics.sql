--Visar live query statistics I Adventureworks
SELECT
    COUNT_BIG(*)
FROM Sales.SalesOrderDetail sod1
CROSS JOIN Sales.SalesOrderDetail sod2
CROSS JOIN Production.Product p
OPTION (MAXDOP 1);
GO
